import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertDebate, type InsertTurn, type DebateWithRelations } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

// ============================================
// TOPICS
// ============================================

export function useTopics(category?: string) {
  return useQuery({
    queryKey: [api.topics.list.path, category],
    queryFn: async () => {
      const url = category 
        ? `${api.topics.list.path}?category=${category}`
        : api.topics.list.path;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch topics");
      return api.topics.list.responses[200].parse(await res.json());
    },
    enabled: !!category, // Only fetch if category is selected
    staleTime: Infinity, // Topics don't change often, prevent auto-refetch
  });
}

// ============================================
// DEBATES
// ============================================

export function useDebates(status?: 'waiting' | 'active' | 'completed') {
  return useQuery({
    queryKey: [api.debates.list.path, status],
    queryFn: async () => {
      const url = status 
        ? `${api.debates.list.path}?status=${status}`
        : api.debates.list.path;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch debates");
      // Note: Backend returns JSON, client uses explicit typing in schema
      return await res.json() as DebateWithRelations[]; 
    },
  });
}

export function useDebate(id: number) {
  return useQuery({
    queryKey: [api.debates.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.debates.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch debate");
      return await res.json() as DebateWithRelations;
    },
    refetchInterval: (query) => {
      const data = query.state.data;
      // Poll more frequently if active or judging
      if (data && (data.status === 'active' || data.status === 'judging')) {
        return 2000;
      }
      return 10000;
    },
  });
}

export function useCreateDebate() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertDebate) => {
      const validated = api.debates.create.input.parse(data);
      const res = await fetch(api.debates.create.path, {
        method: api.debates.create.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.debates.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 401) throw new Error("Please login to create a debate");
        throw new Error("Failed to create debate");
      }
      return api.debates.create.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.debates.list.path] });
      toast({
        title: "Debate Created",
        description: "Waiting for an opponent to join...",
      });
      return data;
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

export function useJoinDebate() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.debates.join.path, { id });
      const res = await fetch(url, {
        method: api.debates.join.method,
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 401) throw new Error("Please login to join");
        if (res.status === 400) {
           const err = await res.json();
           throw new Error(err.message || "Cannot join this debate");
        }
        throw new Error("Failed to join debate");
      }
      return api.debates.join.responses[200].parse(await res.json());
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.debates.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.debates.get.path, variables] });
      toast({
        title: "Joined Debate",
        description: "Get ready to argue your side!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

// ============================================
// TURNS
// ============================================

export function useCreateTurn() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ debateId, transcript }: { debateId: number, transcript: string }) => {
      const url = buildUrl(api.turns.create.path, { id: debateId });
      const validated = api.turns.create.input.parse({ transcript });
      
      const res = await fetch(url, {
        method: api.turns.create.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) throw new Error("Invalid argument data");
        if (res.status === 401) throw new Error("Unauthorized");
        throw new Error("Failed to submit argument");
      }
      return api.turns.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.debates.get.path, variables.debateId] });
      toast({
        title: "Argument Submitted",
        description: "Your turn has been recorded.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

// ============================================
// RE-JUDGE DEBATE
// ============================================

export function useReJudgeDebate(debateId: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/debates/${debateId}/rejudge`, {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to re-judge debate");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.debates.get.path, debateId] });
      toast({
        title: "Re-judgment Requested",
        description: "The AI judge is analyzing the debate again...",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
