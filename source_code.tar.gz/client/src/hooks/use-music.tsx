import { createContext, useContext, useState, useEffect, useRef, ReactNode } from "react";

export interface MusicTrack {
  id: string;
  name: string;
  url: string;
}

export const MUSIC_TRACKS: MusicTrack[] = [
  { id: "none", name: "No Music", url: "" },
  { id: "chill", name: "Chill Vibes", url: "https://cdn.pixabay.com/audio/2022/05/27/audio_1808fbf07a.mp3" },
  { id: "focus", name: "Deep Focus", url: "https://cdn.pixabay.com/audio/2024/09/10/audio_6e5d7d1912.mp3" },
  { id: "epic", name: "Epic Battle", url: "https://cdn.pixabay.com/audio/2022/08/25/audio_4f3b0a816e.mp3" },
  { id: "lofi", name: "Lo-Fi Beats", url: "https://cdn.pixabay.com/audio/2022/01/18/audio_d0a13f69d2.mp3" },
  { id: "jazz", name: "Smooth Jazz", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3" },
  { id: "arabic", name: "Arabic Classical", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3" },
];

export const DEFAULT_TRACK_ID = "lofi";

interface MusicContextType {
  currentTrack: MusicTrack;
  setTrack: (track: MusicTrack) => void;
  isPlaying: boolean;
  togglePlayback: () => void;
  startPlayback: () => void;
  volume: number;
  setVolume: (volume: number) => void;
}

const MusicContext = createContext<MusicContextType | undefined>(undefined);

export function MusicProvider({ children }: { children: ReactNode }) {
  const [currentTrack, setCurrentTrack] = useState<MusicTrack>(() => {
    const saved = localStorage.getItem("musicTrack");
    if (saved) {
      const found = MUSIC_TRACKS.find(t => t.id === saved);
      if (found) return found;
    }
    return MUSIC_TRACKS.find(t => t.id === DEFAULT_TRACK_ID) || MUSIC_TRACKS[1];
  });
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolumeState] = useState(() => {
    const saved = localStorage.getItem("musicVolume");
    return saved ? parseFloat(saved) : 0.3;
  });
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.loop = true;
    }
    
    const audio = audioRef.current;
    
    if (currentTrack.url) {
      audio.src = currentTrack.url;
      audio.volume = volume;
      if (isPlaying) {
        audio.play().catch(() => {});
      }
    } else {
      audio.pause();
      audio.src = "";
    }
    
    localStorage.setItem("musicTrack", currentTrack.id);
    
    return () => {
      audio.pause();
    };
  }, [currentTrack]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      localStorage.setItem("musicVolume", volume.toString());
    }
  }, [volume]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !currentTrack.url) return;
    
    if (isPlaying) {
      audio.play().catch(() => {});
    } else {
      audio.pause();
    }
  }, [isPlaying, currentTrack]);

  const setTrack = (track: MusicTrack) => {
    setCurrentTrack(track);
    if (track.url && !isPlaying) {
      setIsPlaying(true);
    }
  };

  const togglePlayback = () => {
    if (currentTrack.url) {
      setIsPlaying(!isPlaying);
    }
  };

  const startPlayback = () => {
    if (currentTrack.url && !isPlaying) {
      setIsPlaying(true);
    }
  };

  const setVolume = (v: number) => {
    setVolumeState(Math.max(0, Math.min(1, v)));
  };

  return (
    <MusicContext.Provider value={{ currentTrack, setTrack, isPlaying, togglePlayback, startPlayback, volume, setVolume }}>
      {children}
    </MusicContext.Provider>
  );
}

export function useMusic() {
  const context = useContext(MusicContext);
  if (!context) {
    throw new Error("useMusic must be used within a MusicProvider");
  }
  return context;
}
