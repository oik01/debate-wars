import { useState, useEffect, useCallback, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const OPT_OUT_KEY = 'debate-wars-notifications-opt-out';

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export function usePushNotifications() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSupported, setIsSupported] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const autoSubscribeAttempted = useRef(false);

  useEffect(() => {
    const supported = 'serviceWorker' in navigator && 'PushManager' in window;
    setIsSupported(supported);
    if (supported && 'Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const { data: vapidKey } = useQuery<{ publicKey: string }>({
    queryKey: ['/api/push/vapid-key'],
    enabled: isSupported,
  });

  const { data: subscriptionStatus, isLoading: statusLoading } = useQuery<{ subscribed: boolean }>({
    queryKey: ['/api/push/status'],
    enabled: isSupported,
  });

  const subscribeMutation = useMutation({
    mutationFn: async () => {
      if (!vapidKey?.publicKey) throw new Error('VAPID key not available');

      const permission = await Notification.requestPermission();
      setPermission(permission);
      
      if (permission !== 'granted') {
        throw new Error('Notification permission denied');
      }

      const registration = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;

      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidKey.publicKey),
      });

      const subscriptionJson = subscription.toJSON();
      await apiRequest('POST', '/api/push/subscribe', {
        endpoint: subscriptionJson.endpoint,
        keys: subscriptionJson.keys,
      });
      
      // Clear opt-out flag when user explicitly enables
      localStorage.removeItem(OPT_OUT_KEY);

      return subscription;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/push/status'] });
      toast({
        title: 'Notifications Enabled',
        description: "You'll now receive alerts for debates and challenges",
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Could not enable notifications',
        description: error.message || 'Please try again',
        variant: 'destructive',
      });
    },
  });

  const unsubscribeMutation = useMutation({
    mutationFn: async () => {
      const registration = await navigator.serviceWorker.getRegistration();
      if (!registration) return;

      const subscription = await registration.pushManager.getSubscription();
      if (!subscription) return;

      await apiRequest('POST', '/api/push/unsubscribe', {
        endpoint: subscription.endpoint,
      });

      await subscription.unsubscribe();
      
      // Mark as opted out so we don't auto-subscribe again
      localStorage.setItem(OPT_OUT_KEY, 'true');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/push/status'] });
      toast({
        title: 'Notifications Disabled',
        description: 'You will no longer receive push notifications',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to disable notifications',
        variant: 'destructive',
      });
    },
  });

  // Auto-subscribe on first load if user hasn't opted out
  useEffect(() => {
    if (autoSubscribeAttempted.current) return;
    if (!isSupported) return;
    if (statusLoading) return;
    if (!vapidKey?.publicKey) return;
    
    // Don't auto-subscribe if already subscribed
    if (subscriptionStatus?.subscribed) return;
    
    // Don't auto-subscribe if user has opted out
    const hasOptedOut = localStorage.getItem(OPT_OUT_KEY) === 'true';
    if (hasOptedOut) return;
    
    // Don't auto-subscribe if permission was previously denied
    if (permission === 'denied') return;
    
    // Mark as attempted to prevent multiple tries
    autoSubscribeAttempted.current = true;
    
    // Auto-subscribe (will prompt for permission)
    subscribeMutation.mutate();
  }, [isSupported, statusLoading, subscriptionStatus, vapidKey, permission, subscribeMutation]);

  const subscribe = useCallback(() => {
    subscribeMutation.mutate();
  }, [subscribeMutation]);

  const unsubscribe = useCallback(() => {
    unsubscribeMutation.mutate();
  }, [unsubscribeMutation]);

  return {
    isSupported,
    permission,
    isSubscribed: subscriptionStatus?.subscribed ?? false,
    isLoading: statusLoading || subscribeMutation.isPending || unsubscribeMutation.isPending,
    subscribe,
    unsubscribe,
  };
}
