import { useCallback, useRef } from "react";

type SoundType = "matchFound" | "ready" | "victory" | "defeat" | "tick" | "whoosh";

const SOUND_URLS: Record<SoundType, string> = {
  matchFound: "https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3",
  ready: "https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3",
  victory: "https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3",
  defeat: "https://assets.mixkit.co/active_storage/sfx/2020/2020-preview.mp3",
  tick: "https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3",
  whoosh: "https://assets.mixkit.co/active_storage/sfx/2577/2577-preview.mp3",
};

export function useSound() {
  const audioCache = useRef<Map<SoundType, HTMLAudioElement>>(new Map());

  const preloadSound = useCallback((type: SoundType) => {
    if (!audioCache.current.has(type)) {
      const audio = new Audio(SOUND_URLS[type]);
      audio.preload = "auto";
      audioCache.current.set(type, audio);
    }
  }, []);

  const playSound = useCallback((type: SoundType, volume: number = 0.5) => {
    try {
      let audio = audioCache.current.get(type);
      if (!audio) {
        audio = new Audio(SOUND_URLS[type]);
        audioCache.current.set(type, audio);
      }
      
      audio.currentTime = 0;
      audio.volume = Math.max(0, Math.min(1, volume));
      audio.play().catch(() => {
      });
    } catch (e) {
    }
  }, []);

  return { playSound, preloadSound };
}
