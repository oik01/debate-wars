import { useState, useEffect, useRef, useCallback } from 'react';

interface SpeechRecognitionHook {
  isListening: boolean;
  transcript: string;
  startListening: () => void;
  stopListening: () => void;
  resetTranscript: () => void;
  error: string | null;
  isSupported: boolean;
}

export function useSpeechRecognition(): SpeechRecognitionHook {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(false);
  
  const recognitionRef = useRef<any>(null);
  const finalTranscriptRef = useRef('');
  const shouldRestartRef = useRef(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).webkitSpeechRecognition) {
      setIsSupported(true);
    } else {
      setIsSupported(false);
      setError('Speech recognition not supported. Please use Chrome or type your argument.');
    }
  }, []);

  const createRecognition = useCallback(() => {
    if (typeof window === 'undefined' || !(window as any).webkitSpeechRecognition) {
      return null;
    }
    
    const SpeechRecognition = (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    // Key settings based on best practices research
    recognition.continuous = false; // Use manual restart for stability
    recognition.interimResults = true;
    recognition.lang = 'en-US';
    recognition.maxAlternatives = 1;

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      
      // CRITICAL: Start from resultIndex to avoid reprocessing old results
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const text = result[0].transcript;
        
        if (result.isFinal) {
          // Append final result with space
          finalTranscriptRef.current = (finalTranscriptRef.current + ' ' + text).trim();
        } else {
          // Keep only current interim
          interimTranscript = text;
        }
      }
      
      // Display: finalized text + current interim
      const display = (finalTranscriptRef.current + ' ' + interimTranscript).trim();
      setTranscript(display);
    };

    recognition.onerror = (event: any) => {
      // Ignore non-critical errors
      if (event.error === 'no-speech' || event.error === 'aborted') {
        return;
      }
      console.error('Speech recognition error:', event.error);
      setError(`Speech error: ${event.error}`);
      setIsListening(false);
    };

    recognition.onend = () => {
      // Manual restart if still supposed to be listening
      if (shouldRestartRef.current && recognitionRef.current) {
        try {
          // Small delay before restart to prevent rapid cycling
          setTimeout(() => {
            if (shouldRestartRef.current && recognitionRef.current) {
              recognitionRef.current.start();
            }
          }, 100);
        } catch (err) {
          console.error('Failed to restart recognition:', err);
          setIsListening(false);
        }
      } else {
        setIsListening(false);
      }
    };

    return recognition;
  }, []);

  const startListening = useCallback(() => {
    if (!isSupported || isListening) return;
    
    try {
      // Reset state
      finalTranscriptRef.current = '';
      setTranscript('');
      setError(null);
      shouldRestartRef.current = true;
      
      const recognition = createRecognition();
      if (recognition) {
        recognitionRef.current = recognition;
        recognition.start();
        setIsListening(true);
      }
    } catch (err) {
      console.error('Failed to start recognition:', err);
      setError('Failed to start speech recognition. Please try again.');
    }
  }, [isSupported, isListening, createRecognition]);

  const stopListening = useCallback(() => {
    shouldRestartRef.current = false;
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (err) {
        // Ignore stop errors
      }
      recognitionRef.current = null; // Clear to avoid stale instances
    }
    setIsListening(false);
  }, []);

  const resetTranscript = useCallback(() => {
    finalTranscriptRef.current = '';
    setTranscript('');
  }, []);

  return {
    isListening,
    transcript,
    startListening,
    stopListening,
    resetTranscript,
    error,
    isSupported,
  };
}
