import { useState } from "react";
import { UserAvatar } from "./user-avatar";
import { UserProfileModal } from "./user-profile-modal";

interface ClickableAvatarProps {
  user: {
    id?: string;
    avatarType?: string | null;
    customAvatarUrl?: string | null;
    profileImageUrl?: string | null;
    firstName?: string | null;
    lastName?: string | null;
    email?: string | null;
    username?: string | null;
  } | null;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  currentUserId?: string;
  disabled?: boolean;
  stopPropagation?: boolean;
}

export function ClickableAvatar({ 
  user, 
  size = "md", 
  className = "", 
  currentUserId, 
  disabled = false,
  stopPropagation = false 
}: ClickableAvatarProps) {
  const [modalOpen, setModalOpen] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (stopPropagation) {
      e.stopPropagation();
    }
    if (!disabled && user?.id) {
      setModalOpen(true);
    }
  };

  if (!user?.id || disabled) {
    return <UserAvatar user={user} size={size} className={className} />;
  }

  return (
    <>
      <button
        onClick={handleClick}
        className="cursor-pointer hover:opacity-80 transition-opacity focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 rounded-full"
        data-testid={`avatar-${user.id}`}
      >
        <UserAvatar user={user} size={size} className={className} />
      </button>
      <UserProfileModal
        userId={user.id}
        open={modalOpen}
        onOpenChange={setModalOpen}
        currentUserId={currentUserId}
      />
    </>
  );
}
