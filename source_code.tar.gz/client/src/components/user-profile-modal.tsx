import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Swords, TrendingDown, UserPlus, Users, History, BarChart, Loader2, MessageSquare } from "lucide-react";
import { UserAvatar } from "./user-avatar";
import { EloBadge } from "./elo-badge";
import { CountryFlag } from "./country-flag";
import { DebateSkillsChart } from "./debate-skills-chart";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface UserProfile {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  avatarType: string | null;
  customAvatarUrl: string | null;
  eloRating: string | null;
  wins: string | null;
  losses: string | null;
  nationality: string | null;
  politicalAffiliation: string | null;
  avgLogicScore: string | null;
  avgEvidenceScore: string | null;
  avgPersuasionScore: string | null;
  avgRebuttalsScore: string | null;
  totalDebatesGraded: string | null;
  rank?: number;
}

interface DebateHistory {
  id: number;
  topic: string;
  category: string;
  status: string;
  creatorId: string;
  opponentId: string | null;
  winnerId: string | null;
  creatorSide: string;
  createdAt: string;
  creator: UserProfile | null;
  opponent: UserProfile | null;
  judgment: {
    id: number;
    explanation: string;
    winnerId: string | null;
    creatorOverallGrade?: string;
    opponentOverallGrade?: string;
  } | null;
}

interface UserProfileModalProps {
  userId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentUserId?: string;
}

export function UserProfileModal({ userId, open, onOpenChange, currentUserId }: UserProfileModalProps) {
  const { toast } = useToast();
  
  const { data: profile, isLoading: profileLoading, isError: profileError } = useQuery<UserProfile>({
    queryKey: ["/api/users", userId],
    enabled: !!userId && open,
  });

  const { data: debates, isLoading: debatesLoading, isError: debatesError } = useQuery<DebateHistory[]>({
    queryKey: ["/api/users", userId, "debates"],
    enabled: !!userId && open,
  });

  const sendFriendRequest = useMutation({
    mutationFn: (targetId: string) => apiRequest("POST", "/api/relationship-requests", { 
      receiverId: targetId, 
      requestType: "friend" 
    }),
    onSuccess: () => {
      toast({ title: "Friend request sent!" });
      queryClient.invalidateQueries({ queryKey: ["/api/relationship-requests/sent"] });
    },
    onError: (error: any) => {
      const message = error?.message || "Failed to send request";
      toast({ title: message, variant: "destructive" });
    },
  });

  const sendRivalRequest = useMutation({
    mutationFn: (targetId: string) => apiRequest("POST", "/api/relationship-requests", { 
      receiverId: targetId, 
      requestType: "rival" 
    }),
    onSuccess: () => {
      toast({ title: "Rival request sent!" });
      queryClient.invalidateQueries({ queryKey: ["/api/relationship-requests/sent"] });
    },
    onError: (error: any) => {
      const message = error?.message || "Failed to send request";
      toast({ title: message, variant: "destructive" });
    },
  });

  const completedDebates = debates?.filter(d => d.status === "completed") || [];
  const isOwnProfile = currentUserId === userId;

  const getDisplayName = (user: UserProfile | null) => {
    if (!user) return "Unknown";
    if (user.firstName && user.lastName) return `${user.firstName} ${user.lastName}`;
    if (user.firstName) return user.firstName;
    return user.email?.split("@")[0] || "User";
  };

  if (!userId) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>User Profile</DialogTitle>
        </DialogHeader>

        {profileLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : profileError ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>Failed to load profile. Please try again.</p>
          </div>
        ) : profile ? (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <UserAvatar user={profile} size="xl" />
              <div className="flex-1">
                <h3 className="text-xl font-bold">{getDisplayName(profile)}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <EloBadge elo={parseInt(profile.eloRating || "1000")} />
                  {profile.nationality && (
                    <CountryFlag code={profile.nationality} size="sm" />
                  )}
                </div>
                <div className="flex items-center gap-3 mt-2 text-sm">
                  <span className="text-green-500 font-medium">{profile.wins || 0} Wins</span>
                  <span className="text-red-500 font-medium">{profile.losses || 0} Losses</span>
                  {profile.rank && (
                    <Badge variant="outline">Rank #{profile.rank}</Badge>
                  )}
                </div>
              </div>
            </div>

            {!isOwnProfile && currentUserId && (
              <div className="flex gap-2">
                <Button 
                  className="flex-1"
                  onClick={() => sendFriendRequest.mutate(userId)}
                  disabled={sendFriendRequest.isPending}
                  data-testid="button-add-friend-modal"
                >
                  {sendFriendRequest.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Users className="h-4 w-4 mr-2" />
                  )}
                  Add Friend
                </Button>
                <Button 
                  variant="outline"
                  className="flex-1"
                  onClick={() => sendRivalRequest.mutate(userId)}
                  disabled={sendRivalRequest.isPending}
                  data-testid="button-add-rival-modal"
                >
                  {sendRivalRequest.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Swords className="h-4 w-4 mr-2" />
                  )}
                  Add Rival
                </Button>
              </div>
            )}

            <Tabs defaultValue="stats">
              <TabsList className="w-full">
                <TabsTrigger value="stats" className="flex-1">
                  <BarChart className="h-4 w-4 mr-2" />
                  Stats
                </TabsTrigger>
                <TabsTrigger value="history" className="flex-1">
                  <History className="h-4 w-4 mr-2" />
                  History ({completedDebates.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="stats" className="mt-4">
                {parseInt(profile.totalDebatesGraded || "0") > 0 ? (
                  <div className="space-y-4">
                    <DebateSkillsChart
                      logic={parseFloat(profile.avgLogicScore || "0")}
                      evidence={parseFloat(profile.avgEvidenceScore || "0")}
                      persuasion={parseFloat(profile.avgPersuasionScore || "0")}
                      rebuttals={parseFloat(profile.avgRebuttalsScore || "0")}
                      size={180}
                    />
                    <p className="text-sm text-center text-muted-foreground">
                      Based on {profile.totalDebatesGraded} graded debates
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-6 text-muted-foreground">
                    <BarChart className="h-10 w-10 mx-auto mb-2 opacity-50" />
                    <p>No graded debates yet</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="history" className="mt-4">
                {debatesLoading ? (
                  <div className="flex items-center justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : debatesError ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <History className="h-10 w-10 mx-auto mb-2 opacity-50" />
                    <p>Failed to load debate history</p>
                  </div>
                ) : completedDebates.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <History className="h-10 w-10 mx-auto mb-2 opacity-50" />
                    <p>No debate history yet</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {completedDebates.slice(0, 10).map((debate) => {
                      const userWon = debate.winnerId === userId;
                      const isTie = !debate.winnerId;
                      const isCreator = debate.creatorId === userId;
                      const opponent = isCreator ? debate.opponent : debate.creator;
                      
                      return (
                        <Card 
                          key={debate.id}
                          className={`p-3 ${
                            userWon ? "border-green-500/30" : 
                            isTie ? "border-yellow-500/30" : 
                            "border-red-500/30"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              userWon ? "bg-green-500/20 text-green-500" : 
                              isTie ? "bg-yellow-500/20 text-yellow-500" : 
                              "bg-red-500/20 text-red-500"
                            }`}>
                              {userWon ? <Trophy className="h-4 w-4" /> : 
                               isTie ? <Swords className="h-4 w-4" /> :
                               <TrendingDown className="h-4 w-4" />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium line-clamp-1">{debate.topic}</p>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <span>{new Date(debate.createdAt).toLocaleDateString()}</span>
                                {opponent && (
                                  <span>vs {getDisplayName(opponent)}</span>
                                )}
                              </div>
                            </div>
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            User not found
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
