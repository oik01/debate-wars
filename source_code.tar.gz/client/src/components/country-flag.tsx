interface CountryFlagProps {
  code: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const dimensions = {
  sm: { width: 20, height: 15, src: "w20", srcSet: "w40" },
  md: { width: 32, height: 24, src: "w40", srcSet: "w80" },
  lg: { width: 48, height: 36, src: "w80", srcSet: "w160" },
};

export function CountryFlag({ code, size = "md", className = "" }: CountryFlagProps) {
  if (!code) return null;
  
  const { width, height, src, srcSet } = dimensions[size];
  return (
    <img
      src={`https://flagcdn.com/${src}/${code.toLowerCase()}.png`}
      srcSet={`https://flagcdn.com/${srcSet}/${code.toLowerCase()}.png 2x`}
      width={width}
      height={height}
      alt={code}
      className={`inline-block rounded-sm shadow-sm ${className}`}
    />
  );
}
