import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";
import introVideo from "@assets/intro.mp4";

interface IntroVideoProps {
  onComplete: () => void;
}

export function IntroVideo({ onComplete }: IntroVideoProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [hasStarted, setHasStarted] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (hasStarted && videoRef.current) {
      videoRef.current.play().catch(console.error);
    }
  }, [hasStarted]);

  const handleStart = () => {
    setHasStarted(true);
  };

  const handleVideoEnd = () => {
    setIsVisible(false);
    setTimeout(onComplete, 500);
  };

  const handleSkip = () => {
    setIsVisible(false);
    setTimeout(onComplete, 300);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-50 bg-black flex items-center justify-center"
          data-testid="intro-video-container"
        >
          {!hasStarted ? (
            <div className="flex flex-col items-center gap-8">
              <motion.h1 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-5xl md:text-7xl font-bold text-white tracking-tight"
              >
                Debate<span className="text-primary">Wars</span>
              </motion.h1>
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
              >
                <Button
                  size="lg"
                  onClick={handleStart}
                  className="gap-2 text-lg px-8 py-6"
                  data-testid="button-start-intro"
                >
                  <Play className="h-5 w-5" />
                  Watch Intro
                </Button>
              </motion.div>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <Button
                  variant="ghost"
                  onClick={handleSkip}
                  className="text-white/60 hover:text-white"
                  data-testid="button-skip-to-app"
                >
                  Skip to App
                </Button>
              </motion.div>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                src={introVideo}
                className="w-full h-full object-cover"
                onEnded={handleVideoEnd}
                playsInline
                data-testid="intro-video"
              />
              <Button
                variant="outline"
                onClick={handleSkip}
                className="absolute bottom-8 right-8 backdrop-blur-sm"
                data-testid="button-skip-intro"
              >
                Skip Intro
              </Button>
            </>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
