import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, ChevronDown, ChevronUp, Award, Crown } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import type { Judgment } from "@shared/schema";

interface JudgmentDisplayProps {
  judgment: Judgment;
  creator: { id: string; username: string; profileImageUrl?: string | null };
  opponent: { id: string; username: string; profileImageUrl?: string | null };
  creatorSide: "pro" | "con";
  winnerId?: string | null;
  onReJudge?: () => void;
  isReJudging?: boolean;
  showReJudgeButton?: boolean;
}

type GradeInfo = {
  grade: string;
  explanation: string;
  category: string;
};

function getGradeColor(grade: string): string {
  switch (grade?.toUpperCase()) {
    case 'A': return 'text-green-500 bg-green-500/20 border-green-500/30';
    case 'B': return 'text-blue-500 bg-blue-500/20 border-blue-500/30';
    case 'C': return 'text-yellow-500 bg-yellow-500/20 border-yellow-500/30';
    case 'D': return 'text-orange-500 bg-orange-500/20 border-orange-500/30';
    case 'F': return 'text-red-500 bg-red-500/20 border-red-500/30';
    default: return 'text-muted-foreground bg-muted border-border';
  }
}

function GradeBadge({ grade, size = "default" }: { grade: string; size?: "default" | "large" }) {
  const sizeClasses = size === "large" ? "w-14 h-14 text-2xl font-bold" : "w-10 h-10 text-lg font-semibold";
  return (
    <div className={`${sizeClasses} rounded-lg border-2 flex items-center justify-center ${getGradeColor(grade)}`}>
      {grade || "-"}
    </div>
  );
}

function GradeRow({ category, grade, explanation, isExpanded }: { category: string; grade: string; explanation: string; isExpanded: boolean }) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-foreground">{category}</span>
        <GradeBadge grade={grade} />
      </div>
      <AnimatePresence>
        {isExpanded && explanation && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="text-sm text-muted-foreground pl-2 border-l-2 border-border"
          >
            {explanation}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ReportCard({ 
  user, 
  grades, 
  overallGrade,
  isWinner 
}: { 
  user: { username: string; profileImageUrl?: string | null };
  grades: GradeInfo[];
  overallGrade: string;
  isWinner: boolean;
}) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <Card className={`relative overflow-hidden transition-all ${isWinner ? 'border-accent/50 bg-accent/5' : ''}`}>
      {isWinner && (
        <div className="absolute top-0 right-0">
          <div className="bg-accent text-accent-foreground px-4 py-1 text-xs font-bold transform rotate-45 translate-x-6 translate-y-2">
            WINNER
          </div>
        </div>
      )}
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center gap-3">
          <Avatar className="w-12 h-12">
            <AvatarImage src={user.profileImageUrl || undefined} />
            <AvatarFallback>{user.username?.[0]?.toUpperCase() || "?"}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-semibold truncate">{user.username}</span>
              {isWinner && <Crown className="w-5 h-5 text-accent shrink-0" />}
            </div>
            <div className="text-sm text-muted-foreground">
              Overall Grade
            </div>
          </div>
          <GradeBadge grade={overallGrade} size="large" />
        </div>

        <Button
          variant="ghost"
          className="w-full justify-between"
          onClick={() => setIsExpanded(!isExpanded)}
          data-testid={`button-expand-grades-${user.username}`}
        >
          <span className="text-sm">{isExpanded ? 'Hide Details' : 'View Category Grades'}</span>
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </Button>

        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-4"
            >
              {grades.map((g) => (
                <GradeRow
                  key={g.category}
                  category={g.category}
                  grade={g.grade}
                  explanation={g.explanation}
                  isExpanded={true}
                />
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}

function WinnerBanner({ winner, loser }: { winner: { username: string; profileImageUrl?: string | null }; loser: { username: string; profileImageUrl?: string | null } }) {
  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-accent/20 via-accent/10 to-accent/20 blur-2xl" />
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="relative flex flex-col items-center py-8"
      >
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex items-center gap-2 text-accent mb-4"
        >
          <Award className="w-6 h-6" />
          <span className="text-lg font-bold uppercase tracking-wider">Victory</span>
          <Award className="w-6 h-6" />
        </motion.div>

        <div className="flex items-center gap-8">
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-center"
          >
            <div className="relative">
              <Avatar className="w-20 h-20 border-4 border-accent shadow-lg shadow-accent/30">
                <AvatarImage src={winner.profileImageUrl || undefined} />
                <AvatarFallback className="text-2xl">{winner.username?.[0]?.toUpperCase() || "?"}</AvatarFallback>
              </Avatar>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.5, type: "spring", bounce: 0.5 }}
                className="absolute -top-3 -right-3 bg-accent text-accent-foreground rounded-full p-2"
              >
                <Trophy className="w-5 h-5" />
              </motion.div>
            </div>
            <div className="mt-3 font-bold text-lg">{winner.username}</div>
            <Badge variant="outline" className="bg-accent/20 text-accent border-accent/50">Winner</Badge>
          </motion.div>

          <div className="text-3xl font-bold text-muted-foreground">VS</div>

          <motion.div
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-center opacity-60"
          >
            <Avatar className="w-20 h-20 border-2 border-border">
              <AvatarImage src={loser.profileImageUrl || undefined} />
              <AvatarFallback className="text-2xl">{loser.username?.[0]?.toUpperCase() || "?"}</AvatarFallback>
            </Avatar>
            <div className="mt-3 font-medium text-lg text-muted-foreground">{loser.username}</div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}

function TieBanner({ player1, player2 }: { player1: { username: string; profileImageUrl?: string | null }; player2: { username: string; profileImageUrl?: string | null } }) {
  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-muted/20 via-muted/10 to-muted/20 blur-2xl" />
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="relative flex flex-col items-center py-8"
      >
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex items-center gap-2 text-muted-foreground mb-4"
        >
          <span className="text-lg font-bold uppercase tracking-wider">Draw</span>
        </motion.div>

        <div className="flex items-center gap-8">
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-center"
          >
            <Avatar className="w-20 h-20 border-2 border-border">
              <AvatarImage src={player1.profileImageUrl || undefined} />
              <AvatarFallback className="text-2xl">{player1.username?.[0]?.toUpperCase() || "?"}</AvatarFallback>
            </Avatar>
            <div className="mt-3 font-medium text-lg">{player1.username}</div>
          </motion.div>

          <div className="text-3xl font-bold text-muted-foreground">=</div>

          <motion.div
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-center"
          >
            <Avatar className="w-20 h-20 border-2 border-border">
              <AvatarImage src={player2.profileImageUrl || undefined} />
              <AvatarFallback className="text-2xl">{player2.username?.[0]?.toUpperCase() || "?"}</AvatarFallback>
            </Avatar>
            <div className="mt-3 font-medium text-lg">{player2.username}</div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}

function replaceProConWithNames(text: string, creatorName: string, opponentName: string, creatorSide: "pro" | "con"): string {
  if (!text) return text;
  // Map Pro/Con to actual names based on which side the creator took
  const proName = creatorSide === "pro" ? creatorName : opponentName;
  const conName = creatorSide === "con" ? creatorName : opponentName;
  return text
    .replace(/\bPro\b/g, proName)
    .replace(/\bCon\b/g, conName)
    .replace(/\bpro\b/g, proName)
    .replace(/\bcon\b/g, conName)
    .replace(/\bPRO\b/g, proName)
    .replace(/\bCON\b/g, conName);
}

export function JudgmentDisplay({ 
  judgment, 
  creator, 
  opponent, 
  creatorSide,
  winnerId,
  onReJudge,
  isReJudging,
  showReJudgeButton
}: JudgmentDisplayProps) {
  const isCreatorWinner = winnerId === creator.id;
  const isOpponentWinner = winnerId === opponent.id;
  const isTie = !winnerId;

  const winner = isCreatorWinner ? creator : isOpponentWinner ? opponent : null;
  const loser = isCreatorWinner ? opponent : isOpponentWinner ? creator : null;

  const creatorGrades: GradeInfo[] = [
    { category: "Logic & Reasoning", grade: judgment.creatorLogicGrade || "-", explanation: replaceProConWithNames(judgment.creatorLogicExplanation || "", creator.username, opponent.username, creatorSide) },
    { category: "Evidence & Facts", grade: judgment.creatorEvidenceGrade || "-", explanation: replaceProConWithNames(judgment.creatorEvidenceExplanation || "", creator.username, opponent.username, creatorSide) },
    { category: "Persuasion & Rhetoric", grade: judgment.creatorPersuasionGrade || "-", explanation: replaceProConWithNames(judgment.creatorPersuasionExplanation || "", creator.username, opponent.username, creatorSide) },
    { category: "Rebuttals & Counters", grade: judgment.creatorRebuttalsGrade || "-", explanation: replaceProConWithNames(judgment.creatorRebuttalsExplanation || "", creator.username, opponent.username, creatorSide) },
  ];

  const opponentGrades: GradeInfo[] = [
    { category: "Logic & Reasoning", grade: judgment.opponentLogicGrade || "-", explanation: replaceProConWithNames(judgment.opponentLogicExplanation || "", creator.username, opponent.username, creatorSide) },
    { category: "Evidence & Facts", grade: judgment.opponentEvidenceGrade || "-", explanation: replaceProConWithNames(judgment.opponentEvidenceExplanation || "", creator.username, opponent.username, creatorSide) },
    { category: "Persuasion & Rhetoric", grade: judgment.opponentPersuasionGrade || "-", explanation: replaceProConWithNames(judgment.opponentPersuasionExplanation || "", creator.username, opponent.username, creatorSide) },
    { category: "Rebuttals & Counters", grade: judgment.opponentRebuttalsGrade || "-", explanation: replaceProConWithNames(judgment.opponentRebuttalsExplanation || "", creator.username, opponent.username, creatorSide) },
  ];

  const explanationWithNames = replaceProConWithNames(judgment.explanation, creator.username, opponent.username, creatorSide);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-card border-2 border-accent/30 rounded-2xl shadow-2xl relative overflow-hidden"
      data-testid="container-judgment"
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white shadow-lg">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-2xl font-display">AI Judgment</h3>
            <p className="text-muted-foreground">The verdict is in</p>
          </div>
        </div>

        {winner && loser ? (
          <WinnerBanner winner={winner} loser={loser} />
        ) : (
          <TieBanner player1={creator} player2={opponent} />
        )}
      </div>

      <div className="p-6 space-y-6">
        <div className="prose prose-invert max-w-none">
          <p className="text-lg leading-relaxed text-foreground/90" data-testid="text-judgment-explanation">
            {explanationWithNames}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <ReportCard
            user={creator}
            grades={creatorGrades}
            overallGrade={judgment.creatorOverallGrade || "-"}
            isWinner={isCreatorWinner}
          />
          <ReportCard
            user={opponent}
            grades={opponentGrades}
            overallGrade={judgment.opponentOverallGrade || "-"}
            isWinner={isOpponentWinner}
          />
        </div>

        {showReJudgeButton && isTie && (
          <div className="pt-6 border-t border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">The AI judge was unable to determine a clear winner.</p>
                <p className="text-sm text-muted-foreground">You can request a re-judgment to try again.</p>
              </div>
              <Button
                onClick={onReJudge}
                disabled={isReJudging}
                data-testid="button-rejudge"
              >
                {isReJudging ? "Re-judging..." : "Request Re-judgment"}
              </Button>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
