import { useEffect } from "react";
import { usePWAInstall } from "@/hooks/use-pwa-install";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Smartphone, X } from "lucide-react";
import { motion } from "framer-motion";

interface PWAInstallPromptProps {
  trigger?: "auto" | "manual";
  onInstalled?: () => void;
}

export function PWAInstallPrompt({ trigger = "auto", onInstalled }: PWAInstallPromptProps) {
  const {
    showPrompt,
    promptInstall,
    triggerPrompt,
    dismissPrompt,
    shouldShowPrompt,
    isInstalled,
  } = usePWAInstall();

  useEffect(() => {
    if (trigger === "auto" && shouldShowPrompt()) {
      const timer = setTimeout(() => {
        triggerPrompt();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [trigger, shouldShowPrompt, triggerPrompt]);

  useEffect(() => {
    if (isInstalled && onInstalled) {
      onInstalled();
    }
  }, [isInstalled, onInstalled]);

  const handleInstall = async () => {
    const success = await promptInstall();
    if (success && onInstalled) {
      onInstalled();
    }
  };

  return (
    <Dialog open={showPrompt} onOpenChange={(open) => !open && dismissPrompt()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-primary" />
            Install Debate Wars
          </DialogTitle>
          <DialogDescription>
            Add the app to your home screen for the best experience
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <motion.div 
            className="flex justify-center"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-indigo-500 flex items-center justify-center shadow-lg">
              <svg width="48" height="48" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="35" fill="rgba(255,255,255,0.1)"/>
                <path d="M55 20 L35 48 L48 48 L42 80 L65 48 L52 48 Z" fill="#f59e0b"/>
                <ellipse cx="28" cy="38" rx="12" ry="10" fill="white" opacity="0.9"/>
                <ellipse cx="72" cy="62" rx="12" ry="10" fill="white" opacity="0.9"/>
              </svg>
            </div>
          </motion.div>
          
          <div className="space-y-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              <span>Quick access from your home screen</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              <span>Full-screen experience without browser bars</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              <span>Get push notifications for debates</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              <span>Works offline for basic features</span>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={dismissPrompt}
            className="flex-1"
            data-testid="button-dismiss-install"
          >
            <X className="w-4 h-4 mr-2" />
            Maybe Later
          </Button>
          <Button 
            onClick={handleInstall}
            className="flex-1"
            data-testid="button-install-app"
          >
            <Download className="w-4 h-4 mr-2" />
            Install App
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function PWAInstallButton({ className }: { className?: string }) {
  const { isInstallable, isInstalled, promptInstall } = usePWAInstall();

  if (isInstalled || !isInstallable) return null;

  return (
    <Button 
      onClick={promptInstall} 
      size="sm"
      className={className}
      data-testid="button-install-pwa"
    >
      <Download className="w-4 h-4 mr-2" />
      Install App
    </Button>
  );
}
