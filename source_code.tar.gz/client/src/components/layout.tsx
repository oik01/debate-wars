import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LogOut, Plus, Home, Menu, Trophy, User } from "lucide-react";
import { SettingsModal } from "@/components/settings-modal";
import { NotificationToggle } from "@/components/notification-toggle";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import logoImage from "@assets/logo.png";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-20 items-center justify-between">
          <Link href="/" className="flex items-center gap-3 font-display text-2xl md:text-3xl font-extrabold tracking-tight text-foreground hover:opacity-80 transition-opacity">
            <img src={logoImage} alt="Debate Wars" className="h-12 w-12 md:h-14 md:w-14 rounded-xl shadow-xl shadow-primary/30" />
            <span className="bg-gradient-to-r from-foreground via-foreground to-primary bg-clip-text">Debate<span className="text-transparent bg-gradient-to-r from-primary to-red-500 bg-clip-text">Wars</span></span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            <nav className="flex items-center gap-6 text-sm font-medium">
              <Link href="/" className="text-foreground/60 transition-colors hover:text-foreground" data-testid="link-dashboard">Dashboard</Link>
              <Link href="/leaderboard" className="text-foreground/60 transition-colors hover:text-foreground" data-testid="link-leaderboard">Leaderboard</Link>
            </nav>
            
            <div className="flex items-center gap-4">
              {user && <NotificationToggle />}
              <SettingsModal />
              
              {user && (
                <>
                  <Link href="/create">
                    <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground shadow-md shadow-primary/20">
                      <Plus className="h-4 w-4" />
                      New Debate
                    </Button>
                  </Link>
                
                  <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-9 w-9 rounded-full ring-2 ring-transparent hover:ring-primary/20 transition-all">
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={user.profileImageUrl || undefined} alt={user.email || 'User'} />
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {(user.email || 'U').substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <div className="flex items-center justify-start gap-2 p-2">
                      <div className="flex flex-col space-y-1 leading-none">
                        <p className="font-medium">{user.email?.split('@')[0] || 'User'}</p>
                        <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                      </div>
                    </div>
                    <DropdownMenuSeparator />
                    <Link href="/profile">
                      <DropdownMenuItem className="cursor-pointer" data-testid="link-profile">
                        <User className="mr-2 h-4 w-4" />
                        Profile & Stats
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/leaderboard">
                      <DropdownMenuItem className="cursor-pointer" data-testid="link-leaderboard-dropdown">
                        <Trophy className="mr-2 h-4 w-4" />
                        Leaderboard
                      </DropdownMenuItem>
                    </Link>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="cursor-pointer text-destructive focus:text-destructive" onClick={() => logout()}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Log out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                  </DropdownMenu>
                </>
              )}
            </div>
          </div>

          {/* Mobile Nav */}
          <div className="md:hidden flex items-center gap-2">
            {user && <NotificationToggle />}
            <SettingsModal />
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-10 w-10 border-2 border-primary/50 bg-primary/10 hover:bg-primary/20 hover:border-primary"
                  data-testid="button-mobile-menu"
                >
                  <Menu className="h-6 w-6 text-primary" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex flex-col gap-6 py-4">
                  <div className="flex items-center gap-3 font-display text-2xl font-extrabold">
                    <img src={logoImage} alt="Debate Wars" className="h-12 w-12 rounded-xl shadow-lg" />
                    <span>Debate<span className="text-transparent bg-gradient-to-r from-primary to-red-500 bg-clip-text">Wars</span></span>
                  </div>
                  
                  {user && (
                    <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                      <Avatar>
                        <AvatarImage src={user.profileImageUrl || undefined} />
                        <AvatarFallback>{(user.email || 'U').substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col">
                        <span className="font-medium">{user.email?.split('@')[0] || 'User'}</span>
                        <span className="text-xs text-muted-foreground">{user.email}</span>
                      </div>
                    </div>
                  )}

                  <nav className="flex flex-col gap-2">
                    <Link href="/" onClick={() => setIsOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start gap-2">
                        <Home className="h-4 w-4" />
                        Dashboard
                      </Button>
                    </Link>
                    <Link href="/create" onClick={() => setIsOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start gap-2">
                        <Plus className="h-4 w-4" />
                        New Debate
                      </Button>
                    </Link>
                    <Link href="/profile" onClick={() => setIsOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start gap-2">
                        <User className="h-4 w-4" />
                        Profile & Stats
                      </Button>
                    </Link>
                    <Link href="/leaderboard" onClick={() => setIsOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start gap-2">
                        <Trophy className="h-4 w-4" />
                        Leaderboard
                      </Button>
                    </Link>
                    <div className="pt-2 border-t border-border">
                      <SettingsModal />
                    </div>
                  </nav>

                  {user && (
                    <div className="mt-auto">
                      <Button variant="destructive" className="w-full gap-2" onClick={() => {
                        logout();
                        setIsOpen(false);
                      }}>
                        <LogOut className="h-4 w-4" />
                        Log out
                      </Button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <main className="flex-1 container py-6 md:py-8 lg:py-10">
        {children}
      </main>
    </div>
  );
}
