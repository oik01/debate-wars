import { useMemo } from "react";

interface DebateSkillsChartProps {
  logic: number;
  evidence: number;
  persuasion: number;
  rebuttals: number;
  size?: number;
}

function polarToCartesian(centerX: number, centerY: number, radius: number, angleInDegrees: number) {
  const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
  return {
    x: centerX + (radius * Math.cos(angleInRadians)),
    y: centerY + (radius * Math.sin(angleInRadians))
  };
}

export function DebateSkillsChart({ logic, evidence, persuasion, rebuttals, size = 200 }: DebateSkillsChartProps) {
  const padding = 55; // Extra padding for labels to prevent cropping
  const center = size / 2;
  const maxRadius = (size / 2) - padding;
  const levels = 4;
  
  const categories = useMemo(() => [
    { name: "Logic", value: logic, angle: 0 },
    { name: "Evidence", value: evidence, angle: 90 },
    { name: "Persuasion", value: persuasion, angle: 180 },
    { name: "Rebuttals", value: rebuttals, angle: 270 },
  ], [logic, evidence, persuasion, rebuttals]);

  const gridLines = useMemo(() => {
    const lines = [];
    for (let i = 1; i <= levels; i++) {
      const radius = (maxRadius / levels) * i;
      const points = categories.map(cat => polarToCartesian(center, center, radius, cat.angle));
      const pathData = points.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') + ' Z';
      lines.push(pathData);
    }
    return lines;
  }, [center, maxRadius, categories, levels]);

  const axisLines = useMemo(() => {
    return categories.map(cat => {
      const end = polarToCartesian(center, center, maxRadius, cat.angle);
      return { start: { x: center, y: center }, end };
    });
  }, [center, maxRadius, categories]);

  const dataPoints = useMemo(() => {
    return categories.map(cat => {
      const normalizedValue = Math.max(0, Math.min(4, cat.value)) / 4;
      const radius = maxRadius * normalizedValue;
      return polarToCartesian(center, center, radius, cat.angle);
    });
  }, [categories, center, maxRadius]);

  const dataPath = dataPoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') + ' Z';

  const labelPositions = useMemo(() => {
    return categories.map(cat => {
      const labelRadius = maxRadius + 28;
      const pos = polarToCartesian(center, center, labelRadius, cat.angle);
      return { ...cat, x: pos.x, y: pos.y };
    });
  }, [categories, center, maxRadius]);

  function scoreToGrade(score: number): string {
    if (score >= 3.7) return 'A';
    if (score >= 2.7) return 'B';
    if (score >= 1.7) return 'C';
    if (score >= 0.7) return 'D';
    return 'F';
  }

  function getGradeColor(score: number): string {
    if (score >= 3.7) return '#22c55e';
    if (score >= 2.7) return '#3b82f6';
    if (score >= 1.7) return '#eab308';
    if (score >= 0.7) return '#f97316';
    return '#ef4444';
  }

  const svgPadding = 20; // Extra padding for SVG to prevent label clipping
  const svgSize = size + (svgPadding * 2);
  
  return (
    <div className="flex flex-col items-center">
      <svg width={svgSize} height={svgSize} viewBox={`${-svgPadding} ${-svgPadding} ${svgSize} ${svgSize}`}>
        {gridLines.map((path, idx) => (
          <path
            key={idx}
            d={path}
            fill="none"
            stroke="currentColor"
            strokeOpacity={0.15}
            strokeWidth={1}
          />
        ))}
        
        {axisLines.map((line, idx) => (
          <line
            key={idx}
            x1={line.start.x}
            y1={line.start.y}
            x2={line.end.x}
            y2={line.end.y}
            stroke="currentColor"
            strokeOpacity={0.2}
            strokeWidth={1}
          />
        ))}

        <path
          d={dataPath}
          fill="hsl(var(--primary))"
          fillOpacity={0.25}
          stroke="hsl(var(--primary))"
          strokeWidth={2}
        />

        {dataPoints.map((point, idx) => (
          <circle
            key={idx}
            cx={point.x}
            cy={point.y}
            r={5}
            fill="hsl(var(--primary))"
            stroke="hsl(var(--background))"
            strokeWidth={2}
          />
        ))}

        {labelPositions.map((label, idx) => (
          <g key={idx}>
            <text
              x={label.x}
              y={label.y - 8}
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-xs fill-current font-medium"
            >
              {label.name}
            </text>
            <text
              x={label.x}
              y={label.y + 8}
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-sm font-bold"
              fill={getGradeColor(label.value)}
            >
              {scoreToGrade(label.value)}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

export function DebateSkillsStats({ 
  logic, 
  evidence, 
  persuasion, 
  rebuttals,
  totalDebatesGraded
}: DebateSkillsChartProps & { totalDebatesGraded: number }) {
  function scoreToGrade(score: number): string {
    if (score >= 3.7) return 'A';
    if (score >= 2.7) return 'B';
    if (score >= 1.7) return 'C';
    if (score >= 0.7) return 'D';
    return 'F';
  }

  function getGradeColor(score: number): string {
    if (score >= 3.7) return 'text-green-500';
    if (score >= 2.7) return 'text-blue-500';
    if (score >= 1.7) return 'text-yellow-500';
    if (score >= 0.7) return 'text-orange-500';
    return 'text-red-500';
  }

  const skills = [
    { name: "Logic", value: logic },
    { name: "Evidence", value: evidence },
    { name: "Persuasion", value: persuasion },
    { name: "Rebuttals", value: rebuttals },
  ];

  if (totalDebatesGraded === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>Complete debates to see your skill breakdown</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-center">
        <DebateSkillsChart 
          logic={logic} 
          evidence={evidence} 
          persuasion={persuasion} 
          rebuttals={rebuttals}
          size={250}
        />
      </div>
      
      <div className="grid grid-cols-2 gap-3 mt-4">
        {skills.map((skill) => (
          <div key={skill.name} className="flex items-center justify-between p-2 bg-muted/30 rounded-lg">
            <span className="text-sm text-muted-foreground">{skill.name}</span>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {skill.value.toFixed(1)}
              </span>
              <span className={`font-bold ${getGradeColor(skill.value)}`}>
                {scoreToGrade(skill.value)}
              </span>
            </div>
          </div>
        ))}
      </div>
      
      <div className="text-center text-xs text-muted-foreground pt-2">
        Based on {totalDebatesGraded} graded {totalDebatesGraded === 1 ? 'debate' : 'debates'}
      </div>
    </div>
  );
}
