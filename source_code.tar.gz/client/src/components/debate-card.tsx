import { Link } from "wouter";
import { type DebateWithRelations } from "@shared/schema";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserAvatar } from "@/components/user-avatar";
import { Mic, Trophy, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

function getDisplayName(user: { firstName?: string | null; lastName?: string | null; email?: string | null } | null): string {
  if (!user) return "Unknown";
  if (user.firstName) return `${user.firstName}${user.lastName ? ` ${user.lastName[0]}.` : ""}`;
  return user.email?.split("@")[0] || "Unknown";
}

interface DebateCardProps {
  debate: DebateWithRelations;
}

export function DebateCard({ debate }: DebateCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400 border-green-500/50';
      case 'completed': return 'bg-purple-500/20 text-purple-400 border-purple-500/50';
      case 'judging': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const getCategoryIcon = (category: string) => {
    // Add logic for specific icons based on category if desired
    return null;
  };

  return (
    <Link href={`/debate/${debate.id}`} className="block group">
      <Card className="h-full border-border/50 bg-card hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 overflow-hidden">
        <CardHeader className="pb-3 relative">
          <div className="flex justify-between items-start mb-2">
            <Badge variant="outline" className={`uppercase text-xs font-bold tracking-wider ${getStatusColor(debate.status)}`}>
              {debate.status}
            </Badge>
            <Badge variant="secondary" className="bg-secondary/10 text-secondary border-transparent">
              {debate.category}
            </Badge>
          </div>
          <CardTitle className="text-xl font-bold leading-tight group-hover:text-primary transition-colors line-clamp-2">
            {debate.topic}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="pb-4">
          <div className="flex items-center justify-between mt-2">
            <div className="flex items-center gap-2">
              <UserAvatar user={debate.creator || null} size="sm" className="border border-border" />
              <div className="text-sm">
                <p className="font-medium text-foreground/90">{getDisplayName(debate.creator || null)}</p>
                <p className="text-xs text-muted-foreground capitalize">{debate.creatorSide}</p>
              </div>
            </div>

            <div className="text-muted-foreground font-display font-bold text-xs px-2">VS</div>

            <div className="flex items-center gap-2 justify-end">
              <div className="text-sm text-right">
                <p className="font-medium text-foreground/90">{debate.opponent ? getDisplayName(debate.opponent) : "Waiting..."}</p>
                <p className="text-xs text-muted-foreground capitalize">
                  {debate.creatorSide === 'pro' ? 'Con' : 'Pro'}
                </p>
              </div>
              <UserAvatar user={debate.opponent || null} size="sm" className="border border-border" />
            </div>
          </div>
        </CardContent>

        <CardFooter className="pt-0 text-xs text-muted-foreground flex justify-between items-center border-t border-border/50 p-4 bg-muted/20">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {debate.createdAt ? formatDistanceToNow(new Date(debate.createdAt), { addSuffix: true }) : 'Just now'}
          </div>
          {debate.status === 'completed' && (
            <div className="flex items-center gap-1 text-accent font-bold">
              <Trophy className="w-3 h-3" />
              <span>Winner Declared</span>
            </div>
          )}
          {debate.status === 'active' && (
            <div className="flex items-center gap-1 text-green-400 font-bold animate-pulse">
              <Mic className="w-3 h-3" />
              <span>Live Now</span>
            </div>
          )}
        </CardFooter>
      </Card>
    </Link>
  );
}
