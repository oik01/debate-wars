import { Bell, BellOff, BellRing } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePushNotifications } from '@/hooks/use-push-notifications';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export function NotificationToggle() {
  const { isSupported, permission, isSubscribed, isLoading, subscribe, unsubscribe } = usePushNotifications();

  if (!isSupported) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="ghost" size="icon" disabled data-testid="button-notifications-unsupported">
            <BellOff className="h-5 w-5 text-muted-foreground" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Push notifications not supported in this browser</p>
        </TooltipContent>
      </Tooltip>
    );
  }

  if (permission === 'denied') {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="ghost" size="icon" disabled data-testid="button-notifications-denied">
            <BellOff className="h-5 w-5 text-muted-foreground" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Notifications blocked. Enable in browser settings.</p>
        </TooltipContent>
      </Tooltip>
    );
  }

  if (isSubscribed) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            onClick={unsubscribe}
            disabled={isLoading}
            data-testid="button-notifications-disable"
          >
            <BellRing className="h-5 w-5 text-primary" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Notifications enabled. Click to disable.</p>
        </TooltipContent>
      </Tooltip>
    );
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          onClick={subscribe}
          disabled={isLoading}
          data-testid="button-notifications-enable"
        >
          <Bell className="h-5 w-5" />
        </Button>
      </TooltipTrigger>
      <TooltipContent>
        <p>Enable notifications for debate updates</p>
      </TooltipContent>
    </Tooltip>
  );
}
