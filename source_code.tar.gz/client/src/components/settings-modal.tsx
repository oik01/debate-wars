import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Settings, Volume2, VolumeX, Music, Play, Pause, Film } from "lucide-react";
import { useMusic, MUSIC_TRACKS } from "@/hooks/use-music";
import { cn } from "@/lib/utils";

export function SettingsModal() {
  const { currentTrack, setTrack, isPlaying, togglePlayback, volume, setVolume } = useMusic();

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" data-testid="button-settings">
          <Settings className="h-5 w-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Settings
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium flex items-center gap-2">
                <Music className="h-4 w-4" />
                Background Music
              </h3>
              {currentTrack.url && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={togglePlayback}
                  data-testid="button-toggle-music"
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
              )}
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              {MUSIC_TRACKS.map((track) => (
                <div
                  key={track.id}
                  onClick={() => setTrack(track)}
                  data-testid={`music-track-${track.id}`}
                  className={cn(
                    "p-3 rounded-lg border-2 cursor-pointer transition-all flex items-center justify-between",
                    currentTrack.id === track.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/30 hover:bg-muted/30"
                  )}
                >
                  <span className="font-medium text-sm">{track.name}</span>
                  {currentTrack.id === track.id && isPlaying && track.url && (
                    <div className="flex gap-0.5">
                      <div className="w-1 h-3 bg-primary rounded-full animate-pulse" />
                      <div className="w-1 h-4 bg-primary rounded-full animate-pulse delay-75" />
                      <div className="w-1 h-2 bg-primary rounded-full animate-pulse delay-150" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {currentTrack.url && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium flex items-center gap-2">
                  {volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                  Volume
                </h3>
                <span className="text-xs text-muted-foreground">{Math.round(volume * 100)}%</span>
              </div>
              <Slider
                value={[volume]}
                onValueChange={([v]) => setVolume(v)}
                max={1}
                step={0.01}
                className="w-full"
                data-testid="slider-volume"
              />
            </div>
          )}

          <div className="space-y-3 pt-2 border-t">
            <h3 className="text-sm font-medium flex items-center gap-2">
              <Film className="h-4 w-4" />
              Intro Video
            </h3>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                sessionStorage.removeItem("hasSeenIntro");
                window.location.reload();
              }}
              data-testid="button-watch-intro"
            >
              Watch Intro Again
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
