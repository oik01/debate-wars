import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const CARTOON_AVATAR_DATA: Record<string, { bgColor: string; emoji: string }> = {
  cartoon1: { bgColor: "#4F46E5", emoji: "cat" },
  cartoon2: { bgColor: "#7C3AED", emoji: "owl" },
  cartoon3: { bgColor: "#DC2626", emoji: "lion" },
  cartoon4: { bgColor: "#EA580C", emoji: "fox" },
  cartoon5: { bgColor: "#65A30D", emoji: "bear" },
  cartoon6: { bgColor: "#0891B2", emoji: "eagle" },
  cartoon7: { bgColor: "#DB2777", emoji: "rabbit" },
  cartoon8: { bgColor: "#4338CA", emoji: "wolf" },
};

const ANIMAL_PATHS: Record<string, JSX.Element> = {
  cat: <g fill="white"><circle cx="50" cy="55" r="30" /><polygon points="25,30 35,55 15,55" /><polygon points="75,30 65,55 85,55" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="4" ry="3" fill="#333" /><path d="M46,68 Q50,72 54,68" stroke="#333" strokeWidth="2" fill="none" /></g>,
  owl: <g fill="white"><ellipse cx="50" cy="58" rx="28" ry="25" /><circle cx="38" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="62" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="38" cy="52" r="5" fill="#333" /><circle cx="62" cy="52" r="5" fill="#333" /><polygon points="50,60 46,70 54,70" fill="#F59E0B" /><polygon points="25,35 30,50 20,50" /><polygon points="75,35 70,50 80,50" /></g>,
  lion: <g><circle cx="50" cy="55" r="35" fill="#F59E0B" /><circle cx="50" cy="58" r="22" fill="white" /><circle cx="42" cy="52" r="4" fill="#333" /><circle cx="58" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="62" rx="5" ry="4" fill="#333" /><path d="M45,70 Q50,75 55,70" stroke="#333" strokeWidth="2" fill="none" /></g>,
  fox: <g fill="white"><ellipse cx="50" cy="58" rx="25" ry="22" /><polygon points="20,25 35,55 20,55" fill="#EA580C" /><polygon points="80,25 65,55 80,55" fill="#EA580C" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="64" rx="4" ry="3" fill="#333" /></g>,
  bear: <g fill="white"><circle cx="50" cy="55" r="28" /><circle cx="28" cy="35" r="10" /><circle cx="72" cy="35" r="10" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="8" ry="6" fill="#333" /></g>,
  eagle: <g fill="white"><ellipse cx="50" cy="55" rx="25" ry="28" /><circle cx="40" cy="48" r="4" fill="#333" /><circle cx="60" cy="48" r="4" fill="#333" /><polygon points="50,55 42,68 58,68" fill="#F59E0B" /><path d="M25,40 Q20,30 30,35" stroke="white" strokeWidth="4" fill="none" /><path d="M75,40 Q80,30 70,35" stroke="white" strokeWidth="4" fill="none" /></g>,
  rabbit: <g fill="white"><ellipse cx="50" cy="60" rx="22" ry="20" /><ellipse cx="38" cy="25" rx="8" ry="25" /><ellipse cx="62" cy="25" rx="8" ry="25" /><ellipse cx="38" cy="25" rx="4" ry="18" fill="#FFB6C1" /><ellipse cx="62" cy="25" rx="4" ry="18" fill="#FFB6C1" /><circle cx="42" cy="55" r="4" fill="#333" /><circle cx="58" cy="55" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="3" ry="2" fill="#FFB6C1" /></g>,
  wolf: <g fill="white"><ellipse cx="50" cy="58" rx="24" ry="22" /><polygon points="28,25 38,50 22,50" /><polygon points="72,25 62,50 78,50" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="6" ry="4" fill="#333" /></g>,
};

interface UserAvatarProps {
  user: {
    avatarType?: string | null;
    customAvatarUrl?: string | null;
    profileImageUrl?: string | null;
    firstName?: string | null;
    lastName?: string | null;
    email?: string | null;
    username?: string | null;
  } | null;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

export function UserAvatar({ user, size = "md", className = "" }: UserAvatarProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
    xl: "w-24 h-24",
  };
  
  const sizePx = {
    sm: 32,
    md: 48,
    lg: 64,
    xl: 96,
  };

  const getFallbackInitial = () => {
    if (user?.firstName) return user.firstName[0].toUpperCase();
    if (user?.username) return user.username[0].toUpperCase();
    if (user?.email) return user.email[0].toUpperCase();
    return "?";
  };

  if (!user) {
    return (
      <Avatar className={`${sizeClasses[size]} ${className}`}>
        <AvatarFallback>?</AvatarFallback>
      </Avatar>
    );
  }

  if (user.avatarType === "default" && user.customAvatarUrl) {
    const cartoonData = CARTOON_AVATAR_DATA[user.customAvatarUrl];
    if (cartoonData) {
      return (
        <svg
          width={sizePx[size]}
          height={sizePx[size]}
          viewBox="0 0 100 100"
          className={`rounded-full shadow-sm ${className}`}
        >
          <circle cx="50" cy="50" r="50" fill={cartoonData.bgColor} />
          {ANIMAL_PATHS[cartoonData.emoji]}
        </svg>
      );
    }
  }

  const imageUrl = user.avatarType === "custom" ? user.customAvatarUrl : user.profileImageUrl;

  return (
    <Avatar className={`${sizeClasses[size]} ${className}`}>
      <AvatarImage src={imageUrl || undefined} />
      <AvatarFallback className="text-lg bg-primary/20 text-primary">
        {getFallbackInitial()}
      </AvatarFallback>
    </Avatar>
  );
}

export { CARTOON_AVATAR_DATA, ANIMAL_PATHS };