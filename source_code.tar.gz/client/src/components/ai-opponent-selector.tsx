import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Shield, Zap, Crown, Star, ChevronDown, ChevronUp, Check } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { DebateSkillsChart } from "@/components/debate-skills-chart";
import type { AiOpponent } from "@shared/schema";

interface AiOpponentSelectorProps {
  selectedOpponent: AiOpponent | null;
  onSelect: (opponent: AiOpponent) => void;
}

const DIFFICULTY_CONFIG = {
  beginner: {
    label: "Beginner",
    icon: Shield,
    color: "bg-green-500/10 text-green-500 border-green-500/30",
    badgeVariant: "outline" as const,
  },
  intermediate: {
    label: "Intermediate",
    icon: Zap,
    color: "bg-blue-500/10 text-blue-500 border-blue-500/30",
    badgeVariant: "outline" as const,
  },
  expert: {
    label: "Expert",
    icon: Star,
    color: "bg-orange-500/10 text-orange-500 border-orange-500/30",
    badgeVariant: "outline" as const,
  },
  master: {
    label: "Master",
    icon: Crown,
    color: "bg-purple-500/10 text-purple-500 border-purple-500/30",
    badgeVariant: "outline" as const,
  },
};

const animalPaths: Record<string, JSX.Element> = {
  cat: (
    <g fill="white">
      <circle cx="50" cy="55" r="30" />
      <polygon points="25,30 35,55 15,55" />
      <polygon points="75,30 65,55 85,55" />
      <circle cx="40" cy="50" r="5" fill="#333" />
      <circle cx="60" cy="50" r="5" fill="#333" />
      <ellipse cx="50" cy="62" rx="4" ry="3" fill="#333" />
      <path d="M46,68 Q50,72 54,68" stroke="#333" strokeWidth="2" fill="none" />
    </g>
  ),
  owl: (
    <g fill="white">
      <ellipse cx="50" cy="58" rx="28" ry="25" />
      <circle cx="38" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" />
      <circle cx="62" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" />
      <circle cx="38" cy="52" r="5" fill="#333" />
      <circle cx="62" cy="52" r="5" fill="#333" />
      <polygon points="50,60 46,70 54,70" fill="#F59E0B" />
      <polygon points="25,35 30,50 20,50" />
      <polygon points="75,35 70,50 80,50" />
    </g>
  ),
  lion: (
    <g>
      <circle cx="50" cy="55" r="35" fill="#F59E0B" />
      <circle cx="50" cy="58" r="22" fill="white" />
      <circle cx="42" cy="52" r="4" fill="#333" />
      <circle cx="58" cy="52" r="4" fill="#333" />
      <ellipse cx="50" cy="62" rx="5" ry="4" fill="#333" />
      <path d="M45,70 Q50,75 55,70" stroke="#333" strokeWidth="2" fill="none" />
    </g>
  ),
  fox: (
    <g fill="white">
      <ellipse cx="50" cy="58" rx="25" ry="22" />
      <polygon points="20,25 35,55 20,55" fill="#EA580C" />
      <polygon points="80,25 65,55 80,55" fill="#EA580C" />
      <circle cx="40" cy="52" r="4" fill="#333" />
      <circle cx="60" cy="52" r="4" fill="#333" />
      <ellipse cx="50" cy="64" rx="4" ry="3" fill="#333" />
    </g>
  ),
  bear: (
    <g fill="white">
      <circle cx="50" cy="55" r="28" />
      <circle cx="28" cy="35" r="10" />
      <circle cx="72" cy="35" r="10" />
      <circle cx="40" cy="50" r="5" fill="#333" />
      <circle cx="60" cy="50" r="5" fill="#333" />
      <ellipse cx="50" cy="62" rx="8" ry="6" fill="#333" />
    </g>
  ),
  eagle: (
    <g fill="white">
      <ellipse cx="50" cy="55" rx="25" ry="28" />
      <circle cx="40" cy="48" r="4" fill="#333" />
      <circle cx="60" cy="48" r="4" fill="#333" />
      <polygon points="50,55 42,68 58,68" fill="#F59E0B" />
      <path d="M25,40 Q20,30 30,35" stroke="white" strokeWidth="4" fill="none" />
      <path d="M75,40 Q80,30 70,35" stroke="white" strokeWidth="4" fill="none" />
    </g>
  ),
  rabbit: (
    <g fill="white">
      <ellipse cx="50" cy="60" rx="22" ry="20" />
      <ellipse cx="38" cy="25" rx="8" ry="25" />
      <ellipse cx="62" cy="25" rx="8" ry="25" />
      <ellipse cx="38" cy="25" rx="4" ry="18" fill="#FFB6C1" />
      <ellipse cx="62" cy="25" rx="4" ry="18" fill="#FFB6C1" />
      <circle cx="42" cy="55" r="4" fill="#333" />
      <circle cx="58" cy="55" r="4" fill="#333" />
      <ellipse cx="50" cy="65" rx="3" ry="2" fill="#FFB6C1" />
    </g>
  ),
  wolf: (
    <g fill="white">
      <ellipse cx="50" cy="58" rx="25" ry="22" />
      <polygon points="22,20 35,50 22,50" />
      <polygon points="78,20 65,50 78,50" />
      <circle cx="40" cy="52" r="4" fill="#333" />
      <circle cx="60" cy="52" r="4" fill="#333" />
      <ellipse cx="50" cy="62" rx="6" ry="4" fill="#333" />
      <path d="M44,70 Q50,75 56,70" stroke="#333" strokeWidth="2" fill="none" />
    </g>
  ),
};

const AVATAR_EMOJI_MAP: Record<string, string> = {
  cartoon1: "cat",
  cartoon2: "owl",
  cartoon3: "lion",
  cartoon4: "fox",
  cartoon5: "bear",
  cartoon6: "eagle",
  cartoon7: "rabbit",
  cartoon8: "wolf",
};

function AiAvatar({ avatarId, bgColor, size = 48 }: { avatarId: string; bgColor: string; size?: number }) {
  const emoji = AVATAR_EMOJI_MAP[avatarId] || "cat";
  const path = animalPaths[emoji];
  
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className="rounded-full">
      <circle cx="50" cy="50" r="50" fill={bgColor} />
      {path}
    </svg>
  );
}

function OpponentCard({ 
  opponent, 
  isSelected, 
  onSelect 
}: { 
  opponent: AiOpponent; 
  isSelected: boolean; 
  onSelect: () => void;
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const config = DIFFICULTY_CONFIG[opponent.difficulty as keyof typeof DIFFICULTY_CONFIG] || DIFFICULTY_CONFIG.beginner;
  const Icon = config.icon;

  return (
    <Card 
      className={`cursor-pointer transition-all hover:border-primary/50 ${isSelected ? 'border-primary ring-2 ring-primary/20' : ''}`}
      onClick={onSelect}
      data-testid={`card-ai-opponent-${opponent.id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="relative shrink-0">
            <AiAvatar avatarId={opponent.avatarId} bgColor={opponent.bgColor} size={56} />
            {isSelected && (
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                <Check className="w-3 h-3 text-white" />
              </div>
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="font-bold text-sm">{opponent.name}</h4>
              <Badge variant={config.badgeVariant} className={`text-xs ${config.color}`}>
                <Icon className="w-3 h-3 mr-1" />
                {config.label}
              </Badge>
            </div>
            
            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
              <span>ELO: {opponent.eloRating}</span>
              <span>{opponent.wins}W - {opponent.losses}L</span>
            </div>

            {opponent.specialTrait && (
              <Badge variant="secondary" className="mt-2 text-xs">
                {opponent.specialTrait === 'flip_flops_positions' && 'Changes positions mid-debate!'}
                {opponent.specialTrait === 'accidentally_agrees' && 'Sometimes agrees by accident'}
                {opponent.specialTrait === 'rambles' && 'Tends to go off-topic'}
              </Badge>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              className="mt-2 h-6 text-xs px-2"
              onClick={(e) => {
                e.stopPropagation();
                setIsExpanded(!isExpanded);
              }}
              data-testid={`button-expand-opponent-${opponent.id}`}
            >
              {isExpanded ? (
                <>Hide Details <ChevronUp className="w-3 h-3 ml-1" /></>
              ) : (
                <>View Details <ChevronDown className="w-3 h-3 ml-1" /></>
              )}
            </Button>
          </div>
        </div>

        {isExpanded && (
          <div className="mt-4 pt-4 border-t space-y-4">
            <p className="text-sm text-muted-foreground">{opponent.personality}</p>
            
            <div className="flex justify-center">
              <DebateSkillsChart
                logic={opponent.logicSkill}
                evidence={opponent.evidenceSkill}
                persuasion={opponent.persuasionSkill}
                rebuttals={opponent.rebuttalsSkill}
                size={160}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function AiOpponentSelector({ selectedOpponent, onSelect }: AiOpponentSelectorProps) {
  const [filterDifficulty, setFilterDifficulty] = useState<string | null>(null);
  
  const { data: opponents, isLoading } = useQuery<AiOpponent[]>({
    queryKey: ['/api/ai-opponents'],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
        <span className="ml-2 text-muted-foreground">Loading AI opponents...</span>
      </div>
    );
  }

  const filteredOpponents = filterDifficulty 
    ? opponents?.filter(o => o.difficulty === filterDifficulty)
    : opponents;

  const difficulties = ['beginner', 'intermediate', 'expert', 'master'];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Choose Your AI Opponent</h3>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button
          variant={filterDifficulty === null ? "default" : "outline"}
          size="sm"
          onClick={() => setFilterDifficulty(null)}
          data-testid="button-filter-all"
        >
          All
        </Button>
        {difficulties.map((diff) => {
          const config = DIFFICULTY_CONFIG[diff as keyof typeof DIFFICULTY_CONFIG];
          const Icon = config.icon;
          return (
            <Button
              key={diff}
              variant={filterDifficulty === diff ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterDifficulty(diff)}
              data-testid={`button-filter-${diff}`}
            >
              <Icon className="w-3 h-3 mr-1" />
              {config.label}
            </Button>
          );
        })}
      </div>

      <div className="grid gap-3 max-h-[400px] overflow-y-auto pr-1">
        {filteredOpponents?.map((opponent) => (
          <OpponentCard
            key={opponent.id}
            opponent={opponent}
            isSelected={selectedOpponent?.id === opponent.id}
            onSelect={() => onSelect(opponent)}
          />
        ))}
      </div>

      {selectedOpponent && (
        <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
          <div className="flex items-center gap-3">
            <AiAvatar avatarId={selectedOpponent.avatarId} bgColor={selectedOpponent.bgColor} size={40} />
            <div>
              <div className="font-medium text-sm">Selected: {selectedOpponent.name}</div>
              <div className="text-xs text-muted-foreground">
                {DIFFICULTY_CONFIG[selectedOpponent.difficulty as keyof typeof DIFFICULTY_CONFIG]?.label || selectedOpponent.difficulty} - ELO {selectedOpponent.eloRating}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
