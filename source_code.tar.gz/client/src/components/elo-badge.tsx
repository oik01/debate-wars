import { Badge } from "@/components/ui/badge";
import { Trophy, Shield, Star, Crown, Gem } from "lucide-react";

interface EloBadgeProps {
  elo: number;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
  className?: string;
  "data-testid"?: string;
}

type TierInfo = {
  name: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: typeof Trophy;
  minElo: number;
};

const TIERS: TierInfo[] = [
  { name: "Bronze", color: "text-orange-700", bgColor: "bg-orange-100 dark:bg-orange-950", borderColor: "border-orange-400", icon: Shield, minElo: 0 },
  { name: "Silver", color: "text-slate-500", bgColor: "bg-slate-100 dark:bg-slate-800", borderColor: "border-slate-400", icon: Shield, minElo: 1100 },
  { name: "Gold", color: "text-yellow-600", bgColor: "bg-yellow-100 dark:bg-yellow-950", borderColor: "border-yellow-400", icon: Star, minElo: 1300 },
  { name: "Diamond", color: "text-cyan-500", bgColor: "bg-cyan-100 dark:bg-cyan-950", borderColor: "border-cyan-400", icon: Gem, minElo: 1500 },
  { name: "Master", color: "text-purple-500", bgColor: "bg-purple-100 dark:bg-purple-950", borderColor: "border-purple-400", icon: Crown, minElo: 1800 },
];

export function getTier(elo: number): TierInfo {
  for (let i = TIERS.length - 1; i >= 0; i--) {
    if (elo >= TIERS[i].minElo) {
      return TIERS[i];
    }
  }
  return TIERS[0];
}

export function EloBadge({ elo, size = "md", showLabel = true, className = "", "data-testid": testId }: EloBadgeProps) {
  const tier = getTier(elo);
  const Icon = tier.icon;
  
  const iconSizes = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5",
  };
  
  const textSizes = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  };

  return (
    <Badge 
      variant="outline" 
      className={`${tier.bgColor} ${tier.borderColor} ${tier.color} border ${textSizes[size]} gap-1 ${className}`}
      data-testid={testId}
    >
      <Icon className={iconSizes[size]} />
      {showLabel && <span>{tier.name}</span>}
      <span className="font-mono font-bold">{elo}</span>
    </Badge>
  );
}

export function TierIcon({ elo, size = "md", className = "" }: { elo: number; size?: "sm" | "md" | "lg"; className?: string }) {
  const tier = getTier(elo);
  const Icon = tier.icon;
  
  const iconSizes = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  };

  return (
    <div className={`inline-flex items-center justify-center rounded-full p-1 ${tier.bgColor} ${tier.borderColor} border ${className}`}>
      <Icon className={`${iconSizes[size]} ${tier.color}`} />
    </div>
  );
}
