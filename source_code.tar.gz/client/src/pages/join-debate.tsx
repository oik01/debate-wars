import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, Swords, Check, LogIn } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";

export default function JoinDebate() {
  const { code } = useParams<{ code: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, isLoading: authLoading } = useAuth();

  const { data: debate, isLoading, error } = useQuery<any>({
    queryKey: ["/api/debates/invite", code],
    enabled: !!code,
  });

  const joinDebate = useMutation({
    mutationFn: () => apiRequest("POST", `/api/debates/${debate?.id}/join`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/debates"] });
      toast({
        title: "Joined debate!",
        description: "Get ready to make your arguments.",
      });
      navigate(`/debate/${debate?.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to join debate",
        variant: "destructive",
      });
    },
  });

  if (isLoading || authLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !debate) {
    return (
      <div className="max-w-md mx-auto text-center py-20" data-testid="container-not-found">
        <h1 className="text-2xl font-bold mb-4" data-testid="text-not-found-title">Debate Not Found</h1>
        <p className="text-muted-foreground mb-6" data-testid="text-not-found-message">This debate link may be invalid or expired.</p>
        <Button onClick={() => navigate("/")} data-testid="button-go-home">Go Home</Button>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-md mx-auto py-12">
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Swords className="w-8 h-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">You've Been Challenged!</CardTitle>
            <CardDescription>
              Sign in to join this debate
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted/50 rounded-xl p-4" data-testid="container-topic-info">
              <div className="text-sm text-muted-foreground mb-1">Topic</div>
              <div className="font-bold" data-testid="text-topic">{debate.topic}</div>
            </div>

            <div className="flex items-center gap-4" data-testid="container-creator-info">
              <Avatar className="w-12 h-12">
                <AvatarImage src={debate.creator?.profileImageUrl || undefined} />
                <AvatarFallback>
                  {(debate.creator?.firstName?.[0] || debate.creator?.email?.[0] || '?').toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium" data-testid="text-creator-name">
                  {debate.creator?.firstName && debate.creator?.lastName 
                    ? `${debate.creator.firstName} ${debate.creator.lastName}`
                    : debate.creator?.email || 'Unknown'}
                </div>
                <div className="text-sm text-muted-foreground" data-testid="text-creator-elo">
                  ELO: {debate.creator?.eloRating || '1000'}
                </div>
              </div>
            </div>

            <Button 
              className="w-full" 
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-signin-to-join"
            >
              <LogIn className="w-4 h-4 mr-2" />
              Sign In to Accept Challenge
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (debate.status !== 'waiting') {
    return (
      <div className="max-w-md mx-auto text-center py-20" data-testid="container-already-started">
        <h1 className="text-2xl font-bold mb-4" data-testid="text-already-started">Debate Already Started</h1>
        <p className="text-muted-foreground mb-6">This debate is no longer accepting challengers.</p>
        <Button onClick={() => navigate(`/debate/${debate.id}`)} data-testid="button-watch-debate">
          Watch Debate
        </Button>
      </div>
    );
  }

  if (debate.creatorId === user.id) {
    return (
      <div className="max-w-md mx-auto text-center py-20" data-testid="container-own-debate">
        <h1 className="text-2xl font-bold mb-4" data-testid="text-own-debate">This is Your Debate</h1>
        <p className="text-muted-foreground mb-6">Share this link with someone else to challenge them.</p>
        <Button onClick={() => navigate(`/debate/${debate.id}`)} data-testid="button-go-to-room">
          Go to Debate Room
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto py-12">
      <Card>
        <CardHeader className="text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Swords className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">Accept the Challenge?</CardTitle>
          <CardDescription>
            {debate.creator?.firstName || 'Someone'} wants to debate you
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-muted/50 rounded-xl p-4" data-testid="container-debate-topic">
            <div className="text-sm text-muted-foreground mb-1">Topic</div>
            <div className="font-bold text-lg" data-testid="text-debate-topic">{debate.topic}</div>
            <div className="text-sm text-muted-foreground mt-2" data-testid="text-debate-category">
              Category: {debate.category}
            </div>
          </div>

          <div className="flex items-center gap-4 p-4 border rounded-xl">
            <Avatar className="w-12 h-12">
              <AvatarImage src={debate.creator?.profileImageUrl || undefined} />
              <AvatarFallback>
                {(debate.creator?.firstName?.[0] || debate.creator?.email?.[0] || '?').toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="font-medium">
                {debate.creator?.firstName && debate.creator?.lastName 
                  ? `${debate.creator.firstName} ${debate.creator.lastName}`
                  : debate.creator?.email || 'Unknown'}
              </div>
              <div className="text-sm text-muted-foreground">
                ELO: {debate.creator?.eloRating || '1000'} | Side: {debate.creatorSide.toUpperCase()}
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-xl p-4">
            <h4 className="font-medium mb-2">Debate Format</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>Round 1: 60 seconds each</li>
              <li>Round 2: 60 seconds each</li>
              <li>Round 3: 30 seconds each (order reversed)</li>
            </ul>
          </div>

          <div className="flex gap-3">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => navigate("/")}
              data-testid="button-decline"
            >
              Decline
            </Button>
            <Button
              className="flex-1"
              onClick={() => joinDebate.mutate()}
              disabled={joinDebate.isPending}
              data-testid="button-accept-challenge"
            >
              {joinDebate.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Check className="h-4 w-4 mr-2" />
              )}
              Accept Challenge
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
