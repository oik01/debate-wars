import { useAuth } from "@/hooks/use-auth";
import { useDebates } from "@/hooks/use-debates";
import { useQuery } from "@tanstack/react-query";
import { DebateCard } from "@/components/debate-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { EloBadge } from "@/components/elo-badge";
import { CountryFlag } from "@/components/country-flag";
import { UserAvatar } from "@/components/user-avatar";
import { Loader2, Mic2, Flame, Globe2, Plus, ChevronLeft, ChevronRight, Trophy, BarChart, TrendingUp, Crown, Swords } from "lucide-react";
import { Link } from "wouter";
import { useRef } from "react";

interface UserProfile {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  avatarType: string | null;
  customAvatarUrl: string | null;
  eloRating: string | null;
  wins: string | null;
  losses: string | null;
  nationality: string | null;
  rank: number;
}

// Landing Page Component
function LandingPage() {
  return (
    <div className="min-h-[calc(100vh-64px)] grid grid-cols-1 lg:grid-cols-2">
      {/* Left Branding Side */}
      <div className="flex flex-col justify-center p-8 lg:p-24 bg-background relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        
        <div className="relative z-10 space-y-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
             <span className="relative flex h-2 w-2">
               <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
               <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
             </span>
             AI-Powered Judging Live Now
          </div>
          
          <h1 className="text-5xl lg:text-7xl font-display font-bold tracking-tight leading-[1.1]">
            Debate <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Anyone,</span> <br />
            Anytime.
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-md leading-relaxed">
            Challenge friends or strangers to audio debates. 
            Google Gemini acts as the impartial judge to decide who wins based on logic and persuasion.
          </p>

          <div className="flex gap-4">
             <Button 
               size="lg" 
               className="h-14 px-8 text-lg font-bold bg-white text-black hover:bg-gray-200 shadow-xl shadow-white/5 transition-all hover:scale-105"
               onClick={() => window.location.href = "/api/login"}
             >
               Start Debating
             </Button>
             <Button variant="outline" size="lg" className="h-14 px-8 text-lg border-white/10 hover:bg-white/5">
               Watch Live
             </Button>
          </div>
        </div>
      </div>

      {/* Right Feature/Visual Side */}
      <div className="hidden lg:flex items-center justify-center bg-muted/10 border-l border-white/5 relative">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[length:40px_40px]" />
        
        {/* Abstract shapes */}
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-primary/20 rounded-full blur-[100px]" />
        <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-secondary/20 rounded-full blur-[100px]" />

        <div className="relative z-10 max-w-md space-y-6">
          <div className="bg-card/50 backdrop-blur-xl border border-white/10 p-6 rounded-2xl shadow-2xl animate-float">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-orange-400 to-red-500" />
              <div className="h-2 w-24 bg-white/10 rounded" />
              <div className="ml-auto text-xs font-mono text-green-400">WINNER</div>
            </div>
            <div className="space-y-2">
              <div className="h-2 w-full bg-white/5 rounded" />
              <div className="h-2 w-5/6 bg-white/5 rounded" />
              <div className="h-2 w-4/6 bg-white/5 rounded" />
            </div>
            <div className="mt-4 pt-4 border-t border-white/5 text-xs text-muted-foreground">
              <div className="flex gap-2 items-center">
                <Mic2 className="w-3 h-3" />
                <span>AI Analyzing argument structure...</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Live Debates Horizontal Scrolling Section
function LiveDebatesSection({ debates, isLoading }: { debates: any[] | undefined, isLoading: boolean }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 340; // Card width + gap
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  // Sort debates by latest interaction (most recent first)
  const sortedDebates = debates?.slice().sort((a, b) => {
    const aLatest = a.turns?.length ? new Date(a.turns[a.turns.length - 1].createdAt).getTime() : new Date(a.createdAt).getTime();
    const bLatest = b.turns?.length ? new Date(b.turns[b.turns.length - 1].createdAt).getTime() : new Date(b.createdAt).getTime();
    return bLatest - aLatest;
  });

  return (
    <section>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-red-500/10 rounded-lg text-red-500">
            <Flame className="w-5 h-5" />
          </div>
          <h2 className="text-2xl font-bold">Live Debates</h2>
        </div>
        
        {sortedDebates && sortedDebates.length > 0 && (
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="icon" 
              className="h-8 w-8"
              onClick={() => scroll('left')}
              data-testid="button-scroll-left"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-8 w-8"
              onClick={() => scroll('right')}
              data-testid="button-scroll-right"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
      
      {isLoading ? (
        <div className="flex gap-4 overflow-hidden">
          <div className="h-48 w-80 shrink-0 bg-muted/20 animate-pulse rounded-xl" />
          <div className="h-48 w-80 shrink-0 bg-muted/20 animate-pulse rounded-xl" />
          <div className="h-48 w-80 shrink-0 bg-muted/20 animate-pulse rounded-xl" />
        </div>
      ) : sortedDebates?.length === 0 ? (
        <div className="py-12 text-center border-2 border-dashed border-border rounded-xl bg-muted/5">
          <p className="text-muted-foreground">No active debates right now.</p>
        </div>
      ) : (
        <div 
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          data-testid="container-live-debates"
        >
          {sortedDebates?.map((debate) => (
            <div key={debate.id} className="shrink-0 w-80 snap-start">
              <DebateCard debate={debate} />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

// Open Challenges Horizontal Scrolling Section
function OpenChallengesSection({ debates, isLoading }: { debates: any[] | undefined, isLoading: boolean }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 340;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  // Sort by most recent first
  const sortedDebates = debates?.slice().sort((a, b) => {
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <section>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500">
            <Globe2 className="w-5 h-5" />
          </div>
          <h2 className="text-2xl font-bold">Open Challenges</h2>
        </div>
        
        {sortedDebates && sortedDebates.length > 0 && (
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="icon" 
              className="h-8 w-8"
              onClick={() => scroll('left')}
              data-testid="button-challenges-scroll-left"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-8 w-8"
              onClick={() => scroll('right')}
              data-testid="button-challenges-scroll-right"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
      
      {isLoading ? (
        <div className="flex gap-4 overflow-hidden">
          <div className="h-48 w-80 shrink-0 bg-muted/20 animate-pulse rounded-xl" />
          <div className="h-48 w-80 shrink-0 bg-muted/20 animate-pulse rounded-xl" />
          <div className="h-48 w-80 shrink-0 bg-muted/20 animate-pulse rounded-xl" />
        </div>
      ) : sortedDebates?.length === 0 ? (
        <div className="py-12 text-center border-2 border-dashed border-border rounded-xl bg-muted/5">
          <p className="text-muted-foreground">No open challenges available.</p>
        </div>
      ) : (
        <div 
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          data-testid="container-open-challenges"
        >
          {sortedDebates?.map((debate) => (
            <div key={debate.id} className="shrink-0 w-80 snap-start">
              <DebateCard debate={debate} />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

// Authenticated Home Component
function Dashboard() {
  const { data: activeDebates, isLoading: loadingActive } = useDebates('active');
  const { data: waitingDebates, isLoading: loadingWaiting } = useDebates('waiting');
  const { data: profile } = useQuery<UserProfile>({
    queryKey: ["/api/me"],
  });

  const eloRating = parseInt(profile?.eloRating || "1000");
  const wins = parseInt(profile?.wins || "0");
  const losses = parseInt(profile?.losses || "0");
  const totalGames = wins + losses;
  const winRate = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;

  return (
    <div className="space-y-12">
      {/* Quick Stats Summary */}
      {profile && (
        <section>
          <Card className="bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20" data-testid="card-stats-summary">
            <CardContent className="py-4">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="relative" data-testid="home-avatar-container">
                    <UserAvatar user={profile} size="md" className="border-2 border-primary" />
                    {profile.nationality && (
                      <div className="absolute -bottom-1 -right-1" data-testid="home-flag">
                        <CountryFlag code={profile.nationality} size="sm" />
                      </div>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold" data-testid="home-username">{profile.firstName} {profile.lastName}</span>
                      <EloBadge elo={eloRating} size="sm" data-testid="home-elo-badge" />
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Crown className="w-3 h-3" />
                      <span data-testid="home-rank">Rank #{profile.rank}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-6 flex-wrap">
                  <div className="text-center">
                    <div className="text-xl font-bold text-primary" data-testid="home-elo">{eloRating}</div>
                    <div className="text-xs text-muted-foreground">ELO</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold" data-testid="home-wl">
                      <span className="text-primary">{wins}</span>
                      <span className="text-muted-foreground">/</span>
                      <span className="text-destructive">{losses}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">W/L</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold" data-testid="home-winrate">{winRate}%</div>
                    <div className="text-xs text-muted-foreground">Win Rate</div>
                  </div>
                  <Link href="/profile">
                    <Button variant="outline" size="sm" data-testid="link-view-profile">
                      <BarChart className="w-4 h-4 mr-2" />
                      Full Stats
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      {/* Create New Debate Section */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Link href="/create">
          <div className="group cursor-pointer p-6 rounded-2xl border-2 border-dashed border-primary/30 bg-gradient-to-br from-primary/5 to-primary/10 hover:border-primary/60 hover:from-primary/10 hover:to-primary/20 transition-all h-full">
            <div className="flex flex-col h-full">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-primary/20 rounded-xl text-primary group-hover:scale-110 transition-transform">
                  <Plus className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">Create New Debate</h2>
                  <p className="text-sm text-muted-foreground">Challenge the world to a battle of wits</p>
                </div>
              </div>
              <div className="mt-auto">
                <Button size="default" className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25">
                  Get Started
                </Button>
              </div>
            </div>
          </div>
        </Link>
        
        <Link href="/world-challenge">
          <div className="group cursor-pointer p-6 rounded-2xl border-2 border-dashed border-yellow-500/30 bg-gradient-to-br from-yellow-500/5 to-orange-500/10 hover:border-yellow-500/60 hover:from-yellow-500/10 hover:to-orange-500/20 transition-all h-full" data-testid="link-world-challenge">
            <div className="flex flex-col h-full">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-yellow-500/20 rounded-xl text-yellow-500 group-hover:scale-110 transition-transform">
                  <Trophy className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">Discover the World Challenge</h2>
                  <p className="text-sm text-muted-foreground">Tournament mode - 3 rounds, 30 min prep</p>
                </div>
              </div>
              <div className="mt-auto">
                <Button size="default" className="bg-yellow-500 text-black hover:bg-yellow-400 shadow-lg shadow-yellow-500/25">
                  Join Challenge
                </Button>
              </div>
            </div>
          </div>
        </Link>
        
        <Link href="/political-arena">
          <div className="group cursor-pointer p-6 rounded-2xl border-2 border-dashed border-blue-500/30 bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-red-500/10 hover:border-purple-500/60 hover:from-blue-500/10 hover:via-purple-500/10 hover:to-red-500/20 transition-all h-full" data-testid="link-political-arena">
            <div className="flex flex-col h-full">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-gradient-to-br from-blue-500/20 to-red-500/20 rounded-xl group-hover:scale-110 transition-transform">
                  <Swords className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">Political Arena</h2>
                  <p className="text-sm text-muted-foreground">Democrat vs Republican debates</p>
                </div>
              </div>
              <div className="mt-auto">
                <Button size="default" className="bg-gradient-to-r from-blue-600 to-red-600 hover:from-blue-500 hover:to-red-500 shadow-lg shadow-purple-500/25">
                  Enter Arena
                </Button>
              </div>
            </div>
          </div>
        </Link>
      </section>

      {/* Active Debates - Horizontal Swipeable Row */}
      <LiveDebatesSection debates={activeDebates} isLoading={loadingActive} />


      {/* Open Challenges - Horizontal Swipeable Row */}
      <OpenChallengesSection debates={waitingDebates} isLoading={loadingWaiting} />
    </div>
  );
}

export default function Home() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;
  }

  if (!isAuthenticated) {
    return <LandingPage />;
  }

  return <Dashboard />;
}
