import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserAvatar } from "@/components/user-avatar";
import { ClickableAvatar } from "@/components/clickable-avatar";
import { EloBadge } from "@/components/elo-badge";
import { CountryFlag } from "@/components/country-flag";
import { Trophy, Medal, Award, Crown, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

interface LeaderboardUser {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  avatarType: string | null;
  customAvatarUrl: string | null;
  eloRating: string | null;
  wins: string | null;
  losses: string | null;
  nationality: string | null;
  rank?: number;
}

export default function Leaderboard() {
  const { user } = useAuth();
  
  const { data: leaderboard, isLoading } = useQuery<LeaderboardUser[]>({
    queryKey: ["/api/leaderboard"],
  });

  const { data: myProfile } = useQuery<LeaderboardUser & { rank: number }>({
    queryKey: ["/api/me"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />;
      default:
        return <span className="w-6 text-center font-bold text-muted-foreground">#{rank}</span>;
    }
  };

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-gradient-to-r from-yellow-500/20 to-yellow-600/10 border-yellow-500/30";
      case 2:
        return "bg-gradient-to-r from-gray-400/20 to-gray-500/10 border-gray-400/30";
      case 3:
        return "bg-gradient-to-r from-amber-600/20 to-amber-700/10 border-amber-600/30";
      default:
        return "";
    }
  };

  return (
    <div className="container max-w-3xl py-8 px-4 space-y-6">
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2">
          <Trophy className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">World Leaderboard</h1>
        </div>
        <p className="text-muted-foreground">Top debaters ranked by ELO rating</p>
      </div>

      {myProfile && (
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/20">
                  <TrendingUp className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Your Rank</p>
                  <p className="text-xl font-bold" data-testid="text-my-rank">#{myProfile.rank}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Your ELO</p>
                <p className="text-xl font-bold text-primary" data-testid="text-my-elo">{myProfile.eloRating || "1000"}</p>
              </div>
              <Link href="/profile">
                <Button variant="outline" size="sm" data-testid="link-my-profile">
                  View Profile
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Top 50 Debaters
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {leaderboard?.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>No rankings yet. Be the first to compete!</p>
            </div>
          ) : (
            <div className="divide-y">
              {leaderboard?.map((player) => {
                // Use the rank from the API (DENSE_RANK) for consistency with the "Your Rank" ribbon
                const rank = player.rank!;
                const wins = parseInt(player.wins || "0");
                const losses = parseInt(player.losses || "0");
                const totalGames = wins + losses;
                const winRate = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;
                const isCurrentUser = user && player.id === (user as any).claims?.sub;

                return (
                  <div
                    key={player.id}
                    className={`flex items-center gap-4 p-4 ${getRankBg(rank)} ${isCurrentUser ? "bg-primary/10" : ""}`}
                    data-testid={`leaderboard-row-${rank}`}
                  >
                    <div className="w-10 flex justify-center">
                      {getRankIcon(rank)}
                    </div>
                    
                    <div className="relative" data-testid={`avatar-container-${rank}`}>
                      <ClickableAvatar 
                        user={player} 
                        size="md" 
                        currentUserId={user?.id}
                        className={`${rank <= 3 ? "border-2" : ""} ${rank === 1 ? "border-yellow-500" : rank === 2 ? "border-gray-400" : rank === 3 ? "border-amber-600" : ""}`}
                      />
                      {player.nationality && (
                        <div className="absolute -bottom-1 -right-1" data-testid={`flag-${rank}`}>
                          <CountryFlag code={player.nationality} size="sm" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold truncate" data-testid={`name-${rank}`}>
                          {player.firstName} {player.lastName}
                        </p>
                        <EloBadge elo={parseInt(player.eloRating || "1000")} size="sm" data-testid={`elo-badge-${rank}`} />
                        {isCurrentUser && (
                          <Badge variant="secondary" className="text-xs">You</Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground">
                        <span className="text-primary">{wins}W</span>
                        <span className="text-destructive">{losses}L</span>
                        <span>{winRate}% WR</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">{player.eloRating || "1000"}</p>
                      <p className="text-xs text-muted-foreground">ELO</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Link href="/">
          <Button variant="outline" data-testid="link-back-home">
            Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}
