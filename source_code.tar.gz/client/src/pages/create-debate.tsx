import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useTopics, useCreateDebate } from "@/hooks/use-debates";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Loader2, ArrowRight, Check, Trophy, TrendingUp, Newspaper, Briefcase, LandPlot, Plus, Zap, Brain, Lightbulb, Target, Users, UserPlus, Bot, Globe, Search, Copy, Link2 } from "lucide-react";
import { UserAvatar } from "@/components/user-avatar";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { AiOpponentSelector } from "@/components/ai-opponent-selector";
import type { AiOpponent } from "@shared/schema";

import { useQuery } from "@tanstack/react-query";
import { Sparkles, Hash } from "lucide-react";

const LOADING_FACTS = [
  { icon: Brain, text: "The word 'debate' comes from Old French 'debatre' meaning to fight or contend" },
  { icon: Zap, text: "The average winning argument uses 3 supporting points" },
  { icon: Lightbulb, text: "Active listening can improve your counterarguments by 60%" },
  { icon: Target, text: "The best debaters anticipate opposing arguments before they're made" },
  { icon: Trophy, text: "Winston Churchill practiced speeches for 1 hour per minute of delivery" },
  { icon: Brain, text: "Studies show that debate improves critical thinking by 25%" },
  { icon: Zap, text: "The Lincoln-Douglas debates lasted 3 hours each!" },
  { icon: Lightbulb, text: "Using analogies makes arguments 40% more memorable" },
  { icon: Target, text: "Top debaters pause strategically to emphasize key points" },
  { icon: Trophy, text: "Ancient Greeks invented formal debate over 2,500 years ago" },
];

const CATEGORY_LOADING_FACTS = [
  { icon: Globe, text: "There are over 100 debate formats used worldwide" },
  { icon: Brain, text: "Debating activates both hemispheres of the brain simultaneously" },
  { icon: Sparkles, text: "AI analyzes trending news to find the hottest debate topics" },
  { icon: Target, text: "Categories help focus arguments and make debates more productive" },
  { icon: Trophy, text: "The Oxford Union has hosted debates since 1823" },
  { icon: Zap, text: "Structured categories improve argument quality by 35%" },
  { icon: Lightbulb, text: "The best debate topics have strong arguments on both sides" },
  { icon: Brain, text: "Exploring different categories expands your knowledge horizons" },
  { icon: Globe, text: "Cross-cultural debates lead to greater understanding" },
  { icon: Sparkles, text: "Fresh categories are generated daily based on current events" },
];

function LoadingFacts() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % LOADING_FACTS.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const fact = LOADING_FACTS[currentIndex];
  const Icon = fact.icon;

  return (
    <div className="flex flex-col items-center justify-center py-16 px-4">
      <div className="relative mb-8">
        <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
        </div>
        <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary/20 animate-ping" />
      </div>
      
      <h3 className="text-lg font-semibold text-foreground mb-2">AI is researching topics...</h3>
      <p className="text-sm text-muted-foreground mb-8">Finding the most debatable topics for you</p>
      
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="max-w-md text-center"
        >
          <div className="inline-flex items-center gap-3 px-6 py-4 rounded-xl bg-muted/50 border border-border">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <Icon className="w-5 h-5" />
            </div>
            <p className="text-sm text-muted-foreground">{fact.text}</p>
          </div>
        </motion.div>
      </AnimatePresence>
      
      <div className="flex gap-1 mt-6">
        {LOADING_FACTS.slice(0, 5).map((_, i) => (
          <div
            key={i}
            className={`w-2 h-2 rounded-full transition-colors ${
              i === currentIndex % 5 ? 'bg-primary' : 'bg-muted'
            }`}
          />
        ))}
      </div>
    </div>
  );
}

function LoadingCategoriesFacts() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % CATEGORY_LOADING_FACTS.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const fact = CATEGORY_LOADING_FACTS[currentIndex];
  const Icon = fact.icon;

  return (
    <div className="flex flex-col items-center justify-center py-16 px-4">
      <div className="relative mb-8">
        <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
        </div>
        <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary/20 animate-ping" />
      </div>
      
      <h3 className="text-lg font-semibold text-foreground mb-2">AI is researching categories...</h3>
      <p className="text-sm text-muted-foreground mb-8">Discovering the hottest debate topics for you</p>
      
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="max-w-md text-center"
        >
          <div className="inline-flex items-center gap-3 px-6 py-4 rounded-xl bg-muted/50 border border-border">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <Icon className="w-5 h-5" />
            </div>
            <p className="text-sm text-muted-foreground">{fact.text}</p>
          </div>
        </motion.div>
      </AnimatePresence>
      
      <div className="flex gap-1 mt-6">
        {CATEGORY_LOADING_FACTS.slice(0, 5).map((_, i) => (
          <div
            key={i}
            className={`w-2 h-2 rounded-full transition-colors ${
              i === currentIndex % 5 ? 'bg-primary' : 'bg-muted'
            }`}
          />
        ))}
      </div>
    </div>
  );
}

// Use lucide-react icons that are more generic or fun
const CATEGORY_ICONS: Record<string, any> = {
  default: Hash,
};

interface Friend {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  eloRating: string | null;
  avatarType?: string | null;
  customAvatarUrl?: string | null;
}

export default function CreateDebate() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [selectedSide, setSelectedSide] = useState<"pro" | "con">("pro");
  const [opponentType, setOpponentType] = useState<"open" | "friend" | "ai">("open");
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null);
  const [selectedAiOpponent, setSelectedAiOpponent] = useState<AiOpponent | null>(null);
  const [friendSearch, setFriendSearch] = useState("");
  const [createdDebate, setCreatedDebate] = useState<any>(null);

  const [customTopic, setCustomTopic] = useState("");
  const [useInviteLink, setUseInviteLink] = useState(false);
  const [customCategoryName, setCustomCategoryName] = useState("");
  const [confirmedCustomCategory, setConfirmedCustomCategory] = useState("");
  const [isCustomTopicMode, setIsCustomTopicMode] = useState(false);
  // Track which category name topics were generated for to prevent stale data
  const [topicsGeneratedForCategory, setTopicsGeneratedForCategory] = useState<string>("");

  const { data: categories, isLoading: isLoadingCategories } = useQuery<string[]>({
    queryKey: ["/api/categories"],
  });

  // Use CONFIRMED custom category for AI topic generation (not live typing)
  // This prevents topic generation while the user is still typing
  const categoryForTopics = selectedCategory === 'custom' ? confirmedCustomCategory : selectedCategory;
  const { data: topics, isLoading: isLoadingTopics, refetch: refetchTopics } = useTopics(
    categoryForTopics && categoryForTopics !== 'custom' ? categoryForTopics : undefined
  );
  const { mutate: createDebate, isPending: isCreating } = useCreateDebate();
  
  // Track when topics are successfully loaded for a category
  useEffect(() => {
    if (topics && topics.length > 0 && categoryForTopics) {
      setTopicsGeneratedForCategory(categoryForTopics);
    }
  }, [topics, categoryForTopics]);
  

  // Fetch user's friends and rivals
  const { data: meData } = useQuery<{ friends: Friend[], enemies: Friend[] }>({
    queryKey: ["/api/me"],
    enabled: !!user,
  });

  // Search all users in database
  const { data: searchResults, isLoading: isSearching } = useQuery<Friend[]>({
    queryKey: ["/api/users", friendSearch],
    queryFn: async () => {
      if (friendSearch.length < 2) return [];
      const res = await fetch(`/api/users?q=${encodeURIComponent(friendSearch)}`);
      return res.json();
    },
    enabled: friendSearch.length >= 2 && opponentType === 'friend' && !useInviteLink,
  });

  // Show search results if searching, otherwise show friends/rivals
  const allContacts = friendSearch.length >= 2 
    ? (searchResults || []).filter(u => u.id !== user?.id)
    : [...(meData?.friends || []), ...(meData?.enemies || [])].filter(u => u.id !== user?.id);

  const handleCreate = () => {
    if (!user) return;
    
    // Determine target user - only use invite link mode when in friend mode
    const isInviteLinkMode = opponentType === 'friend' && useInviteLink;
    const targetUser = isInviteLinkMode ? undefined : (selectedFriend?.id || undefined);
    
    // Determine the actual category and topic
    const actualCategory = selectedCategory === 'custom' ? confirmedCustomCategory : selectedCategory;
    // Use customTopic only if in custom topic mode, otherwise use selected AI topic
    const actualTopic = isCustomTopicMode ? customTopic : selectedTopic;
    
    // Guard: prevent submission with empty data
    if (!actualCategory || !actualTopic) {
      toast({
        title: "Missing information",
        description: "Please select a category and topic before creating the debate.",
        variant: "destructive",
      });
      return;
    }
    
    createDebate({
      category: actualCategory,
      topic: actualTopic,
      creatorSide: selectedSide,
      creatorId: user.id,
      opponentType,
      targetUserId: targetUser,
      aiOpponentId: opponentType === 'ai' ? selectedAiOpponent?.id : undefined,
    }, {
      onSuccess: (data) => {
        setCreatedDebate(data);
        if (opponentType === "ai") {
          // Go directly to debate room for AI
          setLocation(`/debate/${data.id}`);
        } else if (opponentType === "friend") {
          // Show share link for friend challenge
          nextStep();
        } else {
          // Open challenge - go to home
          setLocation('/');
        }
      }
    });
  };

  const copyInviteLink = () => {
    if (!createdDebate?.inviteCode) return;
    const link = `${window.location.origin}/join/${createdDebate.inviteCode}`;
    navigator.clipboard.writeText(link);
    toast({
      title: "Link copied!",
      description: "Share this link with your friend to start the debate.",
    });
  };

  const nextStep = () => {
    // Defensive check when leaving step 2
    if (step === 2) {
      const actualCategory = selectedCategory === 'custom' ? confirmedCustomCategory : selectedCategory;
      const actualTopic = isCustomTopicMode ? customTopic : selectedTopic;
      
      // Validate category and topic are set
      if (!actualCategory || !actualTopic) {
        toast({
          title: "Incomplete selection",
          description: "Please select a category and topic before proceeding.",
          variant: "destructive",
        });
        return;
      }
      
      // For AI topic mode, ensure topics were generated for current category
      if (!isCustomTopicMode && topicsGeneratedForCategory !== categoryForTopics) {
        toast({
          title: "Topics not generated",
          description: "Please generate topics for this category first.",
          variant: "destructive",
        });
        return;
      }
    }
    setStep(s => s + 1);
  };
  const prevStep = () => setStep(s => s - 1);

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display tracking-tight mb-2">Create New Debate</h1>
        <p className="text-muted-foreground">Challenge the world to a battle of wits.</p>
        
        {/* Progress Steps */}
        <div className="flex items-center gap-2 mt-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex items-center">
              <div className={`
                w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-colors
                ${step >= i ? 'bg-primary border-primary text-white' : 'border-muted text-muted-foreground'}
              `}>
                {step === 5 && i === 4 ? <Check className="w-4 h-4" /> : i}
              </div>
              {i < 4 && <div className={`w-8 h-1 bg-muted mx-1 rounded ${step > i ? 'bg-primary' : ''}`} />}
            </div>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Choose a Category</h2>
              <div className="flex items-center gap-2 text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">
                <Sparkles className="w-3 h-3" />
                AI Generated
              </div>
            </div>

            {isLoadingCategories ? (
              <LoadingCategoriesFacts />
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                <Card 
                  className={`cursor-pointer transition-all border-dashed hover:border-primary/50 hover:bg-muted/50 ${selectedCategory === 'custom' ? 'border-primary ring-2 ring-primary/20 bg-muted/50' : ''}`}
                  onClick={() => {
                    setSelectedCategory('custom');
                    setSelectedTopic('');
                    setCustomTopic('');
                    setCustomCategoryName('');
                    setConfirmedCustomCategory('');
                    setIsCustomTopicMode(false);
                    setTopicsGeneratedForCategory('');
                    nextStep();
                  }}
                >
                  <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                    <div className={`p-2 rounded-lg bg-background border border-border text-primary ${selectedCategory === 'custom' ? 'scale-110' : ''} transition-transform`}>
                      <Plus className="w-5 h-5" />
                    </div>
                    <span className="font-medium text-sm truncate w-full">Create Own</span>
                  </CardContent>
                </Card>

                {categories?.map((cat) => {
                  const isSelected = selectedCategory === cat;
                  return (
                    <Card 
                      key={cat}
                      className={`cursor-pointer transition-all hover:border-primary/50 hover:bg-muted/50 ${isSelected ? 'border-primary ring-2 ring-primary/20 bg-muted/50' : ''}`}
                      onClick={() => {
                        setSelectedCategory(cat);
                        setSelectedTopic('');
                        setCustomTopic('');
                        setCustomCategoryName('');
                        setConfirmedCustomCategory('');
                        setIsCustomTopicMode(false);
                        setTopicsGeneratedForCategory('');
                        nextStep();
                      }}
                    >
                      <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                        <div className={`p-2 rounded-lg bg-background border border-border text-primary ${isSelected ? 'scale-110' : ''} transition-transform`}>
                          <Hash className="w-5 h-5" />
                        </div>
                        <span className="font-medium text-sm truncate w-full">{cat}</span>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
            <div className="flex justify-end pt-4">
              <Button onClick={nextStep} disabled={!selectedCategory} className="w-full sm:w-auto">
                Next Step <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">
                {selectedCategory === 'custom' && !customCategoryName 
                  ? 'Name Your Category' 
                  : isCustomTopicMode 
                    ? 'Write Your Topic' 
                    : 'Select a Topic'}
              </h2>
              {(selectedCategory !== 'custom' || customCategoryName) && !isCustomTopicMode && (
                <div className="flex items-center gap-2 text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">
                  <Sparkles className="w-3 h-3" />
                  AI Generated
                </div>
              )}
            </div>
            
            {/* Custom Category: Enter category name first */}
            {selectedCategory === 'custom' && !confirmedCustomCategory ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="custom-category">Category Name</Label>
                  <Input
                    id="custom-category"
                    placeholder="e.g. Space Exploration, Urban Planning, Mental Health..."
                    value={customCategoryName}
                    onChange={(e) => setCustomCategoryName(e.target.value)}
                    data-testid="input-custom-category"
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter a topic area and AI will generate debate topics for you, or you can write your own.
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button 
                    onClick={() => {
                      if (customCategoryName.trim()) {
                        // Set the confirmed category which triggers topic generation
                        setConfirmedCustomCategory(customCategoryName.trim());
                        setTopicsGeneratedForCategory('');
                        setSelectedTopic('');
                      }
                    }}
                    disabled={!customCategoryName.trim()}
                    className="flex-1"
                    data-testid="button-generate-topics"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate AI Topics
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      if (customCategoryName.trim()) {
                        // Set confirmed category and go straight to custom topic mode
                        setConfirmedCustomCategory(customCategoryName.trim());
                        setIsCustomTopicMode(true);
                        setSelectedTopic('');
                      }
                    }}
                    disabled={!customCategoryName.trim()}
                    className="flex-1"
                    data-testid="button-write-own-topic-custom"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Write My Own
                  </Button>
                </div>
              </div>
            ) : isCustomTopicMode ? (
              /* Write your own topic mode */
              <div className="space-y-4">
                {/* Show category header when in custom category mode */}
                {selectedCategory === 'custom' && confirmedCustomCategory && (
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border">
                    <div className="flex items-center gap-2">
                      <Hash className="w-4 h-4 text-primary" />
                      <span className="font-medium">{confirmedCustomCategory}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setConfirmedCustomCategory('');
                        setSelectedTopic('');
                        setIsCustomTopicMode(false);
                        setTopicsGeneratedForCategory('');
                      }}
                      data-testid="button-change-custom-category-write"
                    >
                      Change
                    </Button>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="custom-topic">Debate Statement</Label>
                  <textarea
                    id="custom-topic"
                    className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="e.g. Remote work is more productive than in-office work for most industries."
                    value={customTopic}
                    onChange={(e) => setCustomTopic(e.target.value)}
                    data-testid="textarea-custom-topic"
                  />
                  <p className="text-xs text-muted-foreground">
                    Write a clear, debatable statement that can be argued from both Pro and Con sides.
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  onClick={() => setIsCustomTopicMode(false)}
                  className="w-full"
                >
                  Back to AI Suggestions
                </Button>
              </div>
            ) : (
              /* AI-generated topics */
              isLoadingTopics ? (
                <LoadingFacts />
              ) : (
                <div className="space-y-3">
                  {/* Show confirmed custom category with edit option */}
                  {selectedCategory === 'custom' && confirmedCustomCategory && (
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border">
                      <div className="flex items-center gap-2">
                        <Hash className="w-4 h-4 text-primary" />
                        <span className="font-medium">{confirmedCustomCategory}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          // Reset to allow editing the category
                          setConfirmedCustomCategory('');
                          setSelectedTopic('');
                          setTopicsGeneratedForCategory('');
                        }}
                        data-testid="button-change-custom-category"
                      >
                        Change
                      </Button>
                    </div>
                  )}
                  
                  {/* Write your own option */}
                  <div
                    onClick={() => {
                      setIsCustomTopicMode(true);
                      setSelectedTopic('');
                    }}
                    className="p-4 rounded-xl border-2 border-dashed cursor-pointer transition-all flex items-center gap-3 hover:border-primary/50 hover:bg-muted/30"
                    data-testid="button-write-own-topic"
                  >
                    <div className="p-2 rounded-lg bg-primary/10 text-primary">
                      <Plus className="w-4 h-4" />
                    </div>
                    <span className="font-medium text-muted-foreground">Write your own topic</span>
                  </div>
                  
                  {topics?.map((topic) => (
                    <div
                      key={topic}
                      onClick={() => {
                        setSelectedTopic(topic);
                        setCustomTopic('');
                        nextStep();
                      }}
                      className={`
                        p-4 rounded-xl border-2 cursor-pointer transition-all flex items-center justify-between
                        ${selectedTopic === topic 
                          ? 'border-primary bg-primary/5 text-primary' 
                          : 'border-border hover:border-primary/30 hover:bg-muted/30'}
                      `}
                      data-testid={`topic-option-${topic.slice(0, 20)}`}
                    >
                      <span className="font-medium">{topic}</span>
                      {selectedTopic === topic && <Check className="w-5 h-5" />}
                    </div>
                  ))}
                </div>
              )
            )}
            
            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => {
                if (isCustomTopicMode) {
                  // Going back to AI suggestions - clear both topic states
                  setIsCustomTopicMode(false);
                  setCustomTopic('');
                  setSelectedTopic('');
                } else if (selectedCategory === 'custom' && confirmedCustomCategory) {
                  // Going back to category name input - clear confirmed category and topic state
                  setConfirmedCustomCategory('');
                  setSelectedTopic('');
                  setCustomTopic('');
                  setTopicsGeneratedForCategory('');
                } else {
                  // Going back to category selection - clear all
                  setSelectedTopic('');
                  setCustomTopic('');
                  setCustomCategoryName('');
                  setConfirmedCustomCategory('');
                  setIsCustomTopicMode(false);
                  setTopicsGeneratedForCategory('');
                  prevStep();
                }
              }}>Back</Button>
              <Button 
                onClick={nextStep} 
                disabled={
                  // Custom category without confirmed category yet - waiting for user to click Generate/Write Own
                  (selectedCategory === 'custom' && !confirmedCustomCategory)
                    ? true 
                    // In custom topic mode - need custom topic text
                    : isCustomTopicMode 
                      ? !customTopic.trim() 
                      // In AI topic mode - need selected topic AND topics must be generated for current category
                      : !selectedTopic || !topics || topics.length === 0 || topicsGeneratedForCategory !== categoryForTopics
                }
              >
                Next Step <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <h2 className="text-xl font-semibold">Choose Your Side</h2>
            
            <div className="grid grid-cols-2 gap-6">
              <div
                onClick={() => setSelectedSide("pro")}
                className={`flex flex-col items-center justify-between rounded-xl border-2 bg-popover p-6 cursor-pointer transition-all h-full ${
                  selectedSide === 'pro' 
                    ? 'border-green-500 bg-green-500/10 text-green-500' 
                    : 'border-muted hover:bg-accent hover:text-accent-foreground'
                }`}
                data-testid="option-pro"
              >
                <span className="text-3xl mb-2">👍</span>
                <span className="text-xl font-bold uppercase tracking-wide">Pro</span>
                <span className={`text-sm text-center mt-2 ${selectedSide === 'pro' ? 'text-green-500/80' : 'text-muted-foreground'}`}>
                  Agree with the statement
                </span>
              </div>

              <div
                onClick={() => setSelectedSide("con")}
                className={`flex flex-col items-center justify-between rounded-xl border-2 bg-popover p-6 cursor-pointer transition-all h-full ${
                  selectedSide === 'con' 
                    ? 'border-red-500 bg-red-500/10 text-red-500' 
                    : 'border-muted hover:bg-accent hover:text-accent-foreground'
                }`}
                data-testid="option-con"
              >
                <span className="text-3xl mb-2">👎</span>
                <span className="text-xl font-bold uppercase tracking-wide">Con</span>
                <span className={`text-sm text-center mt-2 ${selectedSide === 'con' ? 'text-red-500/80' : 'text-muted-foreground'}`}>
                  Disagree with the statement
                </span>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 space-y-4">
              <h3 className="font-medium text-muted-foreground uppercase text-xs tracking-wider">Summary</h3>
              <div>
                <div className="text-sm text-muted-foreground">Topic</div>
                <div className="font-bold text-lg">
                  {isCustomTopicMode ? customTopic : selectedTopic}
                </div>
              </div>
              <div className="flex gap-8">
                <div>
                  <div className="text-sm text-muted-foreground">Category</div>
                  <div className="capitalize font-medium">
                    {selectedCategory === 'custom' ? confirmedCustomCategory : selectedCategory}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Your Side</div>
                  <div className="uppercase font-bold text-primary">{selectedSide}</div>
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={prevStep}>Back</Button>
              <Button onClick={nextStep}>
                Next Step <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        )}

        {step === 4 && (
          <motion.div
            key="step4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <h2 className="text-xl font-semibold">Choose Your Opponent</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card 
                className={`cursor-pointer transition-all hover:border-primary/50 ${opponentType === 'open' ? 'border-primary ring-2 ring-primary/20' : ''}`}
                onClick={() => {
                  setOpponentType('open');
                  setSelectedFriend(null);
                  setUseInviteLink(false);
                  setFriendSearch("");
                }}
                data-testid="card-open-challenge"
              >
                <CardContent className="p-6 flex flex-col items-center text-center gap-3">
                  <div className="p-3 rounded-xl bg-blue-500/10 text-blue-500">
                    <Globe className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="font-bold">Open Challenge</h3>
                    <p className="text-sm text-muted-foreground mt-1">Anyone can join your debate</p>
                  </div>
                </CardContent>
              </Card>

              <Card 
                className={`cursor-pointer transition-all hover:border-primary/50 ${opponentType === 'friend' ? 'border-primary ring-2 ring-primary/20' : ''}`}
                onClick={() => setOpponentType('friend')}
                data-testid="card-challenge-friend"
              >
                <CardContent className="p-6 flex flex-col items-center text-center gap-3">
                  <div className="p-3 rounded-xl bg-green-500/10 text-green-500">
                    <UserPlus className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="font-bold">Challenge Friend</h3>
                    <p className="text-sm text-muted-foreground mt-1">Send to a friend or rival</p>
                  </div>
                </CardContent>
              </Card>

              <Card 
                className={`cursor-pointer transition-all hover:border-primary/50 ${opponentType === 'ai' ? 'border-primary ring-2 ring-primary/20' : ''}`}
                onClick={() => {
                  setOpponentType('ai');
                  setSelectedFriend(null);
                  setUseInviteLink(false);
                  setFriendSearch("");
                  // Don't reset AI opponent selection when clicking the same type
                }}
                data-testid="card-debate-ai"
              >
                <CardContent className="p-6 flex flex-col items-center text-center gap-3">
                  <div className="p-3 rounded-xl bg-purple-500/10 text-purple-500">
                    <Bot className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="font-bold">Debate AI</h3>
                    <p className="text-sm text-muted-foreground mt-1">Practice against AI opponent</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {opponentType === 'ai' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border" data-testid="notice-ai-practice">
                  <Bot className="w-4 h-4 text-muted-foreground shrink-0" />
                  <p className="text-sm text-muted-foreground">
                    AI debates are for practice and <span className="font-medium text-foreground">won't affect your ELO ranking</span>
                  </p>
                </div>
                <AiOpponentSelector
                  selectedOpponent={selectedAiOpponent}
                  onSelect={setSelectedAiOpponent}
                />
              </div>
            )}

            {opponentType === 'friend' && (
              <div className="space-y-4">
                {/* Toggle between search user or send invite link */}
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant={!useInviteLink ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => {
                      setUseInviteLink(false);
                      setSelectedFriend(null);
                    }}
                    data-testid="button-select-user"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Select User
                  </Button>
                  <Button
                    type="button"
                    variant={useInviteLink ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => {
                      setUseInviteLink(true);
                      setSelectedFriend(null);
                      setFriendSearch("");
                    }}
                    data-testid="button-send-link"
                  >
                    <Link2 className="w-4 h-4 mr-2" />
                    Send Invite Link
                  </Button>
                </div>

                {useInviteLink ? (
                  <div className="text-center py-6 px-4 rounded-xl border border-dashed border-border bg-muted/30">
                    <Link2 className="w-10 h-10 mx-auto mb-3 text-primary" />
                    <h4 className="font-semibold mb-1">Share via Invite Link</h4>
                    <p className="text-sm text-muted-foreground">
                      After creating the debate, you'll get a link to share with anyone. They can join even if they're new to the platform.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search any user by name or email..."
                        value={friendSearch}
                        onChange={(e) => setFriendSearch(e.target.value)}
                        className="pl-10"
                        data-testid="input-user-search"
                      />
                    </div>

                    {friendSearch.length < 2 && allContacts.length === 0 ? (
                      <div className="text-center py-6 text-muted-foreground">
                        <Users className="w-10 h-10 mx-auto mb-3 opacity-50" />
                        <p className="font-medium">Search for any user</p>
                        <p className="text-sm">Type at least 2 characters to search all users</p>
                      </div>
                    ) : isSearching ? (
                      <div className="flex justify-center py-8">
                        <Loader2 className="w-6 h-6 animate-spin text-primary" />
                      </div>
                    ) : allContacts.length === 0 && friendSearch.length >= 2 ? (
                      <div className="text-center py-6 text-muted-foreground">
                        <Users className="w-10 h-10 mx-auto mb-3 opacity-50" />
                        <p className="font-medium">No users found</p>
                        <p className="text-sm">Try a different search or use the invite link option</p>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-[300px] overflow-y-auto">
                        {allContacts.map((contact: Friend) => (
                          <div
                            key={contact.id}
                            onClick={() => setSelectedFriend(contact)}
                            className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                              selectedFriend?.id === contact.id 
                                ? 'border-primary bg-primary/5' 
                                : 'border-border hover:border-primary/30'
                            }`}
                            data-testid={`user-${contact.id}`}
                          >
                            <UserAvatar user={contact} size="sm" />
                            <div className="flex-1 min-w-0">
                              <div className="font-medium truncate">
                                {contact.firstName && contact.lastName 
                                  ? `${contact.firstName} ${contact.lastName}`
                                  : contact.email || 'Unknown'}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                ELO: {contact.eloRating || '1000'}
                              </div>
                            </div>
                            {selectedFriend?.id === contact.id && (
                              <Check className="w-5 h-5 text-primary" />
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            <div className="bg-card border border-border rounded-xl p-6 space-y-4">
              <h3 className="font-medium text-muted-foreground uppercase text-xs tracking-wider">Summary</h3>
              <div>
                <div className="text-sm text-muted-foreground">Topic</div>
                <div className="font-bold text-lg">
                  {isCustomTopicMode ? customTopic : selectedTopic}
                </div>
              </div>
              <div className="flex gap-8 flex-wrap">
                <div>
                  <div className="text-sm text-muted-foreground">Category</div>
                  <div className="capitalize font-medium">
                    {selectedCategory === 'custom' ? confirmedCustomCategory : selectedCategory}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Your Side</div>
                  <div className="uppercase font-bold text-primary">{selectedSide}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Opponent</div>
                  <div className="font-medium">
                    {opponentType === 'open' && 'Open Challenge'}
                    {opponentType === 'ai' && (selectedAiOpponent ? selectedAiOpponent.name : 'Select an AI...')}
                    {opponentType === 'friend' && (
                      useInviteLink 
                        ? 'Via Invite Link'
                        : (selectedFriend 
                          ? (selectedFriend.firstName || selectedFriend.email || 'Selected User')
                          : 'Select a user...')
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={prevStep}>Back</Button>
              <Button 
                onClick={handleCreate} 
                disabled={isCreating || (opponentType === 'friend' && !useInviteLink && !selectedFriend) || (opponentType === 'ai' && !selectedAiOpponent)} 
                className="bg-primary hover:bg-primary/90 text-white min-w-[140px]"
                data-testid="button-create-debate"
              >
                {isCreating ? <Loader2 className="w-4 h-4 animate-spin" /> : "Create Debate"}
              </Button>
            </div>
          </motion.div>
        )}

        {step === 5 && createdDebate && (
          <motion.div
            key="step5"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6 text-center"
          >
            <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center mx-auto">
              <Check className="w-10 h-10 text-green-500" />
            </div>
            
            <div>
              <h2 className="text-2xl font-bold">Debate Created!</h2>
              <p className="text-muted-foreground mt-2">
                {selectedFriend 
                  ? `Share this link with ${selectedFriend.firstName || 'your opponent'} to start the debate`
                  : 'Share this link with anyone to challenge them to a debate'}
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
              <div className="flex-1 font-mono text-sm truncate text-left">
                {window.location.origin}/join/{createdDebate.inviteCode}
              </div>
              <Button onClick={copyInviteLink} variant="outline" size="icon" data-testid="button-copy-link">
                <Copy className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex gap-3 justify-center">
              <Button variant="outline" onClick={() => setLocation('/')}>
                Go Home
              </Button>
              <Button onClick={() => setLocation(`/debate/${createdDebate.id}`)} data-testid="button-go-to-debate">
                Go to Debate Room
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
