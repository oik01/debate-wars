import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserAvatar } from "@/components/user-avatar";
import { EloBadge } from "@/components/elo-badge";
import { CountryFlag } from "@/components/country-flag";
import { useLocation } from "wouter";
import { 
  Loader2, 
  Swords, 
  RefreshCw, 
  Users, 
  Flag,
  Zap,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface PoliticalTopic {
  topic: string;
  proSide: string;
  conSide: string;
}

interface PoliticalDebate {
  id: number;
  topic: string;
  category: string;
  status: string;
  creatorId: string;
  creatorSide: string;
  creatorAffiliation: string;
  requiredAffiliation: string;
  inviteCode: string;
  creator: {
    id: string;
    firstName: string | null;
    lastName: string | null;
    email: string | null;
    avatarType: string | null;
    customAvatarUrl: string | null;
    eloRating: string | null;
    nationality: string | null;
  };
}

const PARTY_COLORS = {
  democrat: {
    bg: "from-blue-600 to-blue-800",
    text: "text-blue-400",
    badge: "bg-blue-600",
    border: "border-blue-500/30",
    glow: "shadow-blue-500/20",
  },
  republican: {
    bg: "from-red-600 to-red-800",
    text: "text-red-400",
    badge: "bg-red-600",
    border: "border-red-500/30",
    glow: "shadow-red-500/20",
  },
};

export default function PoliticalArena() {
  const { user, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedTopic, setSelectedTopic] = useState<PoliticalTopic | null>(null);
  const [selectedSide, setSelectedSide] = useState<"pro" | "con">("pro");

  const userAffiliation = (user as any)?.politicalAffiliation as string | undefined;
  const oppositeParty = userAffiliation === "democrat" ? "republican" : "democrat";
  const partyColors = userAffiliation ? PARTY_COLORS[userAffiliation as keyof typeof PARTY_COLORS] : null;
  const oppositeColors = oppositeParty ? PARTY_COLORS[oppositeParty as keyof typeof PARTY_COLORS] : null;

  const { data: topics = [], isLoading: topicsLoading, refetch: refetchTopics } = useQuery<PoliticalTopic[]>({
    queryKey: ["/api/political-topics"],
    enabled: !!user && userAffiliation !== "independent",
  });

  const { data: pendingDebates = [], isLoading: debatesLoading } = useQuery<PoliticalDebate[]>({
    queryKey: ["/api/political-debates"],
    enabled: !!user && !!userAffiliation,
  });

  const createDebateMutation = useMutation({
    mutationFn: async (data: { topic: string; creatorSide: string }) => {
      return apiRequest("POST", "/api/political-debates", data);
    },
    onSuccess: async (response) => {
      const debate = await response.json();
      queryClient.invalidateQueries({ queryKey: ["/api/political-debates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/debates"] });
      toast({
        title: "Challenge Created!",
        description: `Waiting for a ${oppositeParty === "democrat" ? "Democrat" : "Republican"} to accept...`,
      });
      navigate(`/debate/${debate.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create debate",
        variant: "destructive",
      });
    },
  });

  const joinDebateMutation = useMutation({
    mutationFn: async (debateId: number) => {
      return apiRequest("POST", `/api/debates/${debateId}/join`, {});
    },
    onSuccess: async (_, debateId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/political-debates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/debates"] });
      toast({
        title: "Joined Debate!",
        description: "Get ready to make your arguments!",
      });
      navigate(`/debate/${debateId}`);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to join debate",
        variant: "destructive",
      });
    },
  });

  const handleCreateDebate = () => {
    if (!selectedTopic) return;
    createDebateMutation.mutate({
      topic: selectedTopic.topic,
      creatorSide: selectedSide,
    });
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Sign in to access the Political Arena</h1>
        <Button onClick={() => window.location.href = "/api/login"}>
          Sign In
        </Button>
      </div>
    );
  }

  if (!userAffiliation) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Flag className="w-5 h-5" />
              Set Your Affiliation
            </CardTitle>
            <CardDescription>
              You need to set your political affiliation in your profile to access the Political Arena.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/profile")} className="w-full">
              Go to Profile
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Independents can browse and join debates but not create them
  const canCreateDebates = userAffiliation !== "independent";
  const isIndependent = userAffiliation === "independent";

  const partyDisplayName = userAffiliation === "democrat" ? "Democrat" : userAffiliation === "republican" ? "Republican" : "Independent";
  const oppositeDisplayName = oppositeParty === "democrat" ? "Democrat" : "Republican";

  return (
    <div className="container mx-auto px-4 py-6 space-y-8 max-w-6xl">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-600/20 to-red-600/20 border border-white/10"
        >
          <Swords className="w-5 h-5 text-primary" />
          <span className="font-semibold">Political Arena</span>
        </motion.div>
        
        {isIndependent ? (
          <>
            <h1 className="text-4xl font-bold">
              <span className="text-blue-400">Democrat</span>
              {" vs "}
              <span className="text-red-400">Republican</span>
            </h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              As an Independent, you can join debates from either side! Browse open challenges below.
            </p>
          </>
        ) : (
          <>
            <h1 className="text-4xl font-bold">
              <span className={partyColors?.text}>{partyDisplayName}</span>
              {" vs "}
              <span className={oppositeColors?.text}>{oppositeDisplayName}</span>
            </h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Debate the issues that matter. Challenge someone from the other side on current political topics.
            </p>
          </>
        )}
      </div>

      {/* Challenge Banner - Only show for non-independents */}
      {canCreateDebates && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className={`bg-gradient-to-r ${oppositeColors?.bg} border-0 overflow-hidden`}>
            <CardContent className="p-6 flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Challenge a {oppositeDisplayName}
                  </h2>
                  <p className="text-white/80">
                    Pick a topic and wait for an opponent to accept
                  </p>
                </div>
              </div>
              <Button 
                variant="secondary" 
                size="lg"
                className="bg-white text-black hover:bg-gray-100"
                onClick={() => document.getElementById('create-debate')?.scrollIntoView({ behavior: 'smooth' })}
                data-testid="button-create-political-debate"
              >
                Create Challenge
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Pending Debates from Opposite Party */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Users className="w-5 h-5" />
            {isIndependent ? "Open Political Challenges" : `Open Challenges from ${oppositeDisplayName}s`}
          </h2>
          <Badge variant="outline" className={isIndependent ? "border-purple-500/30" : oppositeColors?.border}>
            {pendingDebates.length} Available
          </Badge>
        </div>

        {debatesLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin" />
          </div>
        ) : pendingDebates.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-12 text-center">
              <Users className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
              <p className="text-muted-foreground">
                {isIndependent 
                  ? "No political challenges waiting. Check back later!"
                  : `No ${oppositeDisplayName} challenges waiting. Be the first to create one!`}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            <AnimatePresence>
              {pendingDebates.map((debate, index) => {
                const creatorParty = debate.creatorAffiliation === "democrat" ? "Democrat" : "Republican";
                const creatorColors = debate.creatorAffiliation === "democrat" 
                  ? PARTY_COLORS.democrat 
                  : PARTY_COLORS.republican;
                
                return (
                <motion.div
                  key={debate.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className={`hover-elevate ${isIndependent ? creatorColors?.border : oppositeColors?.border} ${isIndependent ? creatorColors?.glow : oppositeColors?.glow} shadow-lg`}>
                    <CardContent className="p-4 space-y-4">
                      <div className="flex items-start gap-3">
                        <UserAvatar
                          user={debate.creator}
                          size="md"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium">
                              {debate.creator.firstName || debate.creator.email?.split('@')[0] || 'Anonymous'}
                            </span>
                            {debate.creator.nationality && (
                              <CountryFlag code={debate.creator.nationality} size="sm" />
                            )}
                            <Badge className={isIndependent ? creatorColors?.badge : oppositeColors?.badge}>
                              {isIndependent ? creatorParty : oppositeDisplayName}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <EloBadge elo={parseInt(debate.creator.eloRating || '1000')} size="sm" />
                          </div>
                        </div>
                      </div>
                      
                      <p className="text-sm line-clamp-3">{debate.topic}</p>
                      
                      <div className="flex items-center justify-between gap-2">
                        <Badge variant="outline" className="text-xs">
                          You argue: {debate.creatorSide === "pro" ? "CON" : "PRO"}
                        </Badge>
                        <Button 
                          size="sm"
                          onClick={() => joinDebateMutation.mutate(debate.id)}
                          disabled={joinDebateMutation.isPending}
                          data-testid={`button-join-debate-${debate.id}`}
                        >
                          {joinDebateMutation.isPending ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <>Accept Challenge</>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Create New Political Debate - Only for Democrats and Republicans */}
      {canCreateDebates && (
      <div id="create-debate" className="space-y-4 scroll-mt-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Create Your Challenge
          </h2>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => refetchTopics()}
            disabled={topicsLoading}
            data-testid="button-refresh-topics"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${topicsLoading ? 'animate-spin' : ''}`} />
            New Topics
          </Button>
        </div>

        <p className="text-sm text-muted-foreground">
          Select a topic from current political news and choose your position
        </p>

        {topicsLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin" />
          </div>
        ) : (
          <div className="space-y-3">
            {topics.map((topic, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.03 }}
              >
                <Card 
                  className={`cursor-pointer transition-all ${
                    selectedTopic?.topic === topic.topic 
                      ? 'ring-2 ring-primary bg-primary/5' 
                      : 'hover-elevate'
                  }`}
                  onClick={() => setSelectedTopic(topic)}
                  data-testid={`topic-card-${index}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <p className="font-medium">{topic.topic}</p>
                        <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                          <span className="text-blue-400">PRO: {topic.proSide}</span>
                          <span className="text-red-400">CON: {topic.conSide}</span>
                        </div>
                      </div>
                      {selectedTopic?.topic === topic.topic && (
                        <Badge className="bg-primary">Selected</Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {/* Side Selection and Create Button */}
        <AnimatePresence>
          {selectedTopic && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <Card className="mt-4">
                <CardContent className="p-4 space-y-4">
                  <div>
                    <p className="text-sm font-medium mb-2">Choose your position:</p>
                    <div className="flex gap-2">
                      <Button
                        variant={selectedSide === "pro" ? "default" : "outline"}
                        className={selectedSide === "pro" ? "bg-blue-600 hover:bg-blue-700" : ""}
                        onClick={() => setSelectedSide("pro")}
                        data-testid="button-select-pro"
                      >
                        PRO - {selectedTopic.proSide}
                      </Button>
                      <Button
                        variant={selectedSide === "con" ? "default" : "outline"}
                        className={selectedSide === "con" ? "bg-red-600 hover:bg-red-700" : ""}
                        onClick={() => setSelectedSide("con")}
                        data-testid="button-select-con"
                      >
                        CON - {selectedTopic.conSide}
                      </Button>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full" 
                    size="lg"
                    onClick={handleCreateDebate}
                    disabled={createDebateMutation.isPending}
                    data-testid="button-submit-challenge"
                  >
                    {createDebateMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating Challenge...
                      </>
                    ) : (
                      <>
                        <Swords className="w-4 h-4 mr-2" />
                        Challenge a {oppositeDisplayName}
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      )}
    </div>
  );
}
