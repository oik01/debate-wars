import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useUpload } from "@/hooks/use-upload";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useQuery } from "@tanstack/react-query";
import { Loader2, Upload, Check, User, Globe, Flag, Heart, Camera, Download, Smartphone, PartyPopper } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { usePWAInstall } from "@/hooks/use-pwa-install";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

const COUNTRIES = [
  { code: "US", name: "United States" },
  { code: "GB", name: "United Kingdom" },
  { code: "CA", name: "Canada" },
  { code: "AU", name: "Australia" },
  { code: "DE", name: "Germany" },
  { code: "FR", name: "France" },
  { code: "JP", name: "Japan" },
  { code: "KR", name: "South Korea" },
  { code: "CN", name: "China" },
  { code: "IN", name: "India" },
  { code: "BR", name: "Brazil" },
  { code: "MX", name: "Mexico" },
  { code: "ES", name: "Spain" },
  { code: "IT", name: "Italy" },
  { code: "NL", name: "Netherlands" },
  { code: "SE", name: "Sweden" },
  { code: "NO", name: "Norway" },
  { code: "PL", name: "Poland" },
  { code: "RU", name: "Russia" },
  { code: "ZA", name: "South Africa" },
  { code: "NG", name: "Nigeria" },
  { code: "EG", name: "Egypt" },
  { code: "AR", name: "Argentina" },
  { code: "CL", name: "Chile" },
  { code: "PH", name: "Philippines" },
  { code: "ID", name: "Indonesia" },
  { code: "MY", name: "Malaysia" },
  { code: "TH", name: "Thailand" },
  { code: "VN", name: "Vietnam" },
  { code: "PK", name: "Pakistan" },
  { code: "LB", name: "Lebanon" },
  { code: "AE", name: "United Arab Emirates" },
  { code: "SA", name: "Saudi Arabia" },
  { code: "IL", name: "Israel" },
  { code: "TR", name: "Turkey" },
  { code: "GR", name: "Greece" },
  { code: "PT", name: "Portugal" },
  { code: "IE", name: "Ireland" },
  { code: "BE", name: "Belgium" },
  { code: "CH", name: "Switzerland" },
  { code: "AT", name: "Austria" },
  { code: "DK", name: "Denmark" },
  { code: "FI", name: "Finland" },
  { code: "NZ", name: "New Zealand" },
  { code: "SG", name: "Singapore" },
  { code: "HK", name: "Hong Kong" },
  { code: "TW", name: "Taiwan" },
  { code: "CO", name: "Colombia" },
  { code: "PE", name: "Peru" },
  { code: "VE", name: "Venezuela" },
  { code: "UA", name: "Ukraine" },
  { code: "CZ", name: "Czech Republic" },
  { code: "RO", name: "Romania" },
  { code: "HU", name: "Hungary" },
  { code: "KE", name: "Kenya" },
  { code: "GH", name: "Ghana" },
  { code: "MA", name: "Morocco" },
  { code: "IQ", name: "Iraq" },
  { code: "IR", name: "Iran" },
  { code: "JO", name: "Jordan" },
  { code: "SY", name: "Syria" },
  { code: "BD", name: "Bangladesh" },
  { code: "LK", name: "Sri Lanka" },
  { code: "NP", name: "Nepal" },
];

function CountryFlag({ code, size = "medium" }: { code: string; size?: "small" | "medium" | "large" }) {
  const dimensions = {
    small: { width: 32, height: 24, src: "w40", srcSet: "w80" },
    medium: { width: 48, height: 36, src: "w80", srcSet: "w160" },
    large: { width: 64, height: 48, src: "w80", srcSet: "w160" },
  };
  const { width, height, src, srcSet } = dimensions[size];
  return (
    <img
      src={`https://flagcdn.com/${src}/${code.toLowerCase()}.png`}
      srcSet={`https://flagcdn.com/${srcSet}/${code.toLowerCase()}.png 2x`}
      width={width}
      height={height}
      alt={code}
      className="rounded shadow-sm"
    />
  );
}

const CARTOON_AVATARS = [
  { id: "cartoon1", name: "Cool Cat", bgColor: "#4F46E5", emoji: "cat" },
  { id: "cartoon2", name: "Wise Owl", bgColor: "#7C3AED", emoji: "owl" },
  { id: "cartoon3", name: "Fierce Lion", bgColor: "#DC2626", emoji: "lion" },
  { id: "cartoon4", name: "Clever Fox", bgColor: "#EA580C", emoji: "fox" },
  { id: "cartoon5", name: "Chill Bear", bgColor: "#65A30D", emoji: "bear" },
  { id: "cartoon6", name: "Swift Eagle", bgColor: "#0891B2", emoji: "eagle" },
  { id: "cartoon7", name: "Smart Rabbit", bgColor: "#DB2777", emoji: "rabbit" },
  { id: "cartoon8", name: "Bold Wolf", bgColor: "#4338CA", emoji: "wolf" },
];

function CartoonAvatar({ avatar, selected, onClick }: { avatar: typeof CARTOON_AVATARS[0]; selected: boolean; onClick: () => void }) {
  const animalPaths: Record<string, JSX.Element> = {
    cat: (
      <g fill="white">
        <circle cx="50" cy="55" r="30" />
        <polygon points="25,30 35,55 15,55" />
        <polygon points="75,30 65,55 85,55" />
        <circle cx="40" cy="50" r="5" fill="#333" />
        <circle cx="60" cy="50" r="5" fill="#333" />
        <ellipse cx="50" cy="62" rx="4" ry="3" fill="#333" />
        <path d="M46,68 Q50,72 54,68" stroke="#333" strokeWidth="2" fill="none" />
      </g>
    ),
    owl: (
      <g fill="white">
        <ellipse cx="50" cy="58" rx="28" ry="25" />
        <circle cx="38" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" />
        <circle cx="62" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" />
        <circle cx="38" cy="52" r="5" fill="#333" />
        <circle cx="62" cy="52" r="5" fill="#333" />
        <polygon points="50,60 46,70 54,70" fill="#F59E0B" />
        <polygon points="25,35 30,50 20,50" />
        <polygon points="75,35 70,50 80,50" />
      </g>
    ),
    lion: (
      <g>
        <circle cx="50" cy="55" r="35" fill="#F59E0B" />
        <circle cx="50" cy="58" r="22" fill="white" />
        <circle cx="42" cy="52" r="4" fill="#333" />
        <circle cx="58" cy="52" r="4" fill="#333" />
        <ellipse cx="50" cy="62" rx="5" ry="4" fill="#333" />
        <path d="M45,70 Q50,75 55,70" stroke="#333" strokeWidth="2" fill="none" />
      </g>
    ),
    fox: (
      <g fill="white">
        <ellipse cx="50" cy="58" rx="25" ry="22" />
        <polygon points="20,25 35,55 20,55" fill="#EA580C" />
        <polygon points="80,25 65,55 80,55" fill="#EA580C" />
        <circle cx="40" cy="52" r="4" fill="#333" />
        <circle cx="60" cy="52" r="4" fill="#333" />
        <ellipse cx="50" cy="64" rx="4" ry="3" fill="#333" />
      </g>
    ),
    bear: (
      <g fill="white">
        <circle cx="50" cy="55" r="28" />
        <circle cx="28" cy="35" r="10" />
        <circle cx="72" cy="35" r="10" />
        <circle cx="40" cy="50" r="5" fill="#333" />
        <circle cx="60" cy="50" r="5" fill="#333" />
        <ellipse cx="50" cy="62" rx="8" ry="6" fill="#333" />
      </g>
    ),
    eagle: (
      <g fill="white">
        <ellipse cx="50" cy="55" rx="25" ry="28" />
        <circle cx="40" cy="48" r="4" fill="#333" />
        <circle cx="60" cy="48" r="4" fill="#333" />
        <polygon points="50,55 42,68 58,68" fill="#F59E0B" />
        <path d="M25,40 Q20,30 30,35" stroke="white" strokeWidth="4" fill="none" />
        <path d="M75,40 Q80,30 70,35" stroke="white" strokeWidth="4" fill="none" />
      </g>
    ),
    rabbit: (
      <g fill="white">
        <ellipse cx="50" cy="60" rx="22" ry="20" />
        <ellipse cx="38" cy="25" rx="8" ry="25" />
        <ellipse cx="62" cy="25" rx="8" ry="25" />
        <ellipse cx="38" cy="25" rx="4" ry="18" fill="#FFB6C1" />
        <ellipse cx="62" cy="25" rx="4" ry="18" fill="#FFB6C1" />
        <circle cx="42" cy="55" r="4" fill="#333" />
        <circle cx="58" cy="55" r="4" fill="#333" />
        <ellipse cx="50" cy="65" rx="3" ry="2" fill="#FFB6C1" />
      </g>
    ),
    wolf: (
      <g fill="white">
        <ellipse cx="50" cy="58" rx="24" ry="22" />
        <polygon points="28,25 38,50 22,50" />
        <polygon points="72,25 62,50 78,50" />
        <circle cx="40" cy="52" r="4" fill="#333" />
        <circle cx="60" cy="52" r="4" fill="#333" />
        <ellipse cx="50" cy="65" rx="6" ry="4" fill="#333" />
      </g>
    ),
  };

  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative flex flex-col items-center gap-2 p-3 rounded-xl transition-all ${
        selected ? "ring-2 ring-primary bg-primary/10" : "hover:bg-muted"
      }`}
      data-testid={`avatar-${avatar.id}`}
    >
      <div className="relative">
        <svg width="80" height="80" viewBox="0 0 100 100" className="rounded-full shadow-lg">
          <circle cx="50" cy="50" r="50" fill={avatar.bgColor} />
          {animalPaths[avatar.emoji]}
        </svg>
        {selected && (
          <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground rounded-full p-1">
            <Check className="w-4 h-4" />
          </div>
        )}
      </div>
      <span className="text-xs font-medium text-center">{avatar.name}</span>
    </button>
  );
}

export function getAvatarUrl(user: { avatarType?: string | null; customAvatarUrl?: string | null; selectedAvatar?: string | null } | null): string | null {
  if (!user) return null;
  if (user.avatarType === "custom" && user.customAvatarUrl) {
    return user.customAvatarUrl;
  }
  return null;
}

export function getCartoonAvatarById(avatarId: string | null): typeof CARTOON_AVATARS[0] | null {
  if (!avatarId) return null;
  return CARTOON_AVATARS.find(a => a.id === avatarId) || null;
}

export { CARTOON_AVATARS };

export default function Onboarding() {
  const { user, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [step, setStep] = useState(1);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [nationality, setNationality] = useState("");
  const [politicalAffiliation, setPoliticalAffiliation] = useState("");
  const [avatarType, setAvatarType] = useState("default");
  const [selectedAvatar, setSelectedAvatar] = useState("");
  const [customAvatarUrl, setCustomAvatarUrl] = useState("");
  const [favoriteCategories, setFavoriteCategories] = useState<string[]>([]);
  
  const { isInstallable, isInstalled, promptInstall } = usePWAInstall();
  
  const { uploadFile, isUploading, progress } = useUpload({
    onSuccess: (response) => {
      setCustomAvatarUrl(response.objectPath);
      setAvatarType("custom");
    },
  });

  const { data: categories = [] } = useQuery<string[]>({
    queryKey: ["/api/categories"],
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: {
      firstName: string;
      lastName: string;
      nationality: string;
      politicalAffiliation: string;
      avatarType: string;
      customAvatarUrl: string;
      favoriteCategories: string[];
    }) => {
      await apiRequest("PATCH", "/api/user/profile", data);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      if (isInstallable && !isInstalled) {
        setShowInstallPrompt(true);
      } else {
        navigate("/");
      }
    },
  });
  
  const handleInstall = async () => {
    await promptInstall();
    navigate("/");
  };
  
  const handleSkipInstall = () => {
    setShowInstallPrompt(false);
    navigate("/");
  };

  useEffect(() => {
    if (user) {
      setFirstName(user.firstName || "");
      setLastName(user.lastName || "");
    }
  }, [user]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await uploadFile(file);
    }
  };

  const toggleCategory = (category: string) => {
    setFavoriteCategories(prev => 
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category].slice(0, 5)
    );
  };

  const handleSubmit = () => {
    updateProfileMutation.mutate({
      firstName,
      lastName,
      nationality,
      politicalAffiliation,
      avatarType,
      customAvatarUrl: avatarType === "custom" ? customAvatarUrl : selectedAvatar,
      favoriteCategories,
    });
  };

  const canProceed = () => {
    switch (step) {
      case 1: return firstName.trim().length > 0;
      case 2: return nationality !== "";
      case 3: return avatarType !== "";
      case 4: return politicalAffiliation !== "";
      case 5: return favoriteCategories.length > 0;
      default: return true;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold font-display mb-2">Welcome to Debate Wars</h1>
          <p className="text-muted-foreground">Let's set up your debater profile</p>
          <div className="flex justify-center gap-2 mt-4">
            {[1, 2, 3, 4, 5].map((s) => (
              <div
                key={s}
                className={`w-3 h-3 rounded-full transition-colors ${
                  s <= step ? "bg-primary" : "bg-muted"
                }`}
              />
            ))}
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="shadow-lg" data-testid="onboarding-card">
              {step === 1 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5" />
                      Your Name
                    </CardTitle>
                    <CardDescription>How should we call you in debates?</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                          id="firstName"
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                          placeholder="John"
                          data-testid="input-first-name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                          id="lastName"
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                          placeholder="Doe"
                          data-testid="input-last-name"
                        />
                      </div>
                    </div>
                  </CardContent>
                </>
              )}

              {step === 2 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="w-5 h-5" />
                      Your Nationality
                    </CardTitle>
                    <CardDescription>Select your country flag to display</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-5 gap-3 max-h-[400px] overflow-y-auto p-1">
                      {COUNTRIES.map((country) => (
                        <button
                          key={country.code}
                          onClick={() => setNationality(country.code)}
                          className={`flex flex-col items-center p-3 rounded-lg transition-all ${
                            nationality === country.code
                              ? "bg-primary/20 border-2 border-primary"
                              : "bg-muted/50 border-2 border-transparent hover-elevate"
                          }`}
                          data-testid={`country-${country.code}`}
                        >
                          <CountryFlag code={country.code} />
                          <span className="text-xs text-center truncate w-full">{country.name}</span>
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </>
              )}

              {step === 3 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Camera className="w-5 h-5" />
                      Your Avatar
                    </CardTitle>
                    <CardDescription>Choose an avatar or upload your own photo</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex justify-center">
                      {avatarType === "default" && selectedAvatar ? (
                        <div className="w-24 h-24">
                          {(() => {
                            const cartoon = CARTOON_AVATARS.find(a => a.id === selectedAvatar);
                            if (cartoon) {
                              const animalPaths: Record<string, JSX.Element> = {
                                cat: <g fill="white"><circle cx="50" cy="55" r="30" /><polygon points="25,30 35,55 15,55" /><polygon points="75,30 65,55 85,55" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="4" ry="3" fill="#333" /><path d="M46,68 Q50,72 54,68" stroke="#333" strokeWidth="2" fill="none" /></g>,
                                owl: <g fill="white"><ellipse cx="50" cy="58" rx="28" ry="25" /><circle cx="38" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="62" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="38" cy="52" r="5" fill="#333" /><circle cx="62" cy="52" r="5" fill="#333" /><polygon points="50,60 46,70 54,70" fill="#F59E0B" /><polygon points="25,35 30,50 20,50" /><polygon points="75,35 70,50 80,50" /></g>,
                                lion: <g><circle cx="50" cy="55" r="35" fill="#F59E0B" /><circle cx="50" cy="58" r="22" fill="white" /><circle cx="42" cy="52" r="4" fill="#333" /><circle cx="58" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="62" rx="5" ry="4" fill="#333" /><path d="M45,70 Q50,75 55,70" stroke="#333" strokeWidth="2" fill="none" /></g>,
                                fox: <g fill="white"><ellipse cx="50" cy="58" rx="25" ry="22" /><polygon points="20,25 35,55 20,55" fill="#EA580C" /><polygon points="80,25 65,55 80,55" fill="#EA580C" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="64" rx="4" ry="3" fill="#333" /></g>,
                                bear: <g fill="white"><circle cx="50" cy="55" r="28" /><circle cx="28" cy="35" r="10" /><circle cx="72" cy="35" r="10" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="8" ry="6" fill="#333" /></g>,
                                eagle: <g fill="white"><ellipse cx="50" cy="55" rx="25" ry="28" /><circle cx="40" cy="48" r="4" fill="#333" /><circle cx="60" cy="48" r="4" fill="#333" /><polygon points="50,55 42,68 58,68" fill="#F59E0B" /><path d="M25,40 Q20,30 30,35" stroke="white" strokeWidth="4" fill="none" /><path d="M75,40 Q80,30 70,35" stroke="white" strokeWidth="4" fill="none" /></g>,
                                rabbit: <g fill="white"><ellipse cx="50" cy="60" rx="22" ry="20" /><ellipse cx="38" cy="25" rx="8" ry="25" /><ellipse cx="62" cy="25" rx="8" ry="25" /><ellipse cx="38" cy="25" rx="4" ry="18" fill="#FFB6C1" /><ellipse cx="62" cy="25" rx="4" ry="18" fill="#FFB6C1" /><circle cx="42" cy="55" r="4" fill="#333" /><circle cx="58" cy="55" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="3" ry="2" fill="#FFB6C1" /></g>,
                                wolf: <g fill="white"><ellipse cx="50" cy="58" rx="24" ry="22" /><polygon points="28,25 38,50 22,50" /><polygon points="72,25 62,50 78,50" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="6" ry="4" fill="#333" /></g>,
                              };
                              return (
                                <svg width="96" height="96" viewBox="0 0 100 100" className="rounded-full shadow-lg border-4 border-primary">
                                  <circle cx="50" cy="50" r="50" fill={cartoon.bgColor} />
                                  {animalPaths[cartoon.emoji]}
                                </svg>
                              );
                            }
                            return null;
                          })()}
                        </div>
                      ) : (
                        <Avatar className="w-24 h-24 border-4 border-primary">
                          <AvatarImage src={avatarType === "custom" ? customAvatarUrl : (user?.profileImageUrl || "")} />
                          <AvatarFallback className="text-2xl">{firstName?.[0] || "?"}</AvatarFallback>
                        </Avatar>
                      )}
                    </div>
                    
                    <div className="space-y-3">
                      <Label>Upload Photo</Label>
                      <div className="flex items-center gap-3">
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={handleFileChange}
                          className="flex-1"
                          disabled={isUploading}
                          data-testid="input-avatar-upload"
                        />
                        {isUploading && (
                          <div className="flex items-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span className="text-sm">{progress}%</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Label>Or choose a cartoon avatar</Label>
                      <div className="grid grid-cols-4 gap-2">
                        {CARTOON_AVATARS.map((avatar) => (
                          <CartoonAvatar
                            key={avatar.id}
                            avatar={avatar}
                            selected={selectedAvatar === avatar.id && avatarType === "default"}
                            onClick={() => {
                              setSelectedAvatar(avatar.id);
                              setAvatarType("default");
                              setCustomAvatarUrl("");
                            }}
                          />
                        ))}
                      </div>
                    </div>

                    {user?.profileImageUrl && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          setAvatarType("profile");
                          setSelectedAvatar(user.profileImageUrl || "");
                        }}
                        className={avatarType === "profile" ? "border-primary" : ""}
                        data-testid="button-use-profile-photo"
                      >
                        Use my profile photo
                      </Button>
                    )}
                  </CardContent>
                </>
              )}

              {step === 4 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Flag className="w-5 h-5" />
                      Political Affiliation
                    </CardTitle>
                    <CardDescription>This helps match you with relevant debates</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        onClick={() => setPoliticalAffiliation("democrat")}
                        className={`p-6 rounded-xl transition-all flex flex-col items-center gap-3 ${
                          politicalAffiliation === "democrat"
                            ? "bg-blue-500/20 border-2 border-blue-500"
                            : "bg-muted/50 border-2 border-transparent hover-elevate"
                        }`}
                        data-testid="button-democrat"
                      >
                        <div className="w-16 h-16 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-2xl">
                          D
                        </div>
                        <span className="font-medium">Democrat</span>
                      </button>
                      <button
                        onClick={() => setPoliticalAffiliation("republican")}
                        className={`p-6 rounded-xl transition-all flex flex-col items-center gap-3 ${
                          politicalAffiliation === "republican"
                            ? "bg-red-500/20 border-2 border-red-500"
                            : "bg-muted/50 border-2 border-transparent hover-elevate"
                        }`}
                        data-testid="button-republican"
                      >
                        <div className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center text-white font-bold text-2xl">
                          R
                        </div>
                        <span className="font-medium">Republican</span>
                      </button>
                    </div>
                    <button
                      onClick={() => setPoliticalAffiliation("independent")}
                      className={`w-full mt-4 p-4 rounded-xl transition-all flex items-center justify-center gap-3 ${
                        politicalAffiliation === "independent"
                          ? "bg-purple-500/20 border-2 border-purple-500"
                          : "bg-muted/50 border-2 border-transparent hover-elevate"
                      }`}
                      data-testid="button-independent"
                    >
                      <div className="w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center text-white font-bold">
                        I
                      </div>
                      <span className="font-medium">Independent / Other</span>
                    </button>
                  </CardContent>
                </>
              )}

              {step === 5 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Heart className="w-5 h-5" />
                      Favorite Categories
                    </CardTitle>
                    <CardDescription>Select up to 5 debate topics you're interested in</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2 max-h-[350px] overflow-y-auto p-1">
                      {categories.map((category) => (
                        <Badge
                          key={category}
                          variant={favoriteCategories.includes(category) ? "default" : "outline"}
                          className={`cursor-pointer px-3 py-2 text-sm transition-all ${
                            favoriteCategories.includes(category)
                              ? "bg-primary"
                              : "hover-elevate"
                          }`}
                          onClick={() => toggleCategory(category)}
                          data-testid={`category-${category.toLowerCase().replace(/\s+/g, '-')}`}
                        >
                          {favoriteCategories.includes(category) && (
                            <Check className="w-3 h-3 mr-1" />
                          )}
                          {category}
                        </Badge>
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">
                      Selected: {favoriteCategories.length}/5
                    </p>
                  </CardContent>
                </>
              )}

              <div className="flex justify-between p-6 pt-0">
                {step > 1 ? (
                  <Button
                    variant="ghost"
                    onClick={() => setStep(step - 1)}
                    data-testid="button-back"
                  >
                    Back
                  </Button>
                ) : (
                  <div />
                )}
                
                {step < 5 ? (
                  <Button
                    onClick={() => setStep(step + 1)}
                    disabled={!canProceed()}
                    data-testid="button-next"
                  >
                    Next
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmit}
                    disabled={!canProceed() || updateProfileMutation.isPending}
                    data-testid="button-finish"
                  >
                    {updateProfileMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Check className="w-4 h-4 mr-2" />
                    )}
                    Finish Setup
                  </Button>
                )}
              </div>
            </Card>
          </motion.div>
        </AnimatePresence>
      </div>
      
      {/* PWA Install Prompt after onboarding */}
      <Dialog open={showInstallPrompt} onOpenChange={(open) => !open && handleSkipInstall()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <PartyPopper className="w-5 h-5 text-primary" />
              Welcome to Debate Wars!
            </DialogTitle>
            <DialogDescription>
              Your profile is set up. Install the app for the best experience!
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <motion.div 
              className="flex justify-center"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 }}
            >
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-indigo-500 flex items-center justify-center shadow-lg">
                <svg width="48" height="48" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="35" fill="rgba(255,255,255,0.1)"/>
                  <path d="M55 20 L35 48 L48 48 L42 80 L65 48 L52 48 Z" fill="#f59e0b"/>
                  <ellipse cx="28" cy="38" rx="12" ry="10" fill="white" opacity="0.9"/>
                  <ellipse cx="72" cy="62" rx="12" ry="10" fill="white" opacity="0.9"/>
                </svg>
              </div>
            </motion.div>
            
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                <span>Launch from your home screen</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                <span>Full-screen debate experience</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                <span>Get notified for new challenges</span>
              </div>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={handleSkipInstall}
              className="flex-1"
              data-testid="button-skip-install"
            >
              Continue in Browser
            </Button>
            <Button 
              onClick={handleInstall}
              className="flex-1"
              data-testid="button-install-now"
            >
              <Download className="w-4 h-4 mr-2" />
              Install App
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
