import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserPlus, Swords, Check, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";

interface InviteData {
  id: string;
  code: string;
  creatorId: string;
  inviteType: string;
  used: string;
  expiresAt: string | null;
  creator?: {
    id: string;
    firstName: string | null;
    lastName: string | null;
    profileImageUrl: string | null;
    eloRating: string | null;
  };
}

export default function Invite() {
  const { code } = useParams<{ code: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  const { data: invite, isLoading, error } = useQuery<InviteData>({
    queryKey: ["/api/invites", code],
    enabled: !!code,
  });

  const acceptInvite = useMutation({
    mutationFn: () => apiRequest("POST", `/api/invites/${code}/accept`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/relationships"] });
      toast({
        title: "Invite accepted!",
        description: invite?.inviteType === "friend" 
          ? "You are now friends!" 
          : "You are now rivals!",
      });
      navigate("/profile");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to accept invite",
        variant: "destructive",
      });
    },
  });

  if (isLoading || authLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="container max-w-md py-12 px-4">
        <Card>
          <CardHeader className="text-center">
            <CardTitle>Login Required</CardTitle>
            <CardDescription>
              You need to log in to accept this invite
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Button onClick={() => window.location.href = "/api/login"} data-testid="button-login">
              Log In with Replit
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error || !invite) {
    return (
      <div className="container max-w-md py-12 px-4">
        <Card>
          <CardHeader className="text-center">
            <X className="h-12 w-12 text-destructive mx-auto mb-4" />
            <CardTitle>Invalid Invite</CardTitle>
            <CardDescription>
              This invite link is invalid or has expired.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Button variant="outline" onClick={() => navigate("/")} data-testid="button-go-home">
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (invite.used === "true") {
    return (
      <div className="container max-w-md py-12 px-4">
        <Card>
          <CardHeader className="text-center">
            <Check className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <CardTitle>Invite Already Used</CardTitle>
            <CardDescription>
              This invite has already been accepted.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Button variant="outline" onClick={() => navigate("/profile")} data-testid="button-go-profile">
              View Profile
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isFriend = invite.inviteType === "friend";

  return (
    <div className="container max-w-md py-12 px-4">
      <Card className={isFriend ? "border-green-500/30" : "border-red-500/30"}>
        <CardHeader className="text-center">
          <div className={`h-16 w-16 rounded-full mx-auto mb-4 flex items-center justify-center ${isFriend ? "bg-green-500/20" : "bg-red-500/20"}`}>
            {isFriend ? (
              <UserPlus className="h-8 w-8 text-green-500" />
            ) : (
              <Swords className="h-8 w-8 text-red-500" />
            )}
          </div>
          <CardTitle>
            {isFriend ? "Friend Request" : "Rival Challenge"}
          </CardTitle>
          <CardDescription>
            {invite.creator?.firstName} wants to add you as a {isFriend ? "friend" : "rival"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-center gap-4 p-4 bg-muted/50 rounded-lg">
            <Avatar className="h-16 w-16">
              <AvatarImage src={invite.creator?.profileImageUrl || undefined} />
              <AvatarFallback className="text-xl">
                {invite.creator?.firstName?.[0] || "?"}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold text-lg">
                {invite.creator?.firstName} {invite.creator?.lastName}
              </p>
              <p className="text-muted-foreground">
                {invite.creator?.eloRating || "1000"} ELO
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              className="flex-1"
              variant="outline"
              onClick={() => navigate("/")}
              data-testid="button-decline"
            >
              Decline
            </Button>
            <Button
              className={`flex-1 ${isFriend ? "bg-green-600" : "bg-red-600"}`}
              onClick={() => acceptInvite.mutate()}
              disabled={acceptInvite.isPending}
              data-testid="button-accept"
            >
              {acceptInvite.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : null}
              Accept
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
