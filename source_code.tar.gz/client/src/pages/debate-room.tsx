import { useParams } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useDebate, useJoinDebate, useCreateTurn, useReJudgeDebate } from "@/hooks/use-debates";
import { useSpeechRecognition } from "@/hooks/use-speech-recognition";
import { useTextToSpeech } from "@/hooks/use-text-to-speech";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { UserAvatar } from "@/components/user-avatar";
import { ClickableAvatar } from "@/components/clickable-avatar";
import { EloBadge } from "@/components/elo-badge";
import { CountryFlag } from "@/components/country-flag";
import { JudgmentDisplay } from "@/components/judgment-display";
import { MobileDebateLayout } from "@/components/mobile-debate-layout";
import { DebateSkillsChart } from "@/components/debate-skills-chart";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Mic, Square, Send, Share2, Trophy, AlertCircle, Bot, Volume2, VolumeX, Play, Pause, Info } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

const ROUND_CONFIGS = [
  { round: 1, wordLimit: 300, label: "Opening Arguments" },
  { round: 2, wordLimit: 300, label: "Rebuttals" },
  { round: 3, wordLimit: 100, label: "Closing Statements" },
];

// Client-side cleanup for any remaining repetitions
function cleanupTranscript(text: string): string {
  if (!text) return text;
  
  const words = text.split(/\s+/);
  const result: string[] = [];
  
  for (let i = 0; i < words.length; i++) {
    // Check for phrase repetitions (2-10 words)
    let foundRepeat = false;
    for (let len = 2; len <= Math.min(10, result.length); len++) {
      const recentPhrase = result.slice(-len).join(' ').toLowerCase();
      const currentPhrase = words.slice(i, i + len).join(' ').toLowerCase();
      if (recentPhrase === currentPhrase) {
        i += len - 1;
        foundRepeat = true;
        break;
      }
    }
    if (foundRepeat) continue;
    
    // Skip single word repetitions
    if (result.length > 0 && words[i]?.toLowerCase() === result[result.length - 1]?.toLowerCase()) {
      continue;
    }
    result.push(words[i]);
  }
  
  return result.join(' ').trim();
}

export default function DebateRoom() {
  const { id } = useParams();
  const debateId = parseInt(id || "0");
  const { user } = useAuth();
  
  const { data: debate, isLoading, refetch } = useDebate(debateId);
  const { mutate: joinDebate, isPending: isJoining } = useJoinDebate();
  const { mutate: submitTurn, isPending: isSubmitting } = useCreateTurn();
  const { mutate: reJudge, isPending: isReJudging } = useReJudgeDebate(debateId);
  
  const { 
    isListening, 
    transcript, 
    startListening, 
    stopListening, 
    resetTranscript,
    isSupported 
  } = useSpeechRecognition();
  
  const { speak, stop: stopSpeaking, isSpeaking } = useTextToSpeech();

  const [manualText, setManualText] = useState("");
  const [isManualInput, setIsManualInput] = useState(true); // Default to text input for reliability
  const [playingTurnId, setPlayingTurnId] = useState<number | null>(null);
  const [hasRecorded, setHasRecorded] = useState(false); // Track if recording stopped with content
  const [showAiOpponentModal, setShowAiOpponentModal] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  // Word count helper
  const countWords = (text: string) => {
    if (!text.trim()) return 0;
    return text.trim().split(/\s+/).filter(w => w.length > 0).length;
  };
  
  // Auto-speak new AI turns
  const lastAITurnRef = useRef<number | null>(null);
  useEffect(() => {
    if (!debate?.turns) return;
    const aiTurns = debate.turns.filter(t => t.isAI);
    const latestAITurn = aiTurns[aiTurns.length - 1];
    if (latestAITurn && latestAITurn.id !== lastAITurnRef.current) {
      lastAITurnRef.current = latestAITurn.id;
      // Auto-read the AI argument
      speak(latestAITurn.transcript);
    }
  }, [debate?.turns, speak]);

  useEffect(() => {
    if (transcript) setManualText(transcript);
  }, [transcript]);
  
  // Reset playingTurnId when speech ends (must be before early returns)
  useEffect(() => {
    if (!isSpeaking && playingTurnId !== null) {
      const timeout = setTimeout(() => {
        if (!isSpeaking) setPlayingTurnId(null);
      }, 100);
      return () => clearTimeout(timeout);
    }
  }, [isSpeaking, playingTurnId]);

  // Polling for AI opponent turns
  useEffect(() => {
    if (!debate || debate.status !== 'active') return;
    if (debate.opponentType !== 'ai') return;
    
    // Poll every 2 seconds while waiting for AI turn
    const interval = setInterval(() => {
      refetch();
    }, 2000);
    
    return () => clearInterval(interval);
  }, [debate?.status, debate?.opponentType, refetch]);


  // Handle late transcript arrival after recording stops
  useEffect(() => {
    if (!isListening && hasRecorded && transcript && !manualText) {
      setManualText(transcript);
    }
  }, [isListening, hasRecorded, transcript, manualText]);

  if (isLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!debate) {
    return <div className="text-center py-20">Debate not found</div>;
  }

  const isCreator = user?.id === debate.creatorId;
  const isOpponent = user?.id === debate.opponentId;
  const isAIOpponent = debate.opponentType === 'ai';
  const isParticipant = isCreator || isOpponent;
  const canJoin = !isParticipant && !debate.opponentId && debate.status === 'waiting' && !isAIOpponent;

  // Group turns by round
  const turnsByRound: Record<number, typeof debate.turns> = { 1: [], 2: [], 3: [] };
  (debate.turns || []).forEach(turn => {
    const roundNum = turn.roundNumber || 1;
    if (!turnsByRound[roundNum]) turnsByRound[roundNum] = [];
    turnsByRound[roundNum].push(turn);
  });

  const currentRound = debate.currentRound || 1;
  const currentRoundTurns = turnsByRound[currentRound] || [];
  const currentRoundConfig = ROUND_CONFIGS[currentRound - 1];
  
  // Determine who goes first in this round
  // Rounds 1 & 2: Creator first. Round 3: Opponent first (reversed)
  const isRound3 = currentRound === 3;
  const firstSpeaker = isRound3 ? 'opponent' : 'creator';
  const secondSpeaker = isRound3 ? 'creator' : 'opponent';
  
  // Calculate whose turn it is
  let currentSpeaker: 'creator' | 'opponent' | null = null;
  let isMyTurn = false;
  
  if (debate.status === 'active') {
    if (currentRoundTurns.length === 0) {
      currentSpeaker = firstSpeaker;
    } else if (currentRoundTurns.length === 1) {
      currentSpeaker = secondSpeaker;
    }
    
    if (currentSpeaker === 'creator' && isCreator) isMyTurn = true;
    if (currentSpeaker === 'opponent' && isOpponent) isMyTurn = true;
    if (currentSpeaker === 'opponent' && isAIOpponent && isCreator) {
      // AI is thinking, creator waits
      isMyTurn = false;
    }
  }

  const handleSubmit = () => {
    if (!manualText.trim()) return;
    // Clean up any remaining repetitions before submitting
    const cleanedText = cleanupTranscript(manualText);
    if (!cleanedText) return;
    
    // Enforce word limit (defense in depth)
    if (countWords(cleanedText) > currentWordLimit) return;
    
    submitTurn({ debateId, transcript: cleanedText }, {
      onSuccess: () => {
        setManualText("");
        resetTranscript();
        setIsManualInput(false);
      }
    });
  };

  const handleStartRecording = () => {
    setHasRecorded(false);
    resetTranscript();
    setManualText("");
    startListening();
  };

  const handleStopRecording = () => {
    stopListening();
    // Always mark as recorded - transcript may arrive late via useEffect
    setHasRecorded(true);
    if (transcript) {
      setManualText(transcript);
    }
  };
  
  // Word count values for current round
  const currentWordLimit = currentRoundConfig?.wordLimit || 300;
  const currentWordCount = countWords(manualText);
  const wordsRemaining = currentWordLimit - currentWordCount;
  const isOverLimit = wordsRemaining < 0;

  const getPlayerForTurn = (turn: any) => {
    if (turn.userId === debate.creatorId) return debate.creator;
    if (turn.userId === debate.opponentId) return debate.opponent;
    if (turn.isAI) return { firstName: 'AI', lastName: 'Opponent', profileImageUrl: null };
    return null;
  };

  // Helper to get display name
  const getDisplayName = (player: any) => {
    if (!player) return '?';
    if (player.firstName) return `${player.firstName}${player.lastName ? ' ' + player.lastName : ''}`;
    if (player.email) return player.email.split('@')[0];
    return '?';
  };

  // Input content for the mobile layout
  const inputContent = (
    <div className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="font-bold text-lg text-primary">Your Turn!</h3>
          <Badge variant="outline" className="text-xs">
            R{currentRound} - {currentWordLimit}w
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={isOverLimit ? "destructive" : "secondary"} className="text-sm px-2">
            {currentWordCount}/{currentWordLimit}
          </Badge>
          {isSupported && (
            <Button variant="ghost" size="sm" onClick={() => setIsManualInput(!isManualInput)} className="h-7 text-xs">
              {isManualInput ? <><Mic className="w-3 h-3 mr-1" /> Voice</> : "Type"}
            </Button>
          )}
        </div>
      </div>

      {isManualInput ? (
        <div className="space-y-2">
          <Textarea 
            value={manualText}
            onChange={(e) => setManualText(e.target.value)}
            placeholder="Type your argument here..."
            className={`min-h-[80px] text-base p-3 bg-muted/20 ${isOverLimit ? 'border-red-500 focus-visible:ring-red-500' : ''}`}
            data-testid="textarea-argument-mobile"
          />
          <div className="flex items-center justify-between text-xs">
            <span className={`font-medium ${isOverLimit ? 'text-red-500' : wordsRemaining <= 20 ? 'text-yellow-500' : 'text-muted-foreground'}`}>
              {currentWordCount} / {currentWordLimit} words
            </span>
            <span className={`${isOverLimit ? 'text-red-500 font-medium' : 'text-muted-foreground'}`}>
              {isOverLimit ? `${Math.abs(wordsRemaining)} over` : `${wordsRemaining} left`}
            </span>
          </div>
        </div>
      ) : (
        <div className="bg-card border border-border rounded-lg p-3 space-y-3">
          {isListening ? (
            <div className="text-center space-y-2">
              <div className="flex items-center justify-center gap-2 text-red-500">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="font-medium text-sm">Recording</span>
              </div>
              <div className={`text-3xl font-bold font-mono ${countWords(transcript) > currentWordLimit ? 'text-red-500' : 'text-foreground'}`}>
                {countWords(transcript)} / {currentWordLimit}
              </div>
              {transcript && (
                <p className="text-muted-foreground text-xs leading-relaxed max-h-[40px] overflow-y-auto">
                  {transcript}
                </p>
              )}
              <Button 
                size="sm" 
                variant="destructive"
                className="rounded-full w-12 h-12"
                onClick={handleStopRecording}
                data-testid="button-stop-recording-mobile"
              >
                <Square className="w-4 h-4 fill-current" />
              </Button>
            </div>
          ) : hasRecorded ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground">Edit transcript:</span>
                <Button variant="ghost" size="sm" onClick={handleStartRecording} className="h-6 text-xs">
                  <Mic className="w-3 h-3 mr-1" /> Re-record
                </Button>
              </div>
              <Textarea 
                value={manualText}
                onChange={(e) => setManualText(e.target.value)}
                className={`min-h-[60px] text-sm p-2 bg-muted/20 ${isOverLimit ? 'border-red-500 focus-visible:ring-red-500' : ''}`}
                data-testid="textarea-voice-transcript-mobile"
              />
            </div>
          ) : (
            <div className="text-center space-y-2">
              <p className="text-muted-foreground text-xs">Tap to record</p>
              <Button 
                size="sm" 
                className="rounded-full w-12 h-12 bg-primary hover:bg-primary/90"
                onClick={handleStartRecording}
                data-testid="button-start-recording-mobile"
              >
                <Mic className="w-5 h-5" />
              </Button>
            </div>
          )}
        </div>
      )}

      <Button 
        className="w-full h-10 text-base font-bold" 
        onClick={handleSubmit}
        disabled={!manualText || isSubmitting || isListening || isOverLimit}
        data-testid="button-submit-argument-mobile"
      >
        {isSubmitting ? <Loader2 className="mr-2 animate-spin w-4 h-4" /> : <Send className="mr-2 w-4 h-4" />}
        {isOverLimit ? `Over Limit (${Math.abs(wordsRemaining)})` : 'Submit'}
      </Button>
    </div>
  );

  // History content for the mobile layout  
  const historyContent = (
    <div className="space-y-8 px-4">
      {/* Header Section */}
      <div className="text-center space-y-4 py-8 relative overflow-hidden rounded-3xl bg-gradient-to-br from-background to-muted border border-border/50 shadow-2xl" data-testid="container-debate-header">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[length:20px_20px]" />
        <div className="relative z-10 px-6">
          <div className="flex justify-center gap-3 mb-4 flex-wrap">
            <Badge variant="outline" className="uppercase tracking-wider" data-testid="badge-category">{debate.category}</Badge>
            <Badge className={`${
              debate.status === 'active' ? 'bg-green-500 hover:bg-green-600' : 
              debate.status === 'completed' ? 'bg-purple-500 hover:bg-purple-600' : 
              debate.status === 'judging' ? 'bg-yellow-500 hover:bg-yellow-600' : 'bg-gray-500'
            }`}>
              {debate.status}
            </Badge>
            {isAIOpponent && (
              <Badge className="bg-purple-600">
                <Bot className="w-3 h-3 mr-1" />
                vs AI
              </Badge>
            )}
          </div>
          <h1 className="text-2xl md:text-5xl font-display font-bold leading-tight mb-4 max-w-4xl mx-auto" data-testid="text-debate-topic">
            {debate.topic}
          </h1>
          
          {debate.status === 'waiting' && (
            <div className="flex justify-center gap-4 mt-6 flex-wrap">
              <Button variant="outline" onClick={() => {
                const link = debate.inviteCode 
                  ? `${window.location.origin}/join/${debate.inviteCode}`
                  : window.location.href;
                navigator.clipboard.writeText(link);
              }} data-testid="button-share-link">
                <Share2 className="w-4 h-4 mr-2" /> Share Link
              </Button>
              {canJoin && (
                <Button 
                  onClick={() => joinDebate(debateId)} 
                  disabled={isJoining}
                  className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25 hover:shadow-primary/40 animate-pulse"
                  data-testid="button-accept-challenge"
                >
                  {isJoining ? <Loader2 className="w-4 h-4 animate-spin" /> : "Accept Challenge"}
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Players Bar */}
      <div className="grid grid-cols-2 gap-2 md:gap-4" data-testid="container-players">
        <div className={`flex items-center gap-2 md:gap-3 p-3 md:p-4 rounded-xl border-2 ${debate.winnerId === debate.creatorId ? 'border-accent bg-accent/10' : 'border-border bg-card'}`} data-testid="container-creator">
          <div className="relative shrink-0" data-testid="creator-avatar-container">
            <ClickableAvatar 
              user={debate.creator || null} 
              size="sm" 
              currentUserId={user?.id}
              className="border-2 border-background shadow-sm" 
            />
            {debate.creator?.nationality && (
              <div className="absolute -bottom-1 -right-1" data-testid="creator-flag">
                <CountryFlag code={debate.creator.nationality} size="sm" />
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 flex-wrap">
              <span className="font-bold text-sm truncate" data-testid="creator-name">{getDisplayName(debate.creator)}</span>
              {debate.creator?.eloRating && (
                <EloBadge elo={parseInt(debate.creator.eloRating)} size="sm" data-testid="creator-elo-badge" />
              )}
            </div>
            <Badge variant="secondary" className={`uppercase text-[10px] ${debate.creatorSide === 'pro' ? 'bg-primary/20 text-primary' : 'bg-destructive/20 text-destructive'}`}>
              {debate.creatorSide}
            </Badge>
          </div>
          {debate.winnerId === debate.creatorId && <Trophy className="w-5 h-5 text-accent shrink-0" />}
        </div>

        <div className={`flex items-center gap-2 md:gap-3 p-3 md:p-4 rounded-xl border-2 justify-end text-right ${debate.winnerId === debate.opponentId || (isAIOpponent && debate.winnerId === 'AI_OPPONENT') ? 'border-accent bg-accent/10' : 'border-border bg-card'}`} data-testid="container-opponent">
          {(debate.winnerId === debate.opponentId || (isAIOpponent && debate.winnerId === 'AI_OPPONENT')) && <Trophy className="w-5 h-5 text-accent shrink-0" />}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 flex-wrap justify-end">
              {isAIOpponent && debate.aiOpponent?.eloRating && (
                <EloBadge elo={debate.aiOpponent.eloRating} size="sm" data-testid="ai-opponent-elo-badge" />
              )}
              {!isAIOpponent && debate.opponent?.eloRating && (
                <EloBadge elo={parseInt(debate.opponent.eloRating)} size="sm" data-testid="opponent-elo-badge" />
              )}
              <span className="font-bold text-sm truncate" data-testid="opponent-name">
                {isAIOpponent ? (debate.aiOpponent?.name || 'AI Opponent') : (debate.opponent ? getDisplayName(debate.opponent) : "Waiting...")}
              </span>
            </div>
            <div className="flex items-center gap-1 justify-end">
              <Badge variant="secondary" className={`uppercase text-[10px] ${debate.creatorSide === 'pro' ? 'bg-destructive/20 text-destructive' : 'bg-primary/20 text-primary'}`}>
                {debate.creatorSide === 'pro' ? 'con' : 'pro'}
              </Badge>
              {isAIOpponent && debate.aiOpponent?.difficulty && (
                <Badge variant="outline" className="text-[10px] capitalize">
                  {debate.aiOpponent.difficulty}
                </Badge>
              )}
            </div>
          </div>
          {isAIOpponent ? (
            <button
              onClick={() => setShowAiOpponentModal(true)}
              className="relative shrink-0 hover-elevate rounded-full transition-transform"
              data-testid="button-ai-opponent-profile"
            >
              <Avatar 
                className="w-10 h-10 border-2 border-background shadow-sm"
                style={{ backgroundColor: debate.aiOpponent?.bgColor || 'rgba(168, 85, 247, 0.2)' }}
              >
                {debate.aiOpponent?.avatarId ? (
                  <AvatarImage 
                    src={`/avatars/${debate.aiOpponent.avatarId}.svg`} 
                    alt={debate.aiOpponent.name}
                    className="p-1"
                  />
                ) : null}
                <AvatarFallback className="bg-purple-500/20">
                  <Bot className="w-5 h-5 text-purple-400" />
                </AvatarFallback>
              </Avatar>
              <div 
                className="absolute -bottom-1 -right-1 w-4 h-4 bg-primary rounded-full flex items-center justify-center"
                data-testid="indicator-ai-opponent-info"
              >
                <Info className="w-2.5 h-2.5 text-primary-foreground" />
              </div>
            </button>
          ) : (
            <div className="relative shrink-0" data-testid="opponent-avatar-container">
              <ClickableAvatar 
                user={debate.opponent || null} 
                size="sm" 
                currentUserId={user?.id}
                className="border-2 border-background shadow-sm" 
              />
              {debate.opponent?.nationality && (
                <div className="absolute -bottom-1 -right-1" data-testid="opponent-flag">
                  <CountryFlag code={debate.opponent.nationality} size="sm" />
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Round Progress */}
      <div className="flex items-center justify-center gap-2 md:gap-4">
        {ROUND_CONFIGS.map((config, i) => {
          const roundNum = config.round;
          const isComplete = roundNum < currentRound || debate.status === 'completed' || debate.status === 'judging';
          const isCurrent = roundNum === currentRound && debate.status === 'active';
          
          return (
            <div key={roundNum} className="flex items-center">
              <div className={`flex flex-col items-center gap-1 ${isCurrent ? 'scale-110' : ''} transition-transform`}>
                <div className={`
                  w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center font-bold border-2 transition-colors text-sm md:text-base
                  ${isComplete ? 'bg-primary border-primary text-white' : 
                    isCurrent ? 'bg-primary/20 border-primary text-primary animate-pulse' : 
                    'border-muted text-muted-foreground'}
                `}>
                  {roundNum}
                </div>
                <span className={`text-[10px] md:text-xs ${isCurrent ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                  {config.wordLimit}w
                </span>
              </div>
              {i < 2 && <div className={`w-6 md:w-12 h-1 mx-1 md:mx-2 rounded ${isComplete ? 'bg-primary' : 'bg-muted'}`} />}
            </div>
          );
        })}
      </div>

      {/* Rounds Display */}
      <div className="space-y-4 md:space-y-6">
        {ROUND_CONFIGS.map(config => {
          const roundNum = config.round;
          const roundTurns = turnsByRound[roundNum] || [];
          const isActiveRound = roundNum === currentRound && debate.status === 'active';
          const isRound3Local = roundNum === 3;
          
          const isOpponentTurn = (t: any) => t.userId === debate.opponentId || t.isAI || (!t.userId && isAIOpponent);
          const isCreatorTurn = (t: any) => t.userId === debate.creatorId;
          
          const orderedTurns = isRound3Local 
            ? [roundTurns.find(isOpponentTurn), roundTurns.find(isCreatorTurn)].filter(Boolean)
            : [roundTurns.find(isCreatorTurn), roundTurns.find(isOpponentTurn)].filter(Boolean);

          return (
            <Card 
              key={roundNum} 
              className={`overflow-hidden transition-all ${isActiveRound ? 'ring-2 ring-primary/50' : ''}`}
            >
              <div className={`px-3 md:px-4 py-2 border-b flex items-center justify-between ${isActiveRound ? 'bg-primary/10' : 'bg-muted/30'}`}>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm md:text-base">R{roundNum}</span>
                  <span className="text-xs md:text-sm text-muted-foreground">- {config.label}</span>
                </div>
                <Badge variant="outline" className="text-[10px] md:text-xs">
                  {config.wordLimit}w
                </Badge>
              </div>
              <CardContent className="p-3 md:p-4 space-y-3 md:space-y-4">
                {roundTurns.length === 0 && (roundNum > currentRound || debate.status === 'waiting') && (
                  <div className="text-center py-4 md:py-6 text-muted-foreground text-sm">
                    {roundNum > currentRound ? 'Upcoming round' : 'Waiting to start...'}
                  </div>
                )}
                
                {orderedTurns.map((turn, idx) => {
                  if (!turn) return null;
                  const player = getPlayerForTurn(turn);
                  const isAITurn = turn.isAI;
                  const isCurrentlyPlaying = playingTurnId === turn.id;
                  const isSpeakingThis = isSpeaking && playingTurnId === turn.id;
                  
                  const handlePlayTurn = () => {
                    if (isAITurn) {
                      if (isSpeakingThis) {
                        stopSpeaking();
                        setPlayingTurnId(null);
                      } else {
                        stopSpeaking();
                        setPlayingTurnId(turn.id);
                        speak(turn.transcript);
                      }
                    } else if (turn.audioUrl) {
                      if (audioRef.current) {
                        if (isCurrentlyPlaying) {
                          audioRef.current.pause();
                          setPlayingTurnId(null);
                        } else {
                          audioRef.current.src = turn.audioUrl;
                          audioRef.current.play();
                          setPlayingTurnId(turn.id);
                        }
                      }
                    } else {
                      if (isSpeakingThis) {
                        stopSpeaking();
                        setPlayingTurnId(null);
                      } else {
                        stopSpeaking();
                        setPlayingTurnId(turn.id);
                        speak(turn.transcript);
                      }
                    }
                  };
                  
                  return (
                    <motion.div
                      key={turn.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex gap-3"
                    >
                      {isAITurn ? (
                        <Avatar className="w-8 h-8 md:w-10 md:h-10 shrink-0">
                          <AvatarFallback className="bg-purple-500/20">
                            <Bot className="w-4 h-4 md:w-5 md:h-5 text-purple-400" />
                          </AvatarFallback>
                        </Avatar>
                      ) : (
                        <ClickableAvatar 
                          user={player || null} 
                          size="sm" 
                          currentUserId={user?.id}
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{isAITurn ? 'AI' : getDisplayName(player)}</span>
                          {isAITurn && <Bot className="w-3 h-3 text-purple-400" />}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 ml-auto"
                            onClick={handlePlayTurn}
                            data-testid={`button-play-turn-${turn.id}`}
                          >
                            {(isSpeakingThis || isCurrentlyPlaying) ? (
                              <VolumeX className="w-3 h-3" />
                            ) : (
                              <Volume2 className="w-3 h-3" />
                            )}
                          </Button>
                        </div>
                        <div className="bg-muted/30 p-3 rounded-xl text-sm leading-relaxed border border-border/50">
                          "{turn.transcript}"
                        </div>
                      </div>
                    </motion.div>
                  );
                })}

                {isActiveRound && roundTurns.length < 2 && (
                  <div className="flex items-center justify-center py-3 text-muted-foreground text-sm" data-testid={`status-round-${roundNum}`}>
                    {isAIOpponent && ((isRound3Local && roundTurns.length === 0) || (!isRound3Local && roundTurns.length === 1)) ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>AI thinking...</span>
                      </div>
                    ) : roundTurns.length === 0 ? (
                      <span>Waiting for {isRound3Local ? (isAIOpponent ? 'AI' : 'opponent') : 'creator'}...</span>
                    ) : (
                      <span>Waiting for {isRound3Local ? 'creator' : (isAIOpponent ? 'AI' : 'opponent')}...</span>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      {/* AI Judgment Display */}
      {debate.status === 'completed' && debate.judgment && debate.creator && (debate.opponent || debate.aiOpponent) && (
        <JudgmentDisplay
          judgment={debate.judgment}
          creator={{
            id: debate.creatorId,
            username: getDisplayName(debate.creator),
            profileImageUrl: debate.creator.profileImageUrl
          }}
          opponent={isAIOpponent && debate.aiOpponent ? {
            id: 'AI_OPPONENT',
            username: debate.aiOpponent.name,
            profileImageUrl: `/avatars/${debate.aiOpponent.avatarId || 'cartoon1'}.svg`
          } : {
            id: debate.opponentId || "",
            username: getDisplayName(debate.opponent),
            profileImageUrl: debate.opponent?.profileImageUrl
          }}
          creatorSide={debate.creatorSide as "pro" | "con"}
          winnerId={debate.winnerId}
          onReJudge={() => reJudge()}
          isReJudging={isReJudging}
          showReJudgeButton={!debate.winnerId && debate.turns && debate.turns.length >= 6 && isParticipant}
        />
      )}

      {/* Loading State for AI Judging */}
      {debate.status === 'judging' && (
        <div className="text-center py-8 md:py-12 space-y-4">
           <Loader2 className="w-10 h-10 md:w-12 md:h-12 animate-spin mx-auto text-primary" />
           <h3 className="text-lg md:text-xl font-bold">AI Judge is deliberating...</h3>
           <p className="text-muted-foreground text-sm">Analyzing all 3 rounds.</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="h-[calc(100vh-80px)] max-w-5xl mx-auto">
      {/* Hidden audio element for human audio playback */}
      <audio 
        ref={audioRef} 
        onEnded={() => setPlayingTurnId(null)}
        className="hidden"
      />
      
      <MobileDebateLayout
        historyContent={historyContent}
        inputContent={inputContent}
        isInputVisible={isMyTurn}
      />

      {/* AI Opponent Profile Modal */}
      {debate.aiOpponent && (
        <Dialog open={showAiOpponentModal} onOpenChange={setShowAiOpponentModal}>
          <DialogContent className="sm:max-w-md" data-testid="modal-ai-opponent-profile">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Avatar 
                  className="w-12 h-12"
                  style={{ backgroundColor: debate.aiOpponent.bgColor || 'rgba(168, 85, 247, 0.2)' }}
                  data-testid="avatar-ai-opponent-modal"
                >
                  <AvatarImage 
                    src={`/avatars/${debate.aiOpponent.avatarId || 'cartoon1'}.svg`} 
                    alt={debate.aiOpponent.name}
                    className="p-1"
                  />
                  <AvatarFallback>
                    <Bot className="w-6 h-6" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-bold" data-testid="text-ai-opponent-name">{debate.aiOpponent.name}</div>
                  <div className="flex items-center gap-2 text-sm font-normal">
                    <Badge variant="outline" className="capitalize" data-testid="badge-ai-opponent-difficulty">{debate.aiOpponent.difficulty}</Badge>
                    <EloBadge elo={debate.aiOpponent.eloRating} size="sm" data-testid="badge-ai-opponent-elo" />
                  </div>
                </div>
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div data-testid="container-ai-opponent-skills">
                <h4 className="text-sm font-semibold mb-2">Debate Skills</h4>
                <div className="flex justify-center">
                  <DebateSkillsChart
                    logic={debate.aiOpponent.logicSkill}
                    evidence={debate.aiOpponent.evidenceSkill}
                    persuasion={debate.aiOpponent.persuasionSkill}
                    rebuttals={debate.aiOpponent.rebuttalsSkill}
                    size={160}
                  />
                </div>
              </div>
              
              <div data-testid="container-ai-opponent-personality">
                <h4 className="text-sm font-semibold mb-1">Personality</h4>
                <p className="text-sm text-muted-foreground" data-testid="text-ai-opponent-personality">{debate.aiOpponent.personality}</p>
              </div>
              
              {debate.aiOpponent.specialTrait && (
                <div data-testid="container-ai-opponent-special-trait">
                  <h4 className="text-sm font-semibold mb-1">Special Trait</h4>
                  <Badge variant="secondary" className="capitalize" data-testid="badge-ai-opponent-special-trait">
                    {debate.aiOpponent.specialTrait.replace(/_/g, ' ')}
                  </Badge>
                </div>
              )}
              
              <div className="flex justify-between text-sm text-muted-foreground border-t pt-3" data-testid="container-ai-opponent-stats">
                <span data-testid="text-ai-opponent-wins">Wins: {debate.aiOpponent.wins}</span>
                <span data-testid="text-ai-opponent-losses">Losses: {debate.aiOpponent.losses}</span>
                <span data-testid="text-ai-opponent-winrate">Win Rate: {debate.aiOpponent.wins + debate.aiOpponent.losses > 0 
                  ? Math.round((debate.aiOpponent.wins / (debate.aiOpponent.wins + debate.aiOpponent.losses)) * 100) 
                  : 0}%</span>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
