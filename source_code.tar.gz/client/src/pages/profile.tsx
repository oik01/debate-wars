import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { Trophy, Users, UserMinus, UserPlus, Swords, Copy, Check, Search, Crown, TrendingUp, TrendingDown, BarChart, Settings, Camera, Loader2, ZoomIn, ZoomOut, Crop, Flag, Clock, UserCheck, UserX, Inbox, Send, History, MessageSquare, RotateCcw, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
import { EloBadge } from "@/components/elo-badge";
import { CountryFlag } from "@/components/country-flag";
import { UserAvatar } from "@/components/user-avatar";
import { ClickableAvatar } from "@/components/clickable-avatar";
import { DebateSkillsStats } from "@/components/debate-skills-chart";
import { CARTOON_AVATARS } from "@/pages/onboarding";
import { useUpload } from "@/hooks/use-upload";
import Cropper from "react-easy-crop";
import type { Area, Point } from "react-easy-crop";

async function createCroppedImage(imageSrc: string, pixelCrop: Area): Promise<Blob> {
  const image = await createImage(imageSrc);
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");

  if (!ctx) {
    throw new Error("No 2d context");
  }

  canvas.width = pixelCrop.width;
  canvas.height = pixelCrop.height;

  ctx.drawImage(
    image,
    pixelCrop.x,
    pixelCrop.y,
    pixelCrop.width,
    pixelCrop.height,
    0,
    0,
    pixelCrop.width,
    pixelCrop.height
  );

  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve(blob);
      } else {
        reject(new Error("Canvas is empty"));
      }
    }, "image/jpeg", 0.9);
  });
}

function createImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.addEventListener("load", () => resolve(image));
    image.addEventListener("error", (error) => reject(error));
    image.setAttribute("crossOrigin", "anonymous");
    image.src = url;
  });
}

interface UserProfile {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  avatarType: string | null;
  customAvatarUrl: string | null;
  eloRating: string | null;
  wins: string | null;
  losses: string | null;
  nationality: string | null;
  politicalAffiliation: string | null;
  avgLogicScore: string | null;
  avgEvidenceScore: string | null;
  avgPersuasionScore: string | null;
  avgRebuttalsScore: string | null;
  totalDebatesGraded: string | null;
  rank: number;
  friends: UserProfile[];
  enemies: UserProfile[];
}

interface PoliticalAffiliationStatus {
  canChange: boolean;
  nextChangeDate?: string;
  currentAffiliation: string | null;
  lastChanged: string | null;
}

interface RelationshipRequest {
  id: string;
  senderId: string;
  receiverId: string;
  requestType: string;
  status: string;
  createdAt: string;
  sender?: UserProfile;
  receiver?: UserProfile;
}

interface DebateHistory {
  id: number;
  topic: string;
  category: string;
  status: string;
  creatorId: string;
  opponentId: string | null;
  winnerId: string | null;
  creatorSide: string;
  createdAt: string;
  creator: UserProfile | null;
  opponent: UserProfile | null;
  judgment: {
    id: number;
    explanation: string;
    winnerId: string | null;
    creatorOverallGrade?: string;
    opponentOverallGrade?: string;
  } | null;
}

export default function Profile() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [requestUsername, setRequestUsername] = useState("");
  const [selectedRequestType, setSelectedRequestType] = useState<"friend" | "rival">("friend");
  
  // Avatar settings state
  const [avatarType, setAvatarType] = useState<string>("default");
  const [selectedAvatar, setSelectedAvatar] = useState<string>("");
  const [customAvatarUrl, setCustomAvatarUrl] = useState<string>("");
  const [avatarDialogOpen, setAvatarDialogOpen] = useState(false);
  
  // Image cropping state
  const [imageToCrop, setImageToCrop] = useState<string | null>(null);
  const [crop, setCrop] = useState<Point>({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null);

  const { data: profile, isLoading } = useQuery<UserProfile>({
    queryKey: ["/api/me"],
  });

  // Political affiliation status
  const { data: affiliationStatus } = useQuery<PoliticalAffiliationStatus>({
    queryKey: ["/api/user/political-affiliation/status"],
  });

  // Relationship requests
  const { data: pendingRequests, refetch: refetchPendingRequests } = useQuery<RelationshipRequest[]>({
    queryKey: ["/api/relationship-requests/received"],
  });

  const { data: sentRequests, refetch: refetchSentRequests } = useQuery<RelationshipRequest[]>({
    queryKey: ["/api/relationship-requests/sent"],
  });

  // Debate history
  const { data: debateHistory } = useQuery<DebateHistory[]>({
    queryKey: ["/api/users", profile?.id, "debates"],
    enabled: !!profile?.id,
  });
  
  // Initialize avatar state from profile when it loads
  useEffect(() => {
    if (profile) {
      const profileAvatarType = profile.avatarType || "default";
      setAvatarType(profileAvatarType);
      // customAvatarUrl stores either the upload URL (for custom) or avatar ID (for default)
      if (profileAvatarType === "custom") {
        setCustomAvatarUrl(profile.customAvatarUrl || "");
        setSelectedAvatar("");
      } else {
        setSelectedAvatar(profile.customAvatarUrl || "");
        setCustomAvatarUrl("");
      }
    }
  }, [profile]);
  
  const { uploadFile, isUploading, progress } = useUpload({
    onSuccess: (response) => {
      setCustomAvatarUrl(response.objectPath);
      setAvatarType("custom");
      setSelectedAvatar("");
      setImageToCrop(null);
      setCrop({ x: 0, y: 0 });
      setZoom(1);
    },
  });
  
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImageToCrop(reader.result as string);
        setCrop({ x: 0, y: 0 });
        setZoom(1);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const onCropComplete = useCallback((_croppedArea: Area, croppedAreaPixels: Area) => {
    setCroppedAreaPixels(croppedAreaPixels);
  }, []);
  
  const handleCropConfirm = async () => {
    if (!imageToCrop || !croppedAreaPixels) return;
    
    try {
      const croppedBlob = await createCroppedImage(imageToCrop, croppedAreaPixels);
      const croppedFile = new File([croppedBlob], "avatar.jpg", { type: "image/jpeg" });
      await uploadFile(croppedFile);
    } catch (error) {
      toast({ title: "Failed to crop image", variant: "destructive" });
    }
  };
  
  const handleCropCancel = () => {
    setImageToCrop(null);
    setCrop({ x: 0, y: 0 });
    setZoom(1);
  };
  
  const updateAvatar = useMutation({
    mutationFn: async () => {
      await apiRequest("PATCH", "/api/user/profile", {
        avatarType,
        customAvatarUrl: avatarType === "custom" ? customAvatarUrl : selectedAvatar,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({ title: "Avatar updated successfully!" });
      setAvatarDialogOpen(false);
    },
    onError: () => {
      toast({ title: "Failed to update avatar", variant: "destructive" });
    },
  });

  const { data: searchResults } = useQuery<UserProfile[]>({
    queryKey: ["/api/users", { q: searchQuery }],
    queryFn: async () => {
      const res = await fetch(`/api/users?q=${encodeURIComponent(searchQuery)}`);
      if (!res.ok) throw new Error("Failed to search users");
      return res.json();
    },
    enabled: searchQuery.length >= 2,
  });

  const addFriend = useMutation({
    mutationFn: (targetId: string) => apiRequest("POST", `/api/relationships/friend/${targetId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      toast({ title: "Friend added!" });
    },
  });

  const addEnemy = useMutation({
    mutationFn: (targetId: string) => apiRequest("POST", `/api/relationships/enemy/${targetId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      toast({ title: "Rival added!" });
    },
  });

  const removeRelationship = useMutation({
    mutationFn: (targetId: string) => apiRequest("DELETE", `/api/relationships/${targetId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      toast({ title: "Removed from list" });
    },
  });

  const rejudgeDebate = useMutation({
    mutationFn: (debateId: number) => apiRequest("POST", `/api/debates/${debateId}/rejudge`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", profile?.id, "debates"] });
      toast({ title: "Re-judging debate", description: "The AI is reviewing this debate again..." });
    },
    onError: () => {
      toast({ title: "Failed to rejudge", description: "Could not request re-judgment", variant: "destructive" });
    },
  });

  const createInvite = useMutation({
    mutationFn: (type: string) => apiRequest("POST", "/api/invites", { inviteType: type }),
    onSuccess: async (response) => {
      const data = await response.json();
      const fullUrl = `${window.location.origin}${data.url}`;
      await navigator.clipboard.writeText(fullUrl);
      setCopiedLink(data.inviteType || "friend");
      setTimeout(() => setCopiedLink(null), 2000);
      toast({ title: "Invite link copied!" });
    },
  });

  // Political affiliation mutation
  const changePoliticalAffiliation = useMutation({
    mutationFn: (affiliation: string) => apiRequest("PATCH", "/api/user/political-affiliation", { affiliation }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/political-affiliation/status"] });
      toast({ title: "Political affiliation updated!" });
    },
    onError: (error: any) => {
      toast({ title: error.message || "Failed to update affiliation", variant: "destructive" });
    },
  });

  // Relationship request mutations
  const sendRelationshipRequest = useMutation({
    mutationFn: async ({ receiverId, requestType }: { receiverId: string; requestType: string }) =>
      apiRequest("POST", "/api/relationship-requests", { receiverId, requestType }),
    onSuccess: () => {
      setRequestUsername("");
      refetchSentRequests();
      toast({ title: "Request sent!" });
    },
    onError: async (error: any) => {
      const msg = error.message || "Failed to send request";
      toast({ title: msg, variant: "destructive" });
    },
  });

  const acceptRequest = useMutation({
    mutationFn: (requestId: string) => apiRequest("POST", `/api/relationship-requests/${requestId}/accept`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      refetchPendingRequests();
      toast({ title: "Request accepted!" });
    },
  });

  const declineRequest = useMutation({
    mutationFn: (requestId: string) => apiRequest("POST", `/api/relationship-requests/${requestId}/decline`),
    onSuccess: () => {
      refetchPendingRequests();
      toast({ title: "Request declined" });
    },
  });

  // Use the search results to find user and send request
  const handleSendRequestByUsername = () => {
    if (!requestUsername.trim()) return;
    
    // Use the existing search results if available
    if (searchResults && searchResults.length > 0) {
      const targetUser = searchResults.find((u) => 
        u.id !== profile?.id && 
        (`${u.firstName} ${u.lastName}`.toLowerCase().includes(requestUsername.toLowerCase()) ||
         u.email?.toLowerCase().includes(requestUsername.toLowerCase()))
      );
      if (targetUser) {
        sendRelationshipRequest.mutate({ receiverId: targetUser.id, requestType: selectedRequestType });
        return;
      }
    }
    toast({ title: "User not found. Try searching for them first.", variant: "destructive" });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Please log in to view your profile</p>
      </div>
    );
  }

  const eloRating = parseInt(profile.eloRating || "1000");
  const wins = parseInt(profile.wins || "0");
  const losses = parseInt(profile.losses || "0");
  const totalGames = wins + losses;
  const winRate = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;

  return (
    <div className="container max-w-4xl py-8 px-4 space-y-6">
      <Card className="bg-gradient-to-r from-primary/10 to-accent/10">
        <CardContent className="flex flex-col md:flex-row items-center gap-6 py-6">
          <button 
            onClick={() => setAvatarDialogOpen(true)}
            className="relative group cursor-pointer"
            data-testid="button-edit-avatar"
          >
            <UserAvatar user={profile} size="lg" className="h-24 w-24 border-4 border-primary group-hover:opacity-80 transition-opacity" />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="bg-black/60 rounded-full p-2">
                <Camera className="h-6 w-6 text-white" />
              </div>
            </div>
            {profile.nationality && (
              <div className="absolute -bottom-1 -right-1" data-testid="flag-nationality">
                <CountryFlag code={profile.nationality} size="md" />
              </div>
            )}
          </button>
          
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center gap-2 justify-center md:justify-start flex-wrap">
              <button 
                onClick={() => setAvatarDialogOpen(true)}
                className="text-2xl font-bold hover:text-primary transition-colors cursor-pointer"
                data-testid="button-edit-name"
              >
                {profile.firstName} {profile.lastName}
              </button>
              <EloBadge elo={eloRating} size="md" data-testid="badge-elo-tier" />
            </div>
            <p className="text-muted-foreground">{profile.email}</p>
          </div>

          <div className="flex flex-wrap gap-4 justify-center">
            <div className="text-center px-4">
              <div className="flex items-center gap-1 justify-center">
                <Crown className="h-5 w-5 text-primary" />
                <span className="text-2xl font-bold" data-testid="text-rank">#{profile.rank}</span>
              </div>
              <p className="text-xs text-muted-foreground">World Rank</p>
            </div>
            <div className="text-center px-4">
              <span className="text-2xl font-bold text-primary" data-testid="text-elo">{eloRating}</span>
              <p className="text-xs text-muted-foreground">ELO Rating</p>
            </div>
            <div className="text-center px-4">
              <div className="flex items-center gap-2">
                <span className="text-primary">{wins}W</span>
                <span className="text-muted-foreground">/</span>
                <span className="text-destructive">{losses}L</span>
              </div>
              <p className="text-xs text-muted-foreground">{winRate}% Win Rate</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <BarChart className="h-5 w-5 text-primary" /> Debate Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-muted/50 rounded-lg" data-testid="stat-total-debates">
              <div className="text-2xl font-bold">{totalGames}</div>
              <div className="text-xs text-muted-foreground">Total Debates</div>
            </div>
            <div className="text-center p-3 bg-primary/10 rounded-lg" data-testid="stat-wins">
              <div className="text-2xl font-bold text-primary">{wins}</div>
              <div className="text-xs text-muted-foreground">Wins</div>
            </div>
            <div className="text-center p-3 bg-destructive/10 rounded-lg" data-testid="stat-losses">
              <div className="text-2xl font-bold text-destructive">{losses}</div>
              <div className="text-xs text-muted-foreground">Losses</div>
            </div>
            <div className="text-center p-3 bg-accent/50 rounded-lg" data-testid="stat-winrate">
              <div className="text-2xl font-bold">{winRate}%</div>
              <div className="text-xs text-muted-foreground">Win Rate</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Trophy className="h-5 w-5 text-accent" /> Debate Skills
          </CardTitle>
          <CardDescription>Your average performance across judged debates</CardDescription>
        </CardHeader>
        <CardContent>
          <DebateSkillsStats
            logic={parseFloat(profile.avgLogicScore || "0")}
            evidence={parseFloat(profile.avgEvidenceScore || "0")}
            persuasion={parseFloat(profile.avgPersuasionScore || "0")}
            rebuttals={parseFloat(profile.avgRebuttalsScore || "0")}
            totalDebatesGraded={parseInt(profile.totalDebatesGraded || "0")}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Search className="h-5 w-5" /> Find & Connect with Users
          </CardTitle>
          <CardDescription>
            Search for other debaters by name or email, then click their avatar to view their profile
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-users"
            />
          </div>
          
          {searchQuery.length >= 2 && (
            <div className="space-y-2">
              {searchResults && searchResults.filter(u => u.id !== profile.id).length > 0 ? (
                searchResults.filter(u => u.id !== profile.id).map((user) => {
                  const isFriend = profile.friends?.some(f => f.id === user.id);
                  const isRival = profile.enemies?.some(e => e.id === user.id);
                  const hasSentRequest = sentRequests?.some(r => r.receiverId === user.id);
                  
                  return (
                    <Card key={user.id} className="p-3 hover-elevate">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <ClickableAvatar 
                            user={user} 
                            size="md" 
                            currentUserId={profile.id}
                          />
                          <div>
                            <p className="font-medium">{user.firstName} {user.lastName}</p>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Badge variant="secondary" className="text-xs">{user.eloRating || "1000"} ELO</Badge>
                              {isFriend && <Badge className="bg-green-500/20 text-green-500 text-xs">Friend</Badge>}
                              {isRival && <Badge className="bg-red-500/20 text-red-500 text-xs">Rival</Badge>}
                              {hasSentRequest && <Badge className="bg-yellow-500/20 text-yellow-500 text-xs">Pending</Badge>}
                            </div>
                          </div>
                        </div>
                        {!isFriend && !isRival && !hasSentRequest && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => sendRelationshipRequest.mutate({ receiverId: user.id, requestType: "friend" })}
                              disabled={sendRelationshipRequest.isPending}
                              data-testid={`button-request-friend-${user.id}`}
                            >
                              <UserPlus className="h-4 w-4 mr-1" />
                              Friend
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => sendRelationshipRequest.mutate({ receiverId: user.id, requestType: "rival" })}
                              disabled={sendRelationshipRequest.isPending}
                              data-testid={`button-request-rival-${user.id}`}
                            >
                              <Swords className="h-4 w-4 mr-1" />
                              Rival
                            </Button>
                          </div>
                        )}
                      </div>
                    </Card>
                  );
                })
              ) : (
                <p className="text-center text-muted-foreground py-4">
                  No users found matching "{searchQuery}"
                </p>
              )}
            </div>
          )}
          
          {searchQuery.length < 2 && (
            <div className="flex flex-wrap gap-2 pt-2">
              <p className="text-sm text-muted-foreground w-full mb-2">Or share an invite link:</p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => createInvite.mutate("friend")}
                disabled={createInvite.isPending}
                data-testid="button-invite-friend"
              >
                {copiedLink === "friend" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                Copy Friend Invite
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => createInvite.mutate("enemy")}
                disabled={createInvite.isPending}
                data-testid="button-invite-enemy"
              >
                {copiedLink === "enemy" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                Copy Rival Invite
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="history">
        <TabsList className="w-full overflow-x-auto flex-nowrap">
          <TabsTrigger value="history" className="flex-shrink-0 px-3" data-testid="tab-history">
            <History className="h-4 w-4 mr-1" />
            <span className="hidden sm:inline">History</span> ({debateHistory?.filter(d => d.status === "completed").length || 0})
          </TabsTrigger>
          <TabsTrigger value="friends" className="flex-shrink-0 px-3" data-testid="tab-friends">
            <Users className="h-4 w-4 mr-1" />
            <span className="hidden sm:inline">Friends</span> ({profile.friends?.length || 0})
          </TabsTrigger>
          <TabsTrigger value="enemies" className="flex-shrink-0 px-3" data-testid="tab-enemies">
            <Swords className="h-4 w-4 mr-1" />
            <span className="hidden sm:inline">Rivals</span> ({profile.enemies?.length || 0})
          </TabsTrigger>
          <TabsTrigger value="requests" className="flex-shrink-0 px-3" data-testid="tab-requests">
            <Inbox className="h-4 w-4 mr-1" />
            <span className="hidden sm:inline">Requests</span> {(pendingRequests?.length || 0) > 0 && <Badge variant="destructive" className="ml-1">{pendingRequests?.length}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex-shrink-0 px-3" data-testid="tab-settings">
            <Settings className="h-4 w-4 mr-1" />
            <span className="hidden sm:inline">Settings</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="friends" className="mt-4">
          {profile.friends?.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No friends yet. Search for users above to add friends!
            </p>
          ) : (
            <div className="grid gap-2">
              {profile.friends?.map((friend) => (
                <Card key={friend.id} className="p-3 hover-elevate">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <ClickableAvatar 
                        user={friend} 
                        size="md" 
                        currentUserId={profile.id}
                      />
                      <div>
                        <p className="font-medium">{friend.firstName} {friend.lastName}</p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Badge variant="secondary" className="text-xs">{friend.eloRating || "1000"} ELO</Badge>
                          <span className="text-green-500">{friend.wins || 0}W</span>
                          <span className="text-red-500">{friend.losses || 0}L</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => removeRelationship.mutate(friend.id)}
                      data-testid={`button-remove-friend-${friend.id}`}
                    >
                      <UserMinus className="h-4 w-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="enemies" className="mt-4">
          {profile.enemies?.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No rivals yet. Search for users above to declare your rival!
            </p>
          ) : (
            <div className="grid gap-2">
              {profile.enemies?.map((enemy) => (
                <Card key={enemy.id} className="p-3 border-red-500/20 hover-elevate">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <ClickableAvatar 
                        user={enemy} 
                        size="md" 
                        currentUserId={profile.id}
                        className="ring-2 ring-red-500/50"
                      />
                      <div>
                        <p className="font-medium">{enemy.firstName} {enemy.lastName}</p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Badge variant="secondary" className="text-xs">{enemy.eloRating || "1000"} ELO</Badge>
                          <span className="text-green-500">{enemy.wins || 0}W</span>
                          <span className="text-red-500">{enemy.losses || 0}L</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => removeRelationship.mutate(enemy.id)}
                      data-testid={`button-remove-enemy-${enemy.id}`}
                    >
                      <UserMinus className="h-4 w-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="requests" className="mt-4 space-y-4">
          {/* Send Request Section */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Send className="h-5 w-5" /> Send Request
              </CardTitle>
              <CardDescription>Use the search above to find users, then send them a friend or rival request</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-2">
                <Input
                  placeholder="Search for a user above first..."
                  value={requestUsername}
                  onChange={(e) => {
                    setRequestUsername(e.target.value);
                    setSearchQuery(e.target.value);
                  }}
                  data-testid="input-request-username"
                />
                <div className="flex gap-2">
                  <Button
                    variant={selectedRequestType === "friend" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedRequestType("friend")}
                    data-testid="button-select-friend"
                  >
                    <UserPlus className="h-4 w-4 mr-1" />
                    Friend
                  </Button>
                  <Button
                    variant={selectedRequestType === "rival" ? "destructive" : "outline"}
                    size="sm"
                    onClick={() => setSelectedRequestType("rival")}
                    data-testid="button-select-rival"
                  >
                    <Swords className="h-4 w-4 mr-1" />
                    Rival
                  </Button>
                </div>
                <Button
                  onClick={handleSendRequestByUsername}
                  disabled={!requestUsername.trim() || sendRelationshipRequest.isPending || !searchResults?.length}
                  data-testid="button-send-request"
                >
                  {sendRelationshipRequest.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    "Send"
                  )}
                </Button>
              </div>
              {requestUsername.length >= 2 && searchResults && searchResults.length > 0 && (
                <div className="text-sm text-muted-foreground">
                  Found {searchResults.filter(u => u.id !== profile?.id).length} matching user(s)
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pending Requests Received */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Inbox className="h-5 w-5" /> Pending Requests
                {(pendingRequests?.length || 0) > 0 && (
                  <Badge variant="destructive">{pendingRequests?.length}</Badge>
                )}
              </CardTitle>
              <CardDescription>Requests from other users waiting for your response</CardDescription>
            </CardHeader>
            <CardContent>
              {!pendingRequests?.length ? (
                <p className="text-center text-muted-foreground py-6">No pending requests</p>
              ) : (
                <div className="space-y-2">
                  {pendingRequests.map((request) => (
                    <div key={request.id} className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={request.sender?.profileImageUrl || undefined} />
                          <AvatarFallback>{request.sender?.firstName?.[0] || "?"}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{request.sender?.firstName} {request.sender?.lastName}</p>
                          <Badge variant={request.requestType === "rival" ? "destructive" : "secondary"}>
                            {request.requestType === "rival" ? "Rival" : "Friend"} Request
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => acceptRequest.mutate(request.id)}
                          disabled={acceptRequest.isPending}
                          data-testid={`button-accept-request-${request.id}`}
                        >
                          <UserCheck className="h-5 w-5 text-green-500" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => declineRequest.mutate(request.id)}
                          disabled={declineRequest.isPending}
                          data-testid={`button-decline-request-${request.id}`}
                        >
                          <UserX className="h-5 w-5 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Sent Requests */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Send className="h-5 w-5" /> Sent Requests
              </CardTitle>
              <CardDescription>Requests you've sent that are waiting for a response</CardDescription>
            </CardHeader>
            <CardContent>
              {!sentRequests?.length ? (
                <p className="text-center text-muted-foreground py-6">No pending sent requests</p>
              ) : (
                <div className="space-y-2">
                  {sentRequests.map((request) => (
                    <div key={request.id} className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={request.receiver?.profileImageUrl || undefined} />
                          <AvatarFallback>{request.receiver?.firstName?.[0] || "?"}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{request.receiver?.firstName} {request.receiver?.lastName}</p>
                          <div className="flex items-center gap-2">
                            <Badge variant={request.requestType === "rival" ? "destructive" : "secondary"}>
                              {request.requestType === "rival" ? "Rival" : "Friend"}
                            </Badge>
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Clock className="h-3 w-3" /> Pending
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          {!debateHistory || debateHistory.filter(d => d.status === "completed").length === 0 ? (
            <Card className="p-8">
              <div className="text-center">
                <History className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-lg font-medium mb-2">No Debate History Yet</p>
                <p className="text-muted-foreground mb-4">
                  Start debating to see your past matches here!
                </p>
                <Link href="/">
                  <Button data-testid="button-start-debating">
                    <Swords className="h-4 w-4 mr-2" />
                    Start Debating
                  </Button>
                </Link>
              </div>
            </Card>
          ) : (
            <div className="space-y-3">
              {debateHistory.filter(d => d.status === "completed").map((debate) => {
                const isCreator = debate.creatorId === profile.id;
                const opponent = isCreator ? debate.opponent : debate.creator;
                const userWon = debate.winnerId === profile.id;
                const isTie = !debate.winnerId;
                const userGrade = isCreator 
                  ? debate.judgment?.creatorOverallGrade 
                  : debate.judgment?.opponentOverallGrade;
                
                return (
                  <Card 
                    key={debate.id}
                    className={`p-4 transition-all ${
                      userWon ? "border-green-500/40 bg-green-500/5" : 
                      isTie ? "border-yellow-500/40 bg-yellow-500/5" : 
                      "border-red-500/40 bg-red-500/5"
                    }`}
                    data-testid={`debate-history-${debate.id}`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <Badge 
                            variant={userWon ? "default" : isTie ? "outline" : "destructive"}
                            className={`${userWon ? "bg-green-600" : ""} text-xs`}
                          >
                            {userWon ? "WIN" : isTie ? "TIE" : "LOSS"}
                          </Badge>
                          <span className="text-sm text-muted-foreground">
                            {new Date(debate.createdAt).toLocaleDateString()}
                          </span>
                          {userGrade && (
                            <Badge variant="outline" className="text-xs">
                              Grade: {userGrade}
                            </Badge>
                          )}
                        </div>
                        <p className="font-medium line-clamp-2 mb-2">
                          {debate.topic}
                        </p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Badge variant="secondary" className="text-xs">
                            {debate.category}
                          </Badge>
                          {opponent && (
                            <div className="flex items-center gap-1">
                              <span>vs</span>
                              <ClickableAvatar 
                                user={opponent} 
                                size="sm" 
                                currentUserId={profile.id}
                              />
                              <span className="font-medium">{opponent.firstName || opponent.email?.split("@")[0] || "Opponent"}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col items-center gap-2">
                        <div className={`flex items-center justify-center w-12 h-12 rounded-full ${
                          userWon ? "bg-green-500/20 text-green-500" : 
                          isTie ? "bg-yellow-500/20 text-yellow-500" : 
                          "bg-red-500/20 text-red-500"
                        }`}>
                          {userWon ? <Trophy className="h-6 w-6" /> : 
                           isTie ? <Swords className="h-6 w-6" /> :
                           <TrendingDown className="h-6 w-6" />}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/50">
                      <Link href={`/debate/${debate.id}`} className="flex-1">
                        <Button variant="outline" size="sm" className="w-full" data-testid={`button-view-debate-${debate.id}`}>
                          <ExternalLink className="h-4 w-4 mr-2" />
                          View Debate
                        </Button>
                      </Link>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={(e) => {
                          e.preventDefault();
                          rejudgeDebate.mutate(debate.id);
                        }}
                        disabled={rejudgeDebate.isPending}
                        data-testid={`button-rejudge-${debate.id}`}
                      >
                        {rejudgeDebate.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <RotateCcw className="h-4 w-4" />
                        )}
                        <span className="ml-2">Re-judge</span>
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="settings" className="mt-4 space-y-4">
          {/* Political Affiliation Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Flag className="h-5 w-5" />
                Political Affiliation
              </CardTitle>
              <CardDescription>
                Choose your political affiliation for the Political Arena.
                {!affiliationStatus?.canChange && affiliationStatus?.nextChangeDate && (
                  <span className="block text-yellow-500 mt-1">
                    <Clock className="h-4 w-4 inline mr-1" />
                    You can change again on {new Date(affiliationStatus.nextChangeDate).toLocaleDateString()}
                  </span>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-3">
                {[
                  { value: "democrat", label: "Democrat", badgeColor: "text-blue-500" },
                  { value: "republican", label: "Republican", badgeColor: "text-red-500" },
                  { value: "independent", label: "Independent", badgeColor: "text-purple-500" },
                ].map((party) => {
                  const isSelected = affiliationStatus?.currentAffiliation === party.value;
                  return (
                    <Button
                      key={party.value}
                      variant={isSelected ? "default" : "outline"}
                      disabled={!affiliationStatus?.canChange || changePoliticalAffiliation.isPending || isSelected}
                      onClick={() => changePoliticalAffiliation.mutate(party.value)}
                      data-testid={`button-affiliation-${party.value}`}
                      className={isSelected ? "" : party.badgeColor}
                    >
                      {changePoliticalAffiliation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : isSelected ? (
                        <Check className="h-4 w-4 mr-2" />
                      ) : null}
                      {party.label}
                    </Button>
                  );
                })}
              </div>
              {!affiliationStatus?.currentAffiliation && (
                <p className="text-sm text-muted-foreground">
                  No affiliation selected yet. Choose one to join the Political Arena!
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Change Avatar
              </CardTitle>
              <CardDescription>Choose a cartoon avatar or upload your own photo</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Current avatar preview */}
              <div className="flex justify-center">
                {avatarType === "default" && selectedAvatar ? (
                  <div className="w-24 h-24">
                    {(() => {
                      const cartoon = CARTOON_AVATARS.find(a => a.id === selectedAvatar);
                      if (cartoon) {
                        const animalPaths: Record<string, JSX.Element> = {
                          cat: <g fill="white"><circle cx="50" cy="55" r="30" /><polygon points="25,30 35,55 15,55" /><polygon points="75,30 65,55 85,55" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="4" ry="3" fill="#333" /><path d="M46,68 Q50,72 54,68" stroke="#333" strokeWidth="2" fill="none" /></g>,
                          owl: <g fill="white"><ellipse cx="50" cy="58" rx="28" ry="25" /><circle cx="38" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="62" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="38" cy="52" r="5" fill="#333" /><circle cx="62" cy="52" r="5" fill="#333" /><polygon points="50,60 46,70 54,70" fill="#F59E0B" /><polygon points="25,35 30,50 20,50" /><polygon points="75,35 70,50 80,50" /></g>,
                          lion: <g><circle cx="50" cy="55" r="35" fill="#F59E0B" /><circle cx="50" cy="58" r="22" fill="white" /><circle cx="42" cy="52" r="4" fill="#333" /><circle cx="58" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="62" rx="5" ry="4" fill="#333" /><path d="M45,70 Q50,75 55,70" stroke="#333" strokeWidth="2" fill="none" /></g>,
                          fox: <g fill="white"><ellipse cx="50" cy="58" rx="25" ry="22" /><polygon points="20,25 35,55 20,55" fill="#EA580C" /><polygon points="80,25 65,55 80,55" fill="#EA580C" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="64" rx="4" ry="3" fill="#333" /></g>,
                          bear: <g fill="white"><circle cx="50" cy="55" r="28" /><circle cx="28" cy="35" r="10" /><circle cx="72" cy="35" r="10" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="8" ry="6" fill="#333" /></g>,
                          eagle: <g fill="white"><ellipse cx="50" cy="55" rx="25" ry="28" /><circle cx="40" cy="48" r="4" fill="#333" /><circle cx="60" cy="48" r="4" fill="#333" /><polygon points="50,55 42,68 58,68" fill="#F59E0B" /><path d="M25,40 Q20,30 30,35" stroke="white" strokeWidth="4" fill="none" /><path d="M75,40 Q80,30 70,35" stroke="white" strokeWidth="4" fill="none" /></g>,
                          rabbit: <g fill="white"><ellipse cx="50" cy="60" rx="22" ry="20" /><ellipse cx="38" cy="25" rx="8" ry="25" /><ellipse cx="62" cy="25" rx="8" ry="25" /><ellipse cx="38" cy="25" rx="4" ry="18" fill="#FFB6C1" /><ellipse cx="62" cy="25" rx="4" ry="18" fill="#FFB6C1" /><circle cx="42" cy="55" r="4" fill="#333" /><circle cx="58" cy="55" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="3" ry="2" fill="#FFB6C1" /></g>,
                          wolf: <g fill="white"><ellipse cx="50" cy="58" rx="24" ry="22" /><polygon points="28,25 38,50 22,50" /><polygon points="72,25 62,50 78,50" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="6" ry="4" fill="#333" /></g>,
                        };
                        return (
                          <svg width="96" height="96" viewBox="0 0 100 100" className="rounded-full shadow-lg border-4 border-primary">
                            <circle cx="50" cy="50" r="50" fill={cartoon.bgColor} />
                            {animalPaths[cartoon.emoji]}
                          </svg>
                        );
                      }
                      return null;
                    })()}
                  </div>
                ) : avatarType === "custom" && customAvatarUrl ? (
                  <Avatar className="w-24 h-24 border-4 border-primary">
                    <AvatarImage src={customAvatarUrl} />
                    <AvatarFallback className="text-2xl">{profile.firstName?.[0] || "?"}</AvatarFallback>
                  </Avatar>
                ) : (
                  <UserAvatar user={profile} size="lg" className="h-24 w-24 border-4 border-primary" />
                )}
              </div>
              
              {/* Upload photo option */}
              <div className="space-y-3">
                <Label>Upload Photo</Label>
                <div className="flex items-center gap-3">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="flex-1"
                    disabled={isUploading}
                    data-testid="input-avatar-upload"
                  />
                  {isUploading && (
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">{progress}%</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Cartoon avatar selection */}
              <div className="space-y-3">
                <Label>Or choose a cartoon avatar</Label>
                <div className="grid grid-cols-4 gap-3">
                  {CARTOON_AVATARS.map((avatar) => {
                    const isSelected = selectedAvatar === avatar.id && avatarType === "default";
                    const animalPaths: Record<string, JSX.Element> = {
                      cat: <g fill="white"><circle cx="50" cy="55" r="30" /><polygon points="25,30 35,55 15,55" /><polygon points="75,30 65,55 85,55" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="4" ry="3" fill="#333" /><path d="M46,68 Q50,72 54,68" stroke="#333" strokeWidth="2" fill="none" /></g>,
                      owl: <g fill="white"><ellipse cx="50" cy="58" rx="28" ry="25" /><circle cx="38" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="62" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="38" cy="52" r="5" fill="#333" /><circle cx="62" cy="52" r="5" fill="#333" /><polygon points="50,60 46,70 54,70" fill="#F59E0B" /><polygon points="25,35 30,50 20,50" /><polygon points="75,35 70,50 80,50" /></g>,
                      lion: <g><circle cx="50" cy="55" r="35" fill="#F59E0B" /><circle cx="50" cy="58" r="22" fill="white" /><circle cx="42" cy="52" r="4" fill="#333" /><circle cx="58" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="62" rx="5" ry="4" fill="#333" /><path d="M45,70 Q50,75 55,70" stroke="#333" strokeWidth="2" fill="none" /></g>,
                      fox: <g fill="white"><ellipse cx="50" cy="58" rx="25" ry="22" /><polygon points="20,25 35,55 20,55" fill="#EA580C" /><polygon points="80,25 65,55 80,55" fill="#EA580C" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="64" rx="4" ry="3" fill="#333" /></g>,
                      bear: <g fill="white"><circle cx="50" cy="55" r="28" /><circle cx="28" cy="35" r="10" /><circle cx="72" cy="35" r="10" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="8" ry="6" fill="#333" /></g>,
                      eagle: <g fill="white"><ellipse cx="50" cy="55" rx="25" ry="28" /><circle cx="40" cy="48" r="4" fill="#333" /><circle cx="60" cy="48" r="4" fill="#333" /><polygon points="50,55 42,68 58,68" fill="#F59E0B" /><path d="M25,40 Q20,30 30,35" stroke="white" strokeWidth="4" fill="none" /><path d="M75,40 Q80,30 70,35" stroke="white" strokeWidth="4" fill="none" /></g>,
                      rabbit: <g fill="white"><ellipse cx="50" cy="60" rx="22" ry="20" /><ellipse cx="38" cy="25" rx="8" ry="25" /><ellipse cx="62" cy="25" rx="8" ry="25" /><ellipse cx="38" cy="25" rx="4" ry="18" fill="#FFB6C1" /><ellipse cx="62" cy="25" rx="4" ry="18" fill="#FFB6C1" /><circle cx="42" cy="55" r="4" fill="#333" /><circle cx="58" cy="55" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="3" ry="2" fill="#FFB6C1" /></g>,
                      wolf: <g fill="white"><ellipse cx="50" cy="58" rx="24" ry="22" /><polygon points="28,25 38,50 22,50" /><polygon points="72,25 62,50 78,50" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="6" ry="4" fill="#333" /></g>,
                    };
                    return (
                      <button
                        key={avatar.id}
                        type="button"
                        onClick={() => {
                          setSelectedAvatar(avatar.id);
                          setAvatarType("default");
                          setCustomAvatarUrl("");
                        }}
                        className={`relative flex flex-col items-center gap-2 p-3 rounded-xl transition-all ${
                          isSelected ? "ring-2 ring-primary bg-primary/10" : "hover:bg-muted"
                        }`}
                        data-testid={`avatar-${avatar.id}`}
                      >
                        <div className="relative">
                          <svg width="64" height="64" viewBox="0 0 100 100" className="rounded-full shadow-lg">
                            <circle cx="50" cy="50" r="50" fill={avatar.bgColor} />
                            {animalPaths[avatar.emoji]}
                          </svg>
                          {isSelected && (
                            <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground rounded-full p-1">
                              <Check className="w-3 h-3" />
                            </div>
                          )}
                        </div>
                        <span className="text-xs font-medium text-center">{avatar.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
              
              {/* Save button */}
              <Button 
                onClick={() => updateAvatar.mutate()}
                disabled={updateAvatar.isPending || isUploading}
                className="w-full"
                data-testid="button-save-avatar"
              >
                {updateAvatar.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Avatar"
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-center">
        <Link href="/leaderboard">
          <Button variant="outline" data-testid="link-leaderboard">
            <Trophy className="h-4 w-4 mr-2" />
            View World Leaderboard
          </Button>
        </Link>
      </div>

      {/* Avatar Edit Dialog */}
      <Dialog open={avatarDialogOpen} onOpenChange={setAvatarDialogOpen}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Camera className="h-5 w-5" />
              Change Avatar
            </DialogTitle>
            <DialogDescription>Choose a cartoon avatar or upload your own photo</DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Image Cropper */}
            {imageToCrop ? (
              <div className="space-y-4">
                <div className="relative h-64 bg-muted rounded-lg overflow-hidden">
                  <Cropper
                    image={imageToCrop}
                    crop={crop}
                    zoom={zoom}
                    aspect={1}
                    cropShape="round"
                    showGrid={false}
                    onCropChange={setCrop}
                    onZoomChange={setZoom}
                    onCropComplete={onCropComplete}
                  />
                </div>
                
                {/* Zoom control */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <ZoomIn className="w-4 h-4" />
                      Zoom
                    </Label>
                    <span className="text-sm text-muted-foreground">{Math.round(zoom * 100)}%</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <ZoomOut className="w-4 h-4 text-muted-foreground" />
                    <Slider
                      value={[zoom]}
                      min={1}
                      max={3}
                      step={0.1}
                      onValueChange={(value) => setZoom(value[0])}
                      className="flex-1"
                      data-testid="slider-zoom"
                    />
                    <ZoomIn className="w-4 h-4 text-muted-foreground" />
                  </div>
                </div>
                
                {/* Crop actions */}
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    onClick={handleCropCancel}
                    className="flex-1"
                    data-testid="button-cancel-crop"
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleCropConfirm}
                    disabled={isUploading}
                    className="flex-1"
                    data-testid="button-confirm-crop"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {progress}%
                      </>
                    ) : (
                      <>
                        <Crop className="w-4 h-4 mr-2" />
                        Apply Crop
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ) : (
              <>
                {/* Current avatar preview */}
                <div className="flex justify-center">
                  {avatarType === "default" && selectedAvatar ? (
                    <div className="w-24 h-24">
                      {(() => {
                        const cartoon = CARTOON_AVATARS.find(a => a.id === selectedAvatar);
                        if (cartoon) {
                          const animalPaths: Record<string, JSX.Element> = {
                            cat: <g fill="white"><circle cx="50" cy="55" r="30" /><polygon points="25,30 35,55 15,55" /><polygon points="75,30 65,55 85,55" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="4" ry="3" fill="#333" /><path d="M46,68 Q50,72 54,68" stroke="#333" strokeWidth="2" fill="none" /></g>,
                            owl: <g fill="white"><ellipse cx="50" cy="58" rx="28" ry="25" /><circle cx="38" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="62" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="38" cy="52" r="5" fill="#333" /><circle cx="62" cy="52" r="5" fill="#333" /><polygon points="50,60 46,70 54,70" fill="#F59E0B" /><polygon points="25,35 30,50 20,50" /><polygon points="75,35 70,50 80,50" /></g>,
                            lion: <g><circle cx="50" cy="55" r="35" fill="#F59E0B" /><circle cx="50" cy="58" r="22" fill="white" /><circle cx="42" cy="52" r="4" fill="#333" /><circle cx="58" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="62" rx="5" ry="4" fill="#333" /><path d="M45,70 Q50,75 55,70" stroke="#333" strokeWidth="2" fill="none" /></g>,
                            fox: <g fill="white"><ellipse cx="50" cy="58" rx="25" ry="22" /><polygon points="20,25 35,55 20,55" fill="#EA580C" /><polygon points="80,25 65,55 80,55" fill="#EA580C" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="64" rx="4" ry="3" fill="#333" /></g>,
                            bear: <g fill="white"><circle cx="50" cy="55" r="28" /><circle cx="28" cy="35" r="10" /><circle cx="72" cy="35" r="10" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="8" ry="6" fill="#333" /></g>,
                            eagle: <g fill="white"><ellipse cx="50" cy="55" rx="25" ry="28" /><circle cx="40" cy="48" r="4" fill="#333" /><circle cx="60" cy="48" r="4" fill="#333" /><polygon points="50,55 42,68 58,68" fill="#F59E0B" /><path d="M25,40 Q20,30 30,35" stroke="white" strokeWidth="4" fill="none" /><path d="M75,40 Q80,30 70,35" stroke="white" strokeWidth="4" fill="none" /></g>,
                            rabbit: <g fill="white"><ellipse cx="50" cy="60" rx="22" ry="20" /><ellipse cx="38" cy="25" rx="8" ry="25" /><ellipse cx="62" cy="25" rx="8" ry="25" /><ellipse cx="38" cy="25" rx="4" ry="18" fill="#FFB6C1" /><ellipse cx="62" cy="25" rx="4" ry="18" fill="#FFB6C1" /><circle cx="42" cy="55" r="4" fill="#333" /><circle cx="58" cy="55" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="3" ry="2" fill="#FFB6C1" /></g>,
                            wolf: <g fill="white"><ellipse cx="50" cy="58" rx="24" ry="22" /><polygon points="28,25 38,50 22,50" /><polygon points="72,25 62,50 78,50" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="6" ry="4" fill="#333" /></g>,
                          };
                          return (
                            <svg width="96" height="96" viewBox="0 0 100 100" className="rounded-full shadow-lg border-4 border-primary">
                              <circle cx="50" cy="50" r="50" fill={cartoon.bgColor} />
                              {animalPaths[cartoon.emoji]}
                            </svg>
                          );
                        }
                        return null;
                      })()}
                    </div>
                  ) : avatarType === "custom" && customAvatarUrl ? (
                    <Avatar className="w-24 h-24 border-4 border-primary">
                      <AvatarImage src={customAvatarUrl} />
                      <AvatarFallback className="text-2xl">{profile.firstName?.[0] || "?"}</AvatarFallback>
                    </Avatar>
                  ) : (
                    <UserAvatar user={profile} size="lg" className="h-24 w-24 border-4 border-primary" />
                  )}
                </div>
                
                {/* Upload photo option */}
                <div className="space-y-3">
                  <Label>Upload Photo</Label>
                  <div className="flex items-center gap-3">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="flex-1"
                      disabled={isUploading}
                      data-testid="dialog-input-avatar-upload"
                    />
                    {isUploading && (
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">{progress}%</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Cartoon avatar selection */}
                <div className="space-y-3">
                  <Label>Or choose a cartoon avatar</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {CARTOON_AVATARS.map((avatar) => {
                      const isSelected = selectedAvatar === avatar.id && avatarType === "default";
                      const animalPaths: Record<string, JSX.Element> = {
                        cat: <g fill="white"><circle cx="50" cy="55" r="30" /><polygon points="25,30 35,55 15,55" /><polygon points="75,30 65,55 85,55" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="4" ry="3" fill="#333" /><path d="M46,68 Q50,72 54,68" stroke="#333" strokeWidth="2" fill="none" /></g>,
                        owl: <g fill="white"><ellipse cx="50" cy="58" rx="28" ry="25" /><circle cx="38" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="62" cy="52" r="12" fill="#FFF8DC" stroke="white" strokeWidth="2" /><circle cx="38" cy="52" r="5" fill="#333" /><circle cx="62" cy="52" r="5" fill="#333" /><polygon points="50,60 46,70 54,70" fill="#F59E0B" /><polygon points="25,35 30,50 20,50" /><polygon points="75,35 70,50 80,50" /></g>,
                        lion: <g><circle cx="50" cy="55" r="35" fill="#F59E0B" /><circle cx="50" cy="58" r="22" fill="white" /><circle cx="42" cy="52" r="4" fill="#333" /><circle cx="58" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="62" rx="5" ry="4" fill="#333" /><path d="M45,70 Q50,75 55,70" stroke="#333" strokeWidth="2" fill="none" /></g>,
                        fox: <g fill="white"><ellipse cx="50" cy="58" rx="25" ry="22" /><polygon points="20,25 35,55 20,55" fill="#EA580C" /><polygon points="80,25 65,55 80,55" fill="#EA580C" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="64" rx="4" ry="3" fill="#333" /></g>,
                        bear: <g fill="white"><circle cx="50" cy="55" r="28" /><circle cx="28" cy="35" r="10" /><circle cx="72" cy="35" r="10" /><circle cx="40" cy="50" r="5" fill="#333" /><circle cx="60" cy="50" r="5" fill="#333" /><ellipse cx="50" cy="62" rx="8" ry="6" fill="#333" /></g>,
                        eagle: <g fill="white"><ellipse cx="50" cy="55" rx="25" ry="28" /><circle cx="40" cy="48" r="4" fill="#333" /><circle cx="60" cy="48" r="4" fill="#333" /><polygon points="50,55 42,68 58,68" fill="#F59E0B" /><path d="M25,40 Q20,30 30,35" stroke="white" strokeWidth="4" fill="none" /><path d="M75,40 Q80,30 70,35" stroke="white" strokeWidth="4" fill="none" /></g>,
                        rabbit: <g fill="white"><ellipse cx="50" cy="60" rx="22" ry="20" /><ellipse cx="38" cy="25" rx="8" ry="25" /><ellipse cx="62" cy="25" rx="8" ry="25" /><ellipse cx="38" cy="25" rx="4" ry="18" fill="#FFB6C1" /><ellipse cx="62" cy="25" rx="4" ry="18" fill="#FFB6C1" /><circle cx="42" cy="55" r="4" fill="#333" /><circle cx="58" cy="55" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="3" ry="2" fill="#FFB6C1" /></g>,
                        wolf: <g fill="white"><ellipse cx="50" cy="58" rx="24" ry="22" /><polygon points="28,25 38,50 22,50" /><polygon points="72,25 62,50 78,50" /><circle cx="40" cy="52" r="4" fill="#333" /><circle cx="60" cy="52" r="4" fill="#333" /><ellipse cx="50" cy="65" rx="6" ry="4" fill="#333" /></g>,
                      };
                      return (
                        <button
                          key={avatar.id}
                          type="button"
                          onClick={() => {
                            setSelectedAvatar(avatar.id);
                            setAvatarType("default");
                            setCustomAvatarUrl("");
                          }}
                          className={`relative flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                            isSelected ? "ring-2 ring-primary bg-primary/10" : "hover:bg-muted"
                          }`}
                          data-testid={`dialog-avatar-${avatar.id}`}
                        >
                          <svg width="48" height="48" viewBox="0 0 100 100" className="rounded-full shadow">
                            <circle cx="50" cy="50" r="50" fill={avatar.bgColor} />
                            {animalPaths[avatar.emoji]}
                          </svg>
                          {isSelected && (
                            <div className="absolute -top-1 -right-1 bg-primary text-primary-foreground rounded-full p-0.5">
                              <Check className="w-3 h-3" />
                            </div>
                          )}
                          <span className="text-[10px] font-medium">{avatar.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
                
                {/* Save button */}
                <Button 
                  onClick={() => updateAvatar.mutate()}
                  disabled={updateAvatar.isPending || isUploading}
                  className="w-full"
                  data-testid="dialog-button-save-avatar"
                >
                  {updateAvatar.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save Avatar"
                  )}
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
