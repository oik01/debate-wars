import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Loader2, Globe, Clock, Users, Trophy, ArrowRight, Check, X, Swords, Zap, Target, Brain, Award, Search, BarChart, Flame, Crown, Star, Shield, Medal, Link2, Copy, UserPlus, Mail } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useSound } from "@/hooks/use-sound";
import { useToast } from "@/hooks/use-toast";
import { UserAvatar } from "@/components/user-avatar";
import { CountryFlag } from "@/components/country-flag";
import { EloBadge, TierIcon } from "@/components/elo-badge";
import { Confetti } from "@/components/confetti";
import type { WorldChallengeWithRelations, User } from "@shared/schema";

type ChallengeStatus = "idle" | "selecting" | "matching" | "matchFound" | "waiting" | "researching" | "ready" | "debating" | "results";

function PlayerCard({ 
  user: playerUser, 
  isReady, 
  isCurrentUser,
  isAI = false,
  isLoading = false 
}: { 
  user: User | null | undefined; 
  isReady: boolean; 
  isCurrentUser: boolean;
  isAI?: boolean;
  isLoading?: boolean;
}) {
  const elo = parseInt(playerUser?.eloRating || "1000");
  const wins = parseInt(playerUser?.wins || "0");
  const playerId = isCurrentUser ? "you" : "opponent";
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center"
      data-testid={`player-card-${playerId}`}
    >
      <div className="relative inline-block" data-testid={`avatar-${playerId}`}>
        {isLoading ? (
          <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto border-4 border-muted">
            <Loader2 className="w-10 h-10 animate-spin text-muted-foreground" />
          </div>
        ) : isAI ? (
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center mx-auto border-4 border-primary/30">
            <Brain className="w-10 h-10 text-primary" />
          </div>
        ) : (
          <div className="relative">
            <UserAvatar user={playerUser as any} size="xl" className="border-4 border-primary/20" />
            {playerUser?.nationality && (
              <div className="absolute -bottom-1 -right-1 rounded-full bg-background p-0.5 shadow-md" data-testid={`flag-${playerId}`}>
                <CountryFlag code={playerUser.nationality} size="sm" />
              </div>
            )}
          </div>
        )}
        
        {isReady && (
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 bg-green-500 dark:bg-green-600 rounded-full p-1 shadow-lg"
            data-testid={`ready-check-${playerId}`}
          >
            <Check className="w-4 h-4 text-white" />
          </motion.div>
        )}
      </div>
      
      <div className="mt-3 space-y-1">
        <div className="font-bold text-lg" data-testid={`name-${playerId}`}>
          {isLoading ? "Waiting..." : isAI ? "AI Opponent" : isCurrentUser ? "You" : 
            playerUser?.firstName || playerUser?.email?.split("@")[0] || "Opponent"}
        </div>
        
        {!isLoading && !isAI && playerUser && (
          <div className="flex flex-col items-center gap-1">
            <EloBadge elo={elo} size="sm" />
            <div className="text-xs text-muted-foreground" data-testid={`wins-${playerId}`}>{wins} wins</div>
          </div>
        )}
        
        {isAI && (
          <Badge variant="outline" className="bg-primary/10 border-primary/30 text-primary" data-testid="badge-ai">
            <Zap className="w-3 h-3 mr-1" /> AI Powered
          </Badge>
        )}
        
        {isReady ? (
          <Badge variant="default" className="mt-2 bg-green-500 dark:bg-green-600" data-testid={`badge-ready-${playerId}`}>
            <Check className="w-3 h-3 mr-1" /> Ready
          </Badge>
        ) : (
          <motion.div
            animate={{ opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <Badge variant="secondary" className="mt-2" data-testid={`badge-researching-${playerId}`}>
              <Search className="w-3 h-3 mr-1 animate-pulse" />
              {isCurrentUser ? "Researching..." : "Opponent Researching..."}
            </Badge>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}

function RoundTimeline({ currentRound, rounds }: { currentRound: number; rounds: any[] }) {
  return (
    <div className="flex items-center justify-center gap-2 mb-6" data-testid="round-timeline">
      {[1, 2, 3].map((roundNum) => {
        const round = rounds?.find(r => r.roundNumber === roundNum);
        const isComplete = round?.status === "judged";
        const isCurrent = roundNum === currentRound;
        
        return (
          <div key={roundNum} className="flex items-center gap-2">
            <motion.div 
              initial={false}
              animate={{ 
                scale: isCurrent ? 1.1 : 1,
                opacity: isComplete || isCurrent ? 1 : 0.5 
              }}
              className={`
                w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm
                ${isComplete ? "bg-green-500 dark:bg-green-600 text-white" : 
                  isCurrent ? "bg-primary text-primary-foreground ring-4 ring-primary/30" : 
                  "bg-muted text-muted-foreground"}
              `}
              data-testid={`round-node-${roundNum}`}
            >
              {isComplete ? <Check className="w-5 h-5" /> : roundNum}
            </motion.div>
            {roundNum < 3 && (
              <div className={`w-8 h-1 rounded ${roundNum < currentRound ? "bg-green-500 dark:bg-green-600" : "bg-muted"}`} data-testid={`round-connector-${roundNum}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function WorldChallenge() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { playSound, preloadSound } = useSound();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [status, setStatus] = useState<ChallengeStatus>("idle");
  const [timeRemaining, setTimeRemaining] = useState<number>(0);

  useEffect(() => {
    preloadSound("matchFound");
    preloadSound("ready");
    preloadSound("victory");
    preloadSound("defeat");
  }, [preloadSound]);

  const { data: categories = [] } = useQuery<string[]>({
    queryKey: ["/api/categories"],
  });

  const { data: activeChallenge, refetch: refetchChallenge } = useQuery<WorldChallengeWithRelations | null>({
    queryKey: ["/api/world-challenge/active"],
    refetchInterval: status === "matching" || status === "waiting" || status === "researching" || status === "ready" ? 3000 : false,
  });

  const { data: challengeStats } = useQuery<{
    totalChallenges: number;
    wins: number;
    losses: number;
    winRate: number;
    bestCategory: string | null;
    currentStreak: number;
    badges: {
      categoryMaster: string | null;
      perfectWins: number;
      underdogWins: number;
    };
  }>({
    queryKey: ["/api/world-challenge/stats"],
    enabled: status === "idle" || status === "selecting",
  });

  const { data: challengeHistory = [] } = useQuery<WorldChallengeWithRelations[]>({
    queryKey: ["/api/world-challenge/history"],
    enabled: status === "idle" || status === "selecting",
  });

  const { data: pendingChallenges = [] } = useQuery<WorldChallengeWithRelations[]>({
    queryKey: ["/api/world-challenge/pending"],
    enabled: status === "idle" || status === "selecting",
  });

  const { toast } = useToast();
  const [inviteCode, setInviteCode] = useState<string>("");

  const joinQueueMutation = useMutation({
    mutationFn: async (category: string) => {
      const res = await apiRequest("POST", "/api/world-challenge/join", { category });
      return res.json();
    },
    onSuccess: (data: { matched: boolean; challenge?: WorldChallengeWithRelations }) => {
      if (data.matched && data.challenge) {
        setStatus("researching");
        queryClient.invalidateQueries({ queryKey: ["/api/world-challenge/active"] });
      } else {
        setStatus("matching");
      }
    },
  });

  const leaveQueueMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/world-challenge/leave");
      return res.json();
    },
    onSuccess: () => {
      setStatus("selecting");
      setSelectedCategory(null);
    },
  });

  const markReadyMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      const res = await apiRequest("POST", `/api/world-challenge/${challengeId}/ready`);
      return res.json();
    },
    onSuccess: (data: { challenge: WorldChallengeWithRelations; debateStarted: boolean; debateId?: number }) => {
      if (data.debateStarted && data.debateId) {
        setLocation(`/debate/${data.debateId}`);
      } else {
        setStatus("ready");
        queryClient.invalidateQueries({ queryKey: ["/api/world-challenge/active"] });
      }
    },
  });

  const checkTimeoutMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      const res = await apiRequest("POST", `/api/world-challenge/${challengeId}/check-timeout`);
      return res.json();
    },
    onSuccess: (data: { aiTakeover: boolean; challenge: WorldChallengeWithRelations; debateId?: number }) => {
      if (data.aiTakeover && data.debateId) {
        setLocation(`/debate/${data.debateId}`);
      }
    },
  });

  const createPrivateChallengeMutation = useMutation({
    mutationFn: async (category: string) => {
      const res = await apiRequest("POST", "/api/world-challenge/create-private", { category });
      return res.json();
    },
    onSuccess: (data: WorldChallengeWithRelations) => {
      setStatus("waiting");
      queryClient.invalidateQueries({ queryKey: ["/api/world-challenge/active"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create challenge",
        variant: "destructive",
      });
    },
  });

  const joinByInviteCodeMutation = useMutation({
    mutationFn: async (code: string) => {
      const res = await apiRequest("POST", "/api/world-challenge/join-invite", { code });
      return res.json();
    },
    onSuccess: (data: { matched: boolean; challenge?: WorldChallengeWithRelations }) => {
      if (data.matched && data.challenge) {
        setStatus("researching");
        queryClient.invalidateQueries({ queryKey: ["/api/world-challenge/active"] });
        toast({
          title: "Joined Challenge!",
          description: "Research period has started. Get ready to debate!",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to join challenge",
        variant: "destructive",
      });
    },
  });

  const cancelChallengeMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      const res = await apiRequest("POST", `/api/world-challenge/${challengeId}/cancel`);
      return res.json();
    },
    onSuccess: () => {
      setStatus("selecting");
      setSelectedCategory(null);
      queryClient.invalidateQueries({ queryKey: ["/api/world-challenge/active"] });
      toast({
        title: "Challenge Cancelled",
        description: "Your challenge has been cancelled.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to cancel challenge",
        variant: "destructive",
      });
    },
  });

  const handleCopyInviteLink = (code: string) => {
    const link = `${window.location.origin}/world-challenge?invite=${code}`;
    navigator.clipboard.writeText(link);
    toast({
      title: "Link Copied!",
      description: "Share this link with your friend to challenge them.",
    });
  };

  const handleJoinByCode = () => {
    if (inviteCode.trim()) {
      joinByInviteCodeMutation.mutate(inviteCode.trim().toUpperCase());
    }
  };

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const urlInviteCode = urlParams.get("invite");
    if (urlInviteCode && !activeChallenge) {
      setInviteCode(urlInviteCode.toUpperCase());
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, [activeChallenge]);

  useEffect(() => {
    if (activeChallenge) {
      if (activeChallenge.status === "waiting") {
        setStatus("waiting");
        setSelectedCategory(activeChallenge.category);
      } else if (activeChallenge.status === "researching") {
        const isPlayer1 = activeChallenge.player1Id === user?.id;
        const isReady = isPlayer1 ? activeChallenge.player1Ready : activeChallenge.player2Ready;
        
        // Show "Match Found!" animation if coming from matching or waiting
        if (status === "matching" || status === "waiting") {
          setStatus("matchFound");
          playSound("matchFound", 0.6);
        } else if (status !== "matchFound") {
          setStatus(isReady ? "ready" : "researching");
        }
      } else if (activeChallenge.status === "debating") {
        const currentRound = activeChallenge.rounds?.find(r => r.roundNumber === activeChallenge.currentRound);
        if (currentRound?.debateId) {
          setLocation(`/debate/${currentRound.debateId}`);
        }
      } else if (activeChallenge.status === "completed") {
        if (status !== "results") {
          setStatus("results");
          // Play victory or defeat sound
          const isWinner = activeChallenge.winnerId === user?.id;
          playSound(isWinner ? "victory" : "defeat", 0.5);
        }
      }
    }
  }, [activeChallenge, user?.id, setLocation, status, playSound]);

  // Handle matchFound to researching transition with proper cleanup
  useEffect(() => {
    if (status === "matchFound" && activeChallenge) {
      const isPlayer1 = activeChallenge.player1Id === user?.id;
      const isReady = isPlayer1 ? activeChallenge.player1Ready : activeChallenge.player2Ready;
      
      const timer = setTimeout(() => {
        setStatus(isReady ? "ready" : "researching");
      }, 2500);
      
      return () => clearTimeout(timer);
    }
  }, [status, activeChallenge, user?.id]);

  useEffect(() => {
    if (activeChallenge?.researchDeadline && (status === "researching" || status === "ready")) {
      const deadline = new Date(activeChallenge.researchDeadline).getTime();
      
      const updateTimer = () => {
        const now = Date.now();
        const remaining = Math.max(0, Math.floor((deadline - now) / 1000));
        setTimeRemaining(remaining);
        
        if (remaining === 0 && activeChallenge.id) {
          checkTimeoutMutation.mutate(activeChallenge.id);
        }
      };
      
      updateTimer();
      const interval = setInterval(updateTimer, 1000);
      return () => clearInterval(interval);
    }
  }, [activeChallenge?.researchDeadline, status, activeChallenge?.id]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const handleSelectCategory = (category: string) => {
    setSelectedCategory(category);
  };

  const handleJoinQueue = () => {
    if (selectedCategory) {
      joinQueueMutation.mutate(selectedCategory);
    }
  };

  const handleLeaveQueue = () => {
    leaveQueueMutation.mutate();
  };

  const handleReady = () => {
    if (activeChallenge?.id) {
      playSound("ready", 0.5);
      markReadyMutation.mutate(activeChallenge.id);
    }
  };

  const getCurrentRound = () => {
    if (!activeChallenge?.rounds) return null;
    return activeChallenge.rounds.find(r => r.roundNumber === activeChallenge.currentRound);
  };

  const getOpponent = (): User | null | undefined => {
    if (!activeChallenge) return null;
    const isPlayer1 = activeChallenge.player1Id === user?.id;
    return isPlayer1 ? activeChallenge.player2 : activeChallenge.player1;
  };

  const isOpponentReady = (): boolean => {
    if (!activeChallenge) return false;
    const isPlayer1 = activeChallenge.player1Id === user?.id;
    return isPlayer1 ? !!activeChallenge.player2Ready : !!activeChallenge.player1Ready;
  };

  const isUserReady = (): boolean => {
    if (!activeChallenge) return false;
    const isPlayer1 = activeChallenge.player1Id === user?.id;
    return isPlayer1 ? !!activeChallenge.player1Ready : !!activeChallenge.player2Ready;
  };

  if (status === "idle" || status === "selecting") {
    return (
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Globe className="w-10 h-10 text-primary" />
            <h1 className="text-3xl font-bold">Discover the World Challenge</h1>
          </div>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Choose a category and compete against debaters worldwide. Research your topic for 30 minutes, 
            then debate 3 rounds to become the champion!
          </p>
        </div>

        {challengeStats && challengeStats.totalChallenges > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <BarChart className="w-5 h-5 text-primary" />
                  Your Challenge Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4" data-testid="stats-grid">
                  <div className="text-center p-3 bg-muted/50 rounded-lg" data-testid="stat-challenges">
                    <div className="text-2xl font-bold">{challengeStats.totalChallenges}</div>
                    <div className="text-xs text-muted-foreground">Challenges</div>
                  </div>
                  <div className="text-center p-3 bg-primary/10 rounded-lg" data-testid="stat-wins">
                    <div className="text-2xl font-bold text-primary">{challengeStats.wins}</div>
                    <div className="text-xs text-muted-foreground">Wins</div>
                  </div>
                  <div className="text-center p-3 bg-destructive/10 rounded-lg" data-testid="stat-losses">
                    <div className="text-2xl font-bold text-destructive">{challengeStats.losses}</div>
                    <div className="text-xs text-muted-foreground">Losses</div>
                  </div>
                  <div className="text-center p-3 bg-accent/50 rounded-lg" data-testid="stat-winrate">
                    <div className="text-2xl font-bold">{challengeStats.winRate}%</div>
                    <div className="text-xs text-muted-foreground">Win Rate</div>
                  </div>
                  {challengeStats.currentStreak > 0 && (
                    <div className="text-center p-3 bg-secondary rounded-lg" data-testid="stat-streak">
                      <div className="text-2xl font-bold text-primary">{challengeStats.currentStreak}</div>
                      <div className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                        <Flame className="w-3 h-3" /> Streak
                      </div>
                    </div>
                  )}
                </div>
                {challengeStats.bestCategory && (
                  <div className="mt-4 flex items-center justify-center gap-2 text-sm" data-testid="stat-best-category">
                    <Crown className="w-4 h-4 text-primary" />
                    <span className="text-muted-foreground">Best Category:</span>
                    <Badge variant="secondary">{challengeStats.bestCategory}</Badge>
                  </div>
                )}

                {(challengeStats.badges?.categoryMaster || challengeStats.badges?.perfectWins > 0 || challengeStats.badges?.underdogWins > 0) && (
                  <div className="mt-4 pt-4 border-t border-border" data-testid="gamification-badges">
                    <div className="text-xs text-muted-foreground text-center mb-2">Achievements</div>
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      {challengeStats.badges?.categoryMaster && (
                        <Badge variant="outline" className="border-primary/50 text-primary" data-testid="badge-category-master">
                          <Star className="w-3 h-3 mr-1 flex-shrink-0" />
                          <span className="truncate">Master: {challengeStats.badges.categoryMaster}</span>
                        </Badge>
                      )}
                      {challengeStats.badges?.perfectWins > 0 && (
                        <Badge variant="outline" className="border-primary/50 text-primary" data-testid="badge-perfect-wins">
                          <Medal className="w-3 h-3 mr-1 flex-shrink-0" />
                          Perfect: {challengeStats.badges.perfectWins}
                        </Badge>
                      )}
                      {challengeStats.badges?.underdogWins > 0 && (
                        <Badge variant="outline" className="border-primary/50 text-primary" data-testid="badge-underdog">
                          <Shield className="w-3 h-3 mr-1 flex-shrink-0" />
                          Underdog: {challengeStats.badges.underdogWins}
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {challengeHistory.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Clock className="w-5 h-5 text-primary" />
                  Recent Challenges
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-3 overflow-x-auto pb-2">
                  {challengeHistory.map((challenge) => {
                    const isWinner = challenge.winnerId === user?.id;
                    const opponent = challenge.player1Id === user?.id ? challenge.player2 : challenge.player1;
                    return (
                      <div
                        key={challenge.id}
                        className={`flex-shrink-0 p-3 rounded-lg border ${isWinner ? "border-primary/50 bg-primary/5" : "border-destructive/50 bg-destructive/5"}`}
                        style={{ minWidth: "140px" }}
                        data-testid={`history-card-${challenge.id}`}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          {isWinner ? (
                            <Trophy className="w-4 h-4 text-primary" />
                          ) : (
                            <X className="w-4 h-4 text-destructive" />
                          )}
                          <span className={`text-sm font-medium ${isWinner ? "text-primary" : "text-destructive"}`}>
                            {isWinner ? "Win" : "Loss"}
                          </span>
                        </div>
                        <div className="text-xs text-muted-foreground mb-1 truncate">{challenge.category}</div>
                        <div className="text-xs flex items-center gap-1">
                          vs{" "}
                          {opponent?.firstName || opponent?.email?.split("@")[0] || "Opponent"}
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {challenge.player1Id === user?.id
                            ? `${challenge.player1Score} - ${challenge.player2Score}`
                            : `${challenge.player2Score} - ${challenge.player1Score}`}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5" />
              How It Works
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-primary mb-2">1</div>
                <div className="font-medium">Pick Category</div>
                <p className="text-sm text-muted-foreground">Choose your battleground</p>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-primary mb-2">2</div>
                <div className="font-medium">Get Matched</div>
                <p className="text-sm text-muted-foreground">Find a worthy opponent</p>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-primary mb-2">3</div>
                <div className="font-medium">Research (30 min)</div>
                <p className="text-sm text-muted-foreground">Prepare your arguments</p>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-primary mb-2">4</div>
                <div className="font-medium">Debate 3 Rounds</div>
                <p className="text-sm text-muted-foreground">Claim victory!</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Select Your Category</CardTitle>
            <CardDescription>Pick a topic area you want to debate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  className="h-auto py-3 px-4 text-left justify-start"
                  onClick={() => handleSelectCategory(category)}
                  data-testid={`category-${category.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  {category}
                </Button>
              ))}
            </div>

            {selectedCategory && (
              <div className="mt-6 flex flex-col items-center gap-4">
                <div className="text-center">
                  <Badge variant="secondary" className="text-lg px-4 py-2">
                    {selectedCategory}
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <Button
                    size="lg"
                    onClick={handleJoinQueue}
                    disabled={joinQueueMutation.isPending}
                    data-testid="button-find-match"
                  >
                    {joinQueueMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Finding Match...
                      </>
                    ) : (
                      <>
                        <Users className="w-4 h-4 mr-2" />
                        Find Random Match
                      </>
                    )}
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => createPrivateChallengeMutation.mutate(selectedCategory)}
                    disabled={createPrivateChallengeMutation.isPending}
                    data-testid="button-invite-friend"
                  >
                    {createPrivateChallengeMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4 mr-2" />
                        Invite a Friend
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Link2 className="w-5 h-5" />
              Join by Invite Code
            </CardTitle>
            <CardDescription>Enter an invite code from a friend to join their challenge</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <Input
                placeholder="Enter invite code (e.g. ABC123XY)"
                value={inviteCode}
                onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                className="flex-1 min-w-[200px] uppercase font-mono"
                maxLength={8}
                data-testid="input-invite-code"
              />
              <Button
                onClick={handleJoinByCode}
                disabled={!inviteCode.trim() || joinByInviteCodeMutation.isPending}
                data-testid="button-join-by-code"
              >
                {joinByInviteCodeMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <ArrowRight className="w-4 h-4 mr-2" />
                    Join Challenge
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {pendingChallenges.length > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Open Challenges
              </CardTitle>
              <CardDescription>Join a challenge waiting for an opponent</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pendingChallenges.map((challenge) => (
                  <div
                    key={challenge.id}
                    className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border border-border"
                    data-testid={`pending-challenge-${challenge.id}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <UserAvatar user={challenge.player1 as any} size="md" />
                        {challenge.player1?.nationality && (
                          <div className="absolute -bottom-1 -right-1">
                            <CountryFlag code={challenge.player1.nationality} size="sm" />
                          </div>
                        )}
                      </div>
                      <div>
                        <div className="font-medium">
                          {challenge.player1?.firstName || challenge.player1?.email?.split("@")[0] || "Player"}
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs">{challenge.category}</Badge>
                          {challenge.player1?.eloRating && (
                            <EloBadge elo={parseInt(challenge.player1.eloRating)} size="sm" />
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => challenge.inviteCode && joinByInviteCodeMutation.mutate(challenge.inviteCode)}
                      disabled={joinByInviteCodeMutation.isPending}
                      data-testid={`button-join-challenge-${challenge.id}`}
                    >
                      <Swords className="w-4 h-4 mr-2" />
                      Accept
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  if (status === "waiting" && activeChallenge) {
    return (
      <div className="container max-w-2xl mx-auto py-16 px-4">
        <Card className="text-center overflow-hidden">
          <div className="bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 py-8">
            <motion.div 
              className="relative mx-auto w-32 h-32"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <UserPlus className="w-32 h-32 text-primary" />
            </motion.div>
          </div>
          
          <CardContent className="py-8">
            <h2 className="text-2xl font-bold mb-2">Waiting for Your Friend</h2>
            <p className="text-muted-foreground mb-6">
              Share this link or code with a friend to challenge them in{" "}
              <Badge variant="secondary" className="text-sm">{activeChallenge.category}</Badge>
            </p>
            
            {activeChallenge.inviteCode && (
              <div className="space-y-4 mb-6">
                <div className="flex items-center justify-center gap-2">
                  <div className="px-4 py-2 bg-muted rounded-lg font-mono text-2xl tracking-wider" data-testid="text-invite-code">
                    {activeChallenge.inviteCode}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      navigator.clipboard.writeText(activeChallenge.inviteCode!);
                      toast({ title: "Code Copied!", description: "Share this code with your friend." });
                    }}
                    data-testid="button-copy-code"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                
                <Button
                  variant="outline"
                  onClick={() => handleCopyInviteLink(activeChallenge.inviteCode!)}
                  className="w-full max-w-md"
                  data-testid="button-copy-link"
                >
                  <Link2 className="w-4 h-4 mr-2" />
                  Copy Invite Link
                </Button>
              </div>
            )}
            
            <div className="flex items-center justify-center gap-2 mb-6 text-sm text-muted-foreground">
              <motion.div
                animate={{ opacity: [1, 0.5, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <Clock className="w-4 h-4" />
              </motion.div>
              <span>Waiting for opponent to join...</span>
            </div>
            
            <Button 
              variant="destructive" 
              onClick={() => cancelChallengeMutation.mutate(activeChallenge.id)}
              disabled={cancelChallengeMutation.isPending}
              data-testid="button-cancel-challenge"
            >
              {cancelChallengeMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <X className="w-4 h-4 mr-2" />
              )}
              Cancel Challenge
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (status === "matching") {
    return (
      <div className="container max-w-2xl mx-auto py-16 px-4">
        <Card className="text-center overflow-hidden">
          <div className="bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 py-8">
            <motion.div 
              className="relative mx-auto w-32 h-32"
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Globe className="w-32 h-32 text-primary" />
              <motion.div 
                className="absolute inset-0 rounded-full border-4 border-primary/30"
                animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <motion.div 
                className="absolute inset-0 rounded-full border-4 border-primary/20"
                animate={{ scale: [1, 2, 1], opacity: [0.3, 0, 0.3] }}
                transition={{ duration: 2.5, repeat: Infinity }}
              />
            </motion.div>
          </div>
          
          <CardContent className="py-8">
            <motion.h2 
              className="text-2xl font-bold mb-2"
              animate={{ opacity: [1, 0.5, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              Searching for Opponent...
            </motion.h2>
            <p className="text-muted-foreground mb-6">
              Looking for a worthy challenger in{" "}
              <Badge variant="secondary" className="text-sm">{selectedCategory}</Badge>
            </p>
            
            <div className="flex items-center justify-center gap-2 mb-6 text-sm text-muted-foreground">
              <Users className="w-4 h-4" />
              <span>Players worldwide are being matched...</span>
            </div>
            
            <Button variant="outline" size="lg" onClick={handleLeaveQueue} data-testid="button-leave-queue">
              <X className="w-4 h-4 mr-2" />
              Leave Queue
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (status === "matchFound" && activeChallenge) {
    const opponent = getOpponent();
    
    return (
      <div className="container max-w-2xl mx-auto py-16 px-4">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", duration: 0.5 }}
        >
          <Card className="text-center overflow-hidden">
            <div className="bg-gradient-to-r from-green-500/20 via-green-400/30 to-green-500/20 py-6">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: [0, 1.2, 1] }}
                transition={{ duration: 0.5 }}
              >
                <Award className="w-16 h-16 mx-auto text-green-500" />
              </motion.div>
              <motion.h2 
                className="text-3xl font-bold text-green-500 mt-4"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                MATCH FOUND!
              </motion.h2>
            </div>
            
            <CardContent className="py-8">
              <div className="flex items-center justify-center gap-8">
                <motion.div 
                  className="text-center"
                  initial={{ x: -100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.4, type: "spring" }}
                >
                  <div className="relative inline-block">
                    <UserAvatar user={user as any} size="xl" className="border-4 border-primary/20" />
                    {(user as any)?.nationality && (
                      <div className="absolute -bottom-1 -right-1 rounded-full bg-background p-0.5 shadow-md">
                        <CountryFlag code={(user as any).nationality} size="sm" />
                      </div>
                    )}
                  </div>
                  <div className="mt-3 font-bold">You</div>
                  <EloBadge elo={parseInt((user as any)?.eloRating || "1000")} size="sm" />
                </motion.div>

                <motion.div 
                  className="text-4xl font-black text-primary"
                  initial={{ scale: 0 }}
                  animate={{ scale: [0, 1.3, 1] }}
                  transition={{ delay: 0.6 }}
                >
                  VS
                </motion.div>

                <motion.div 
                  className="text-center"
                  initial={{ x: 100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.4, type: "spring" }}
                >
                  {opponent ? (
                    <div className="relative inline-block">
                      <UserAvatar user={opponent as any} size="xl" className="border-4 border-destructive/20" />
                      {opponent.nationality && (
                        <div className="absolute -bottom-1 -right-1 rounded-full bg-background p-0.5 shadow-md">
                          <CountryFlag code={opponent.nationality} size="sm" />
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto border-4 border-primary/20">
                      <Brain className="w-12 h-12 text-primary" />
                    </div>
                  )}
                  <div className="mt-3 font-bold">
                    {opponent?.firstName || opponent?.email?.split("@")[0] || "Opponent"}
                  </div>
                  {opponent && <EloBadge elo={parseInt(opponent.eloRating || "1000")} size="sm" />}
                </motion.div>
              </div>
              
              <motion.div 
                className="mt-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
              >
                <Badge variant="secondary" className="text-base px-4 py-2">
                  <Target className="w-4 h-4 mr-2" />
                  {activeChallenge.category}
                </Badge>
              </motion.div>
              
              <motion.p 
                className="mt-6 text-muted-foreground"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.2 }}
              >
                Get ready to research and debate!
              </motion.p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  if ((status === "researching" || status === "ready") && activeChallenge) {
    const currentRound = getCurrentRound();
    const opponent = getOpponent();
    const progressPercent = ((30 * 60 - timeRemaining) / (30 * 60)) * 100;
    const isPlayer1 = activeChallenge.player1Id === user?.id;

    return (
      <div className="container max-w-3xl mx-auto py-8 px-4">
        <RoundTimeline currentRound={activeChallenge.currentRound || 1} rounds={activeChallenge.rounds || []} />
        
        <Card className="mb-6 overflow-hidden">
          <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10 p-4 border-b">
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-2">
              <Clock className="w-4 h-4" />
              Research Phase - Round {activeChallenge.currentRound} of 3
            </div>
            <motion.div 
              className="text-center"
              animate={{ scale: timeRemaining < 60 ? [1, 1.05, 1] : 1 }}
              transition={{ repeat: timeRemaining < 60 ? Infinity : 0, duration: 1 }}
            >
              <span className={`text-3xl font-bold font-mono ${timeRemaining < 300 ? "text-destructive" : ""}`}>
                {timeRemaining > 0 ? formatTime(timeRemaining) : "Time's Up!"}
              </span>
            </motion.div>
            <Progress value={progressPercent} className="h-2 mt-4" />
          </div>
          
          <CardContent className="pt-8 pb-6">
            <div className="flex items-start justify-center gap-12">
              <PlayerCard 
                user={isPlayer1 ? user as User : activeChallenge.player1}
                isReady={isPlayer1 ? !!activeChallenge.player1Ready : !!activeChallenge.player2Ready}
                isCurrentUser={true}
              />

              <div className="flex flex-col items-center justify-center pt-8">
                <motion.div 
                  className="text-3xl font-black text-primary/80"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                >
                  VS
                </motion.div>
                <div className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
                  <Target className="w-4 h-4" />
                  <span>{activeChallenge.category}</span>
                </div>
              </div>

              <PlayerCard 
                user={opponent}
                isReady={isOpponentReady()}
                isCurrentUser={false}
                isAI={!!activeChallenge.player2IsAI}
                isLoading={!opponent && !activeChallenge.player2IsAI}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Your Debate Topic</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-lg font-medium">{currentRound?.topic}</p>
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              Research this topic thoroughly. When you're ready, click the button below to signal you're prepared to debate.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary">
                  {activeChallenge.player1Id === user?.id ? activeChallenge.player1Score : activeChallenge.player2Score}
                </div>
                <div className="text-sm text-muted-foreground">You</div>
              </div>
              <div className="text-2xl font-bold text-muted-foreground">-</div>
              <div className="text-center">
                <div className="text-4xl font-bold">
                  {activeChallenge.player1Id === user?.id ? activeChallenge.player2Score : activeChallenge.player1Score}
                </div>
                <div className="text-sm text-muted-foreground">Opponent</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 flex justify-center">
          {!isUserReady() ? (
            <motion.div
              animate={{ 
                boxShadow: ["0 0 0px rgba(var(--primary), 0)", "0 0 20px rgba(var(--primary), 0.5)", "0 0 0px rgba(var(--primary), 0)"]
              }}
              transition={{ duration: 2, repeat: Infinity }}
              className="rounded-lg"
            >
              <Button
                size="lg"
                onClick={handleReady}
                disabled={markReadyMutation.isPending}
                className="text-lg px-8 py-6 shadow-lg shadow-primary/30"
                data-testid="button-ready"
              >
                {markReadyMutation.isPending ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Marking Ready...
                  </>
                ) : (
                  <>
                    <Swords className="w-5 h-5 mr-2" />
                    I'm Ready to Debate!
                  </>
                )}
              </Button>
            </motion.div>
          ) : (
            <motion.div 
              className="text-center"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
            >
              <Badge variant="default" className="text-lg px-8 py-3 bg-green-500" data-testid="badge-you-ready">
                <Check className="w-5 h-5 mr-2" />
                You're Ready!
              </Badge>
              <motion.p 
                className="text-sm text-muted-foreground mt-3"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                Waiting for opponent to be ready...
              </motion.p>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  if (status === "results" && activeChallenge) {
    const isWinner = activeChallenge.winnerId === user?.id;
    const opponent = getOpponent();
    const userScore = activeChallenge.player1Id === user?.id
      ? activeChallenge.player1Score
      : activeChallenge.player2Score;
    const opponentScore = activeChallenge.player1Id === user?.id
      ? activeChallenge.player2Score
      : activeChallenge.player1Score;

    return (
      <div className="container max-w-2xl mx-auto py-16 px-4">
        {isWinner && <Confetti duration={5000} />}
        
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", duration: 0.5 }}
        >
          <Card className="text-center overflow-hidden">
            <div className={`py-6 ${isWinner ? "bg-gradient-to-r from-yellow-500/20 via-yellow-400/30 to-yellow-500/20" : "bg-muted/50"}`}>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1, rotate: isWinner ? [0, -10, 10, 0] : 0 }}
                transition={{ delay: 0.2, type: "spring" }}
              >
                <Trophy className={`w-24 h-24 mx-auto ${isWinner ? "text-yellow-500 drop-shadow-lg" : "text-muted-foreground"}`} />
              </motion.div>
            </div>
            
            <CardContent className="py-8">
              <motion.h2 
                className="text-4xl font-bold mb-2"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                {isWinner ? "Victory!" : activeChallenge.winnerId ? "Defeat" : "Draw!"}
              </motion.h2>
              <p className="text-muted-foreground mb-8">
                {isWinner
                  ? "Congratulations! You've won the World Challenge!"
                  : activeChallenge.winnerId
                    ? "Better luck next time. Keep debating to improve!"
                    : "The match ended in a draw."}
              </p>

              <div className="flex items-center justify-center gap-12 mb-8">
                <motion.div 
                  className="text-center"
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  <div className="relative inline-block">
                    <UserAvatar user={user as any} size="xl" className="border-4 border-primary/20" />
                    {(user as any)?.nationality && (
                      <div className="absolute -bottom-1 -right-1 rounded-full bg-background p-0.5 shadow-md">
                        <CountryFlag code={(user as any).nationality} size="sm" />
                      </div>
                    )}
                  </div>
                  <div className="mt-3 font-bold text-lg">You</div>
                  <motion.div 
                    className="text-5xl font-bold text-primary mt-2"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.6, type: "spring" }}
                  >
                    {userScore}
                  </motion.div>
                </motion.div>

                <motion.div 
                  className="text-3xl font-black text-muted-foreground"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  -
                </motion.div>

                <motion.div 
                  className="text-center"
                  initial={{ x: 50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  {opponent ? (
                    <div className="relative inline-block">
                      <UserAvatar user={opponent as any} size="xl" className="border-4 border-muted" />
                      {opponent.nationality && (
                        <div className="absolute -bottom-1 -right-1 rounded-full bg-background p-0.5 shadow-md">
                          <CountryFlag code={opponent.nationality} size="sm" />
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto border-4 border-primary/20">
                      <Brain className="w-12 h-12 text-primary" />
                    </div>
                  )}
                  <div className="mt-3 font-bold text-lg">
                    {opponent
                      ? opponent.firstName || opponent.email?.split("@")[0]
                      : "AI Opponent"}
                  </div>
                  <motion.div 
                    className="text-5xl font-bold mt-2"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.6, type: "spring" }}
                  >
                    {opponentScore}
                  </motion.div>
                </motion.div>
              </div>

              <motion.div 
                className="flex justify-center gap-4"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                <Button size="lg" onClick={() => { setStatus("idle"); setSelectedCategory(null); }} data-testid="button-play-again">
                  <Trophy className="w-4 h-4 mr-2" />
                  Play Again
                </Button>
                <Button size="lg" variant="outline" onClick={() => setLocation("/")} data-testid="button-go-home">
                  Back to Home
                </Button>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="container max-w-2xl mx-auto py-16 px-4 text-center">
      <Loader2 className="w-12 h-12 mx-auto animate-spin text-muted-foreground" />
      <p className="mt-4 text-muted-foreground">Loading challenge...</p>
    </div>
  );
}
