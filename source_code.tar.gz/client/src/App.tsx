import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import CreateDebate from "@/pages/create-debate";
import DebateRoom from "@/pages/debate-room";
import Profile from "@/pages/profile";
import Leaderboard from "@/pages/leaderboard";
import Invite from "@/pages/invite";
import JoinDebate from "@/pages/join-debate";
import Onboarding from "@/pages/onboarding";
import WorldChallenge from "@/pages/world-challenge";
import PoliticalArena from "@/pages/political-arena";
import { useAuth } from "@/hooks/use-auth";
import { MusicProvider, useMusic } from "@/hooks/use-music";
import { IntroVideo } from "@/components/intro-video";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";

function ProtectedRoute({ component: Component, ...rest }: any) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) return null;

  if (!isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }

  return <Component {...rest} />;
}

function OnboardingRedirect() {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const [location] = useLocation();
  
  useEffect(() => {
    if (!isLoading && user && user.onboardingCompleted !== "true" && location !== "/onboarding") {
      navigate("/onboarding");
    }
  }, [user, isLoading, location, navigate]);
  
  return null;
}

function Router() {
  return (
    <>
      <OnboardingRedirect />
      <Layout>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/onboarding" component={Onboarding} />
          <Route path="/create">
            <ProtectedRoute component={CreateDebate} />
          </Route>
          <Route path="/debate/:id" component={DebateRoom} />
          <Route path="/profile">
            <ProtectedRoute component={Profile} />
          </Route>
          <Route path="/leaderboard" component={Leaderboard} />
          <Route path="/world-challenge">
            <ProtectedRoute component={WorldChallenge} />
          </Route>
          <Route path="/political-arena">
            <ProtectedRoute component={PoliticalArena} />
          </Route>
          <Route path="/invite/:code" component={Invite} />
          <Route path="/join/:code" component={JoinDebate} />
          <Route component={NotFound} />
        </Switch>
      </Layout>
    </>
  );
}

function AppContent() {
  const { startPlayback } = useMusic();
  const [showIntro, setShowIntro] = useState(() => {
    const hasSeenIntro = sessionStorage.getItem("hasSeenIntro");
    return !hasSeenIntro;
  });

  const handleIntroComplete = () => {
    sessionStorage.setItem("hasSeenIntro", "true");
    setShowIntro(false);
    startPlayback();
  };

  return (
    <>
      {showIntro && <IntroVideo onComplete={handleIntroComplete} />}
      <Router />
      <PWAInstallPrompt trigger="auto" />
      <Toaster />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <MusicProvider>
          <AppContent />
        </MusicProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
