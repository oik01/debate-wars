## Packages
framer-motion | Smooth animations for game states and transitions
lucide-react | Beautiful icons for UI elements
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes
date-fns | Formatting timestamps for debates and turns

## Notes
The app relies on `window.webkitSpeechRecognition` for speech-to-text. This is standard in Chrome/Safari but we should implement a text fallback for Firefox/others.
Authentication uses Replit Auth (`useAuth` hook provided).
Images will use Unsplash for category backgrounds.
