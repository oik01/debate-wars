# Debate Wars

## Overview

Debate Wars is a real-time debate competition platform where users can challenge others to audio debates on controversial topics. The application uses Google Gemini AI to generate debate topics, categories, and act as an impartial judge to determine winners based on logic and persuasion. Users can create debates, join open challenges, and submit arguments via speech-to-text or manual text input.

### Key Features
- **Cinematic Intro Video**: Shows a dramatic intro with debate arena, robot judges, and fireworks on first visit
- **AI-Generated Topics**: 30 categories with 20+ timely, controversial debate topics per category
- **Custom Topics**: Users can write their own debate statements
- **Background Music**: Multiple ambient music tracks with settings control (Chill Vibes default)
- **ELO Ranking System**: Competitive rating system that updates after each debate judgment
- **Worldwide Leaderboard**: Top 50 debaters ranked by ELO rating
- **Friends & Rivals**: Request-based system to add other users as friends or rivals
  - Send friend/rival requests by searching for usernames
  - Accept/decline pending requests in the Requests tab
  - View sent requests and their status
  - Shareable invite links still available for easy sharing
- **Clickable Avatars**: Click any user avatar throughout the app to view their profile
  - UserProfileModal displays stats, debate history (last 10), and radar chart
  - Friend/rival request buttons directly from the modal
  - Integrated in: profile page, debate room, leaderboard, search results, friends/rivals tabs
- **Political Affiliation**: Choose Democrat, Republican, or Independent for Political Arena
  - Can only change affiliation once every 30 days
  - Managed in Settings tab on profile page
- **Discover the World Challenge**: Tournament-style mode with category-based matchmaking, 30-minute research periods, 3 debate rounds, AI takeover if opponent abandons
  - Enhanced visuals: Player cards with avatars, country flags, and ELO tier badges (Bronze/Silver/Gold/Diamond/Master)
  - Animations: Match found reveal with 2.5s transition, confetti celebration on victory, pulsing Ready button, animated score counters
  - Sound effects: Match found, ready clicked, victory/defeat sounds with useSound hook
  - Stats panel: Total challenges, wins/losses, win rate, current streak, best category display
  - Recent matches carousel: Last 5 challenge results with win/loss indicators
  - Gamification badges: Category Master (5+ wins), Perfect Wins (3-0), Underdog (beating higher ELO)
  - Round timeline: Visual progress indicator showing completed/current/upcoming rounds
- **Push Notifications**: Web push notifications for debate updates and challenges
  - Bell icon toggle in header to enable/disable notifications
  - Notifies for: debate joined, turn ready, judgment issued, challenge invite accepted, round complete, challenge complete
  - Uses VAPID authentication with web-push library
  - Service worker handles background notifications with click-to-navigate
- **Comprehensive Grading System**: AI judges assign detailed grades for each debater
  - Categories: Logic & Reasoning, Evidence & Facts, Persuasion & Rhetoric, Rebuttals & Counters
  - Letter grades (A-F) with detailed explanations for each category
  - Visual winner display with ribbons, avatars, and clear winner indication
  - Expandable report cards showing grades that reveal explanations when clicked
  - Pro/Con references automatically replaced with actual usernames in explanations
  - User profile tracks running averages across all graded debates
  - Radar chart visualization on profile page showing performance across categories
- **AI Opponent Personalities**: 20 unique AI opponents across 4 difficulty tiers
  - Beginner tier (ELO 800-950): Echo, Parrot, Basic Bob, Simple Simon, Agreeable Andy
  - Intermediate tier (ELO 1000-1150): Silver Tongue, The Professor, Logical Larry, Witty Wendy, Facts Frank
  - Expert tier (ELO 1200-1400): Iron Jaw, The Diplomat, Razor Sharp, Storm Chaser, Mind Bender
  - Master tier (ELO 1450-1700): Walid Jumblatt (flip-flops positions), The Oracle, Grandmaster Grey, Socratic Sage, The Inquisitor
  - Each opponent has unique personality, skill ratings (0-4 scale) across Logic, Evidence, Persuasion, Rebuttals
  - Special traits affect debate behavior (flip_flops_positions, accidentally_agrees, rambles)
  - Skill levels influence AI prompt instructions for more realistic difficulty scaling
  - Clickable avatar in debate room opens profile modal with radar chart and statistics

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Animations**: Framer Motion for smooth transitions
- **Build Tool**: Vite with path aliases (@/, @shared/, @assets/)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful endpoints under /api prefix
- **Authentication**: Replit Auth with OpenID Connect, session-based using express-session and connect-pg-simple
- **Build**: Custom esbuild script bundling server dependencies for optimized cold starts

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: shared/schema.ts (shared between client and server)
- **Key Tables**: debates, turns, judgments, users, sessions, conversations, messages, user_relationships, invite_links, world_challenge_queue, world_challenges, world_challenge_rounds, push_subscriptions, relationship_requests, ai_opponents
- **Migrations**: Drizzle Kit with `db:push` command

### AI Integration
- **Provider**: Google Gemini via Replit AI Integrations
- **Models Used**: gemini-2.5-flash (fast), gemini-2.5-flash-image (image generation)
- **Features**: Dynamic category/topic generation, debate judging, chat functionality
- **Configuration**: Uses AI_INTEGRATIONS_GEMINI_API_KEY and AI_INTEGRATIONS_GEMINI_BASE_URL environment variables

### Key Design Patterns
- **Shared Types**: Schema definitions in /shared folder accessible by both client and server
- **Modular Integrations**: Server integrations organized under /server/replit_integrations (auth, chat, image, batch)
- **Component Library**: Full shadcn/ui implementation with custom theming for dark mode competitive aesthetic

## External Dependencies

### Database
- PostgreSQL (DATABASE_URL environment variable required)
- Drizzle ORM for type-safe queries and schema management

### Authentication
- Replit Auth (OpenID Connect)
- SESSION_SECRET environment variable required
- Passport.js with custom Replit strategy

### AI Services
- Replit AI Integrations (Gemini-compatible API)
- AI_INTEGRATIONS_GEMINI_API_KEY and AI_INTEGRATIONS_GEMINI_BASE_URL required

### Browser APIs
- Web Speech API (window.webkitSpeechRecognition) for speech-to-text
- Fallback to manual text input for unsupported browsers (Firefox)

### Push Notifications
- web-push library for VAPID authentication and sending notifications
- VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY environment variables required
- Service worker at /sw.js handles background push events
- Subscriptions stored in push_subscriptions table

### Third-Party Libraries
- @tanstack/react-query for data fetching
- framer-motion for animations
- date-fns for date formatting
- lucide-react for icons
- web-push for push notifications
- Radix UI primitives via shadcn/ui