import { z } from 'zod';
import { insertDebateSchema, insertTurnSchema, debates, turns, judgments } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  topics: {
    list: {
      method: 'GET' as const,
      path: '/api/topics',
      input: z.object({
        category: z.enum(['news', 'politics', 'sports', 'business', 'religion']).optional(),
      }).optional(),
      responses: {
        200: z.array(z.string()),
      },
    },
  },
  debates: {
    list: {
      method: 'GET' as const,
      path: '/api/debates',
      input: z.object({
        status: z.enum(['waiting', 'active', 'completed']).optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<any>()), // Typed as DebateWithRelations in frontend
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/debates',
      input: insertDebateSchema,
      responses: {
        201: z.custom<typeof debates.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/debates/:id',
      responses: {
        200: z.custom<any>(), // Typed as DebateWithRelations
        404: errorSchemas.notFound,
      },
    },
    join: {
      method: 'POST' as const,
      path: '/api/debates/:id/join',
      responses: {
        200: z.custom<typeof debates.$inferSelect>(),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  turns: {
    create: {
      method: 'POST' as const,
      path: '/api/debates/:id/turns',
      input: z.object({
        transcript: z.string().min(1, "Argument transcript is required"),
      }),
      responses: {
        201: z.custom<typeof turns.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
