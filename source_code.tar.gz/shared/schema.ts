import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, json } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Import Auth and Chat models to re-export them
export * from "./models/auth";
export * from "./models/chat";

import { users } from "./models/auth";

// === DEBATE SCHEMA ===

export const debates = pgTable("debates", {
  id: serial("id").primaryKey(),
  topic: text("topic").notNull(),
  category: text("category").notNull(), // news, politics, sports, business, religion
  status: text("status").notNull().default("waiting"), // waiting, active, judging, completed
  creatorId: text("creator_id").notNull(), // references users.id
  opponentId: text("opponent_id"), // references users.id, nullable for open challenges
  winnerId: text("winner_id"), // references users.id
  creatorSide: text("creator_side").notNull().default("pro"), // pro or con
  opponentType: text("opponent_type").notNull().default("open"), // open, friend, ai, political
  targetUserId: text("target_user_id"), // for friend/rival direct challenges
  aiOpponentId: integer("ai_opponent_id"), // references aiOpponents.id for AI debates
  currentRound: integer("current_round").notNull().default(1), // 1, 2, or 3
  inviteCode: text("invite_code"), // shareable code for joining
  creatorAffiliation: text("creator_affiliation"), // democrat, republican, independent - for political debates
  requiredAffiliation: text("required_affiliation"), // the affiliation required to join (opposite of creator)
  createdAt: timestamp("created_at").defaultNow(),
});

export const turns = pgTable("turns", {
  id: serial("id").primaryKey(),
  debateId: integer("debate_id").notNull(),
  userId: text("user_id").notNull(),
  transcript: text("transcript").notNull(),
  side: text("side").notNull(), // pro or con
  roundNumber: integer("round_number").notNull().default(1), // 1, 2, or 3
  audioUrl: text("audio_url"), // URL to stored audio recording
  isAI: boolean("is_ai").default(false), // true for AI-generated turns
  createdAt: timestamp("created_at").defaultNow(),
});

export const judgments = pgTable("judgments", {
  id: serial("id").primaryKey(),
  debateId: integer("debate_id").notNull(),
  winnerId: text("winner_id"),
  explanation: text("explanation").notNull(),
  // Grades for creator (A, B, C, D, F)
  creatorLogicGrade: text("creator_logic_grade"),
  creatorEvidenceGrade: text("creator_evidence_grade"),
  creatorPersuasionGrade: text("creator_persuasion_grade"),
  creatorRebuttalsGrade: text("creator_rebuttals_grade"),
  creatorOverallGrade: text("creator_overall_grade"),
  creatorLogicExplanation: text("creator_logic_explanation"),
  creatorEvidenceExplanation: text("creator_evidence_explanation"),
  creatorPersuasionExplanation: text("creator_persuasion_explanation"),
  creatorRebuttalsExplanation: text("creator_rebuttals_explanation"),
  creatorOverallExplanation: text("creator_overall_explanation"),
  // Grades for opponent (A, B, C, D, F)
  opponentLogicGrade: text("opponent_logic_grade"),
  opponentEvidenceGrade: text("opponent_evidence_grade"),
  opponentPersuasionGrade: text("opponent_persuasion_grade"),
  opponentRebuttalsGrade: text("opponent_rebuttals_grade"),
  opponentOverallGrade: text("opponent_overall_grade"),
  opponentLogicExplanation: text("opponent_logic_explanation"),
  opponentEvidenceExplanation: text("opponent_evidence_explanation"),
  opponentPersuasionExplanation: text("opponent_persuasion_explanation"),
  opponentRebuttalsExplanation: text("opponent_rebuttals_explanation"),
  opponentOverallExplanation: text("opponent_overall_explanation"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===

export const debatesRelations = relations(debates, ({ one, many }) => ({
  creator: one(users, {
    fields: [debates.creatorId],
    references: [users.id],
    relationName: "createdDebates",
  }),
  opponent: one(users, {
    fields: [debates.opponentId],
    references: [users.id],
    relationName: "opponentDebates",
  }),
  winner: one(users, {
    fields: [debates.winnerId],
    references: [users.id],
    relationName: "wonDebates",
  }),
  turns: many(turns),
  judgment: one(judgments, {
    fields: [debates.id],
    references: [judgments.debateId],
  }),
  aiOpponent: one(aiOpponents, {
    fields: [debates.aiOpponentId],
    references: [aiOpponents.id],
  }),
}));

export const turnsRelations = relations(turns, ({ one }) => ({
  debate: one(debates, {
    fields: [turns.debateId],
    references: [debates.id],
  }),
  user: one(users, {
    fields: [turns.userId],
    references: [users.id],
  }),
}));

// === ZOD SCHEMAS ===

export const insertDebateSchema = createInsertSchema(debates).omit({ 
  id: true, 
  createdAt: true, 
  status: true, 
  winnerId: true 
});

export const insertTurnSchema = createInsertSchema(turns).omit({ 
  id: true, 
  createdAt: true 
});

// === TYPES ===

export type Debate = typeof debates.$inferSelect;
export type InsertDebate = z.infer<typeof insertDebateSchema>;

export type Turn = typeof turns.$inferSelect;
export type InsertTurn = z.infer<typeof insertTurnSchema>;

export type Judgment = typeof judgments.$inferSelect;

// Specialized response types with relations
export type DebateWithRelations = Debate & {
  creator?: typeof users.$inferSelect;
  opponent?: typeof users.$inferSelect;
  turns?: Turn[];
  judgment?: Judgment;
  aiOpponent?: AiOpponent;
};

// === WORLD CHALLENGE (DISCOVER THE WORLD) ===

// Queue for matchmaking
export const worldChallengeQueue = pgTable("world_challenge_queue", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  category: text("category").notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

// Main challenge match
export const worldChallenges = pgTable("world_challenges", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  player1Id: text("player1_id").notNull(),
  player2Id: text("player2_id"),
  status: text("status").notNull().default("matching"), // matching, waiting, researching, debating, completed
  currentRound: integer("current_round").notNull().default(1),
  player1Score: integer("player1_score").notNull().default(0),
  player2Score: integer("player2_score").notNull().default(0),
  winnerId: text("winner_id"),
  researchDeadline: timestamp("research_deadline"),
  player1Ready: boolean("player1_ready").default(false),
  player2Ready: boolean("player2_ready").default(false),
  player2IsAI: boolean("player2_is_ai").default(false),
  inviteCode: text("invite_code"),
  isPrivate: boolean("is_private").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Individual rounds within a challenge
export const worldChallengeRounds = pgTable("world_challenge_rounds", {
  id: serial("id").primaryKey(),
  challengeId: integer("challenge_id").notNull(),
  roundNumber: integer("round_number").notNull(),
  topic: text("topic").notNull(),
  debateId: integer("debate_id"), // Links to debates table when debate starts
  winnerId: text("winner_id"),
  status: text("status").notNull().default("pending"), // pending, researching, debating, judged
  createdAt: timestamp("created_at").defaultNow(),
});

// === WORLD CHALLENGE RELATIONS ===

export const worldChallengesRelations = relations(worldChallenges, ({ one, many }) => ({
  player1: one(users, {
    fields: [worldChallenges.player1Id],
    references: [users.id],
    relationName: "player1Challenges",
  }),
  player2: one(users, {
    fields: [worldChallenges.player2Id],
    references: [users.id],
    relationName: "player2Challenges",
  }),
  winner: one(users, {
    fields: [worldChallenges.winnerId],
    references: [users.id],
    relationName: "wonChallenges",
  }),
  rounds: many(worldChallengeRounds),
}));

export const worldChallengeRoundsRelations = relations(worldChallengeRounds, ({ one }) => ({
  challenge: one(worldChallenges, {
    fields: [worldChallengeRounds.challengeId],
    references: [worldChallenges.id],
  }),
  debate: one(debates, {
    fields: [worldChallengeRounds.debateId],
    references: [debates.id],
  }),
  roundWinner: one(users, {
    fields: [worldChallengeRounds.winnerId],
    references: [users.id],
  }),
}));

// === WORLD CHALLENGE ZOD SCHEMAS ===

export const insertWorldChallengeQueueSchema = createInsertSchema(worldChallengeQueue).omit({
  id: true,
  joinedAt: true,
});

export const insertWorldChallengeSchema = createInsertSchema(worldChallenges).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  status: true,
  currentRound: true,
  player1Score: true,
  player2Score: true,
  winnerId: true,
  player1Ready: true,
  player2Ready: true,
  player2IsAI: true,
});

export const insertWorldChallengeRoundSchema = createInsertSchema(worldChallengeRounds).omit({
  id: true,
  createdAt: true,
  status: true,
  winnerId: true,
  debateId: true,
});

// === WORLD CHALLENGE TYPES ===

export type WorldChallengeQueue = typeof worldChallengeQueue.$inferSelect;
export type InsertWorldChallengeQueue = z.infer<typeof insertWorldChallengeQueueSchema>;

export type WorldChallenge = typeof worldChallenges.$inferSelect;
export type InsertWorldChallenge = z.infer<typeof insertWorldChallengeSchema>;

export type WorldChallengeRound = typeof worldChallengeRounds.$inferSelect;
export type InsertWorldChallengeRound = z.infer<typeof insertWorldChallengeRoundSchema>;

export type WorldChallengeWithRelations = WorldChallenge & {
  player1?: typeof users.$inferSelect;
  player2?: typeof users.$inferSelect;
  rounds?: WorldChallengeRound[];
};

// === PUSH NOTIFICATIONS ===

export const pushSubscriptions = pgTable("push_subscriptions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(), // Public key
  auth: text("auth").notNull(), // Auth secret
  createdAt: timestamp("created_at").defaultNow(),
});

export const pushSubscriptionsRelations = relations(pushSubscriptions, ({ one }) => ({
  user: one(users, {
    fields: [pushSubscriptions.userId],
    references: [users.id],
  }),
}));

export const insertPushSubscriptionSchema = createInsertSchema(pushSubscriptions).omit({
  id: true,
  createdAt: true,
});

export type PushSubscription = typeof pushSubscriptions.$inferSelect;
export type InsertPushSubscription = z.infer<typeof insertPushSubscriptionSchema>;

// === AI OPPONENTS ===

export const aiOpponents = pgTable("ai_opponents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  avatarId: text("avatar_id").notNull(), // References cartoon avatar ID (cartoon1, cartoon2, etc)
  bgColor: text("bg_color").notNull(), // Avatar background color
  difficulty: text("difficulty").notNull(), // beginner, intermediate, expert, master
  eloRating: integer("elo_rating").notNull().default(1000),
  personality: text("personality").notNull(), // Description of debate style
  specialTrait: text("special_trait"), // Special behavior like "flip-flops positions"
  // Skill ratings (0-4 scale matching grade system)
  logicSkill: integer("logic_skill").notNull().default(2),
  evidenceSkill: integer("evidence_skill").notNull().default(2),
  persuasionSkill: integer("persuasion_skill").notNull().default(2),
  rebuttalsSkill: integer("rebuttals_skill").notNull().default(2),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAiOpponentSchema = createInsertSchema(aiOpponents).omit({
  id: true,
  createdAt: true,
  wins: true,
  losses: true,
});

export type AiOpponent = typeof aiOpponents.$inferSelect;
export type InsertAiOpponent = z.infer<typeof insertAiOpponentSchema>;

// Sessions table for connect-pg-simple (auto-created but defined for schema consistency)
export const sessions = pgTable("sessions", {
  sid: varchar("sid").primaryKey(),
  sess: json("sess").notNull(),
  expire: timestamp("expire").notNull(),
});
