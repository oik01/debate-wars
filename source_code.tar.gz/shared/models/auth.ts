import { sql } from "drizzle-orm";
import { index, jsonb, pgTable, timestamp, varchar } from "drizzle-orm/pg-core";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  eloRating: varchar("elo_rating").default("1000"),
  wins: varchar("wins").default("0"),
  losses: varchar("losses").default("0"),
  nationality: varchar("nationality"),
  politicalAffiliation: varchar("political_affiliation"),
  politicalAffiliationLastChanged: timestamp("political_affiliation_last_changed"),
  favoriteCategories: varchar("favorite_categories"),
  avatarType: varchar("avatar_type").default("default"),
  customAvatarUrl: varchar("custom_avatar_url"),
  onboardingCompleted: varchar("onboarding_completed").default("false"),
  // Average debate grades (stored as sum and count for accurate averaging)
  avgLogicScore: varchar("avg_logic_score").default("0"),
  avgEvidenceScore: varchar("avg_evidence_score").default("0"),
  avgPersuasionScore: varchar("avg_persuasion_score").default("0"),
  avgRebuttalsScore: varchar("avg_rebuttals_score").default("0"),
  totalDebatesGraded: varchar("total_debates_graded").default("0"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User relationships (friends and enemies)
export const userRelationships = pgTable("user_relationships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  targetUserId: varchar("target_user_id").notNull(),
  relationshipType: varchar("relationship_type").notNull(), // 'friend' or 'enemy'
  createdAt: timestamp("created_at").defaultNow(),
});

// Invite links for challenging specific users
export const inviteLinks = pgTable("invite_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: varchar("code").notNull().unique(),
  creatorId: varchar("creator_id").notNull(),
  targetUserId: varchar("target_user_id"), // optional - for specific user invites
  debateId: varchar("debate_id"), // optional - link to specific debate
  inviteType: varchar("invite_type").notNull(), // 'friend', 'enemy', 'debate'
  used: varchar("used").default("false"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relationship requests (pending friend/rival requests)
export const relationshipRequests = pgTable("relationship_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").notNull(),
  receiverId: varchar("receiver_id").notNull(),
  requestType: varchar("request_type").notNull(), // 'friend' or 'rival'
  status: varchar("status").notNull().default("pending"), // 'pending', 'accepted', 'declined'
  createdAt: timestamp("created_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type UserRelationship = typeof userRelationships.$inferSelect;
export type InviteLink = typeof inviteLinks.$inferSelect;
export type RelationshipRequest = typeof relationshipRequests.$inferSelect;
