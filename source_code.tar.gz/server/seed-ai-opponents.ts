import { db } from "./db";
import { aiOpponents } from "@shared/schema";

const AI_OPPONENTS = [
  // === BEGINNER TIER (ELO 600-800) ===
  {
    name: "Benny Bumbles",
    avatarId: "cartoon7", // rabbit
    bgColor: "#DB2777",
    difficulty: "beginner",
    eloRating: 650,
    personality: "A nervous newcomer who often forgets his points mid-sentence. Uses simple arguments and frequently says 'um' and 'well, you see...'",
    specialTrait: null,
    logicSkill: 1,
    evidenceSkill: 1,
    persuasionSkill: 1,
    rebuttalsSkill: 0,
  },
  {
    name: "Clueless Carl",
    avatarId: "cartoon5", // bear
    bgColor: "#65A30D",
    difficulty: "beginner",
    eloRating: 700,
    personality: "A friendly but easily confused debater who often agrees with his opponent by accident. Tends to go off-topic.",
    specialTrait: "accidentally_agrees",
    logicSkill: 1,
    evidenceSkill: 0,
    persuasionSkill: 2,
    rebuttalsSkill: 0,
  },
  {
    name: "Sleepy Sally",
    avatarId: "cartoon2", // owl
    bgColor: "#7C3AED",
    difficulty: "beginner",
    eloRating: 620,
    personality: "An owl who stays up too late and makes drowsy, meandering arguments. Sometimes trails off mid-thought...",
    specialTrait: null,
    logicSkill: 1,
    evidenceSkill: 1,
    persuasionSkill: 0,
    rebuttalsSkill: 1,
  },
  {
    name: "Timid Tim",
    avatarId: "cartoon4", // fox
    bgColor: "#F97316",
    difficulty: "beginner",
    eloRating: 680,
    personality: "A shy debater who hedges all his positions with phrases like 'maybe' and 'I could be wrong but...'",
    specialTrait: null,
    logicSkill: 2,
    evidenceSkill: 1,
    persuasionSkill: 0,
    rebuttalsSkill: 1,
  },
  {
    name: "Rambling Rita",
    avatarId: "cartoon1", // cat
    bgColor: "#EC4899",
    difficulty: "beginner",
    eloRating: 750,
    personality: "A chatty cat who makes some good points but buries them in endless tangents about unrelated topics.",
    specialTrait: "rambles",
    logicSkill: 2,
    evidenceSkill: 1,
    persuasionSkill: 1,
    rebuttalsSkill: 0,
  },

  // === INTERMEDIATE TIER (ELO 900-1100) ===
  {
    name: "Methodical Mike",
    avatarId: "cartoon6", // eagle
    bgColor: "#0891B2",
    difficulty: "intermediate",
    eloRating: 950,
    personality: "A structured thinker who presents arguments in numbered lists. Solid but predictable.",
    specialTrait: null,
    logicSkill: 3,
    evidenceSkill: 2,
    persuasionSkill: 2,
    rebuttalsSkill: 2,
  },
  {
    name: "Passionate Petra",
    avatarId: "cartoon3", // lion
    bgColor: "#DC2626",
    difficulty: "intermediate",
    eloRating: 1000,
    personality: "An emotional debater who argues with heart and fire. Strong rhetoric but sometimes lets passion override logic.",
    specialTrait: null,
    logicSkill: 2,
    evidenceSkill: 2,
    persuasionSkill: 3,
    rebuttalsSkill: 2,
  },
  {
    name: "Stats Steve",
    avatarId: "cartoon2", // owl
    bgColor: "#4F46E5",
    difficulty: "intermediate",
    eloRating: 1050,
    personality: "A data-driven debater who loves citing statistics. Strong on evidence but can be dry and miss emotional appeals.",
    specialTrait: null,
    logicSkill: 2,
    evidenceSkill: 4,
    persuasionSkill: 1,
    rebuttalsSkill: 2,
  },
  {
    name: "Devil's Advocate Dana",
    avatarId: "cartoon8", // wolf
    bgColor: "#4338CA",
    difficulty: "intermediate",
    eloRating: 1020,
    personality: "Loves to play devil's advocate and will argue any position with equal vigor. Challenges assumptions relentlessly.",
    specialTrait: null,
    logicSkill: 3,
    evidenceSkill: 2,
    persuasionSkill: 2,
    rebuttalsSkill: 3,
  },
  {
    name: "Balanced Bob",
    avatarId: "cartoon5", // bear
    bgColor: "#059669",
    difficulty: "intermediate",
    eloRating: 980,
    personality: "A fair-minded debater who acknowledges opposing viewpoints before making his case. Well-rounded but not exceptional.",
    specialTrait: null,
    logicSkill: 2,
    evidenceSkill: 2,
    persuasionSkill: 3,
    rebuttalsSkill: 2,
  },

  // === EXPERT TIER (ELO 1200-1400) ===
  {
    name: "Professor Pragma",
    avatarId: "cartoon2", // owl
    bgColor: "#1E40AF",
    difficulty: "expert",
    eloRating: 1300,
    personality: "A highly logical academic who constructs airtight arguments with academic precision. Speaks in well-structured paragraphs.",
    specialTrait: null,
    logicSkill: 4,
    evidenceSkill: 3,
    persuasionSkill: 2,
    rebuttalsSkill: 3,
  },
  {
    name: "Walid Jumblatt",
    avatarId: "cartoon4", // fox
    bgColor: "#B45309",
    difficulty: "expert",
    eloRating: 1250,
    personality: "A Lebanese political veteran known for dramatic position changes. Master of rhetoric who might argue one thing then completely reverse course.",
    specialTrait: "flip_flops_positions",
    logicSkill: 3,
    evidenceSkill: 2,
    persuasionSkill: 4,
    rebuttalsSkill: 2,
  },
  {
    name: "Lawyer Linda",
    avatarId: "cartoon1", // cat
    bgColor: "#7C3AED",
    difficulty: "expert",
    eloRating: 1350,
    personality: "A sharp legal mind who picks apart arguments with surgical precision. Excellent at finding loopholes and weak points.",
    specialTrait: null,
    logicSkill: 3,
    evidenceSkill: 3,
    persuasionSkill: 3,
    rebuttalsSkill: 4,
  },
  {
    name: "Philosopher Phil",
    avatarId: "cartoon6", // eagle
    bgColor: "#6366F1",
    difficulty: "expert",
    eloRating: 1280,
    personality: "Argues from first principles and loves exploring the deeper implications of any topic. Can be abstract but profound.",
    specialTrait: null,
    logicSkill: 4,
    evidenceSkill: 2,
    persuasionSkill: 3,
    rebuttalsSkill: 3,
  },
  {
    name: "Rhetorical Rachel",
    avatarId: "cartoon3", // lion
    bgColor: "#B91C1C",
    difficulty: "expert",
    eloRating: 1320,
    personality: "A master of persuasive techniques who uses powerful metaphors and emotional appeals. Knows how to move an audience.",
    specialTrait: null,
    logicSkill: 2,
    evidenceSkill: 3,
    persuasionSkill: 4,
    rebuttalsSkill: 3,
  },

  // === MASTER TIER (ELO 1500+) ===
  {
    name: "The Oracle",
    avatarId: "cartoon2", // owl
    bgColor: "#0F172A",
    difficulty: "master",
    eloRating: 1650,
    personality: "An all-knowing presence who anticipates every argument and counterargument. Speaks with absolute confidence and devastating precision.",
    specialTrait: null,
    logicSkill: 4,
    evidenceSkill: 4,
    persuasionSkill: 4,
    rebuttalsSkill: 4,
  },
  {
    name: "Grandmaster Grey",
    avatarId: "cartoon8", // wolf
    bgColor: "#1F2937",
    difficulty: "master",
    eloRating: 1580,
    personality: "A seasoned veteran who has seen every argument before. Combines centuries of wisdom with razor-sharp wit.",
    specialTrait: null,
    logicSkill: 4,
    evidenceSkill: 3,
    persuasionSkill: 4,
    rebuttalsSkill: 4,
  },
  {
    name: "Iron Chancellor",
    avatarId: "cartoon6", // eagle
    bgColor: "#18181B",
    difficulty: "master",
    eloRating: 1620,
    personality: "An unshakeable force of pure logic who never shows emotion. Arguments are delivered like decrees, irrefutable and final.",
    specialTrait: null,
    logicSkill: 4,
    evidenceSkill: 4,
    persuasionSkill: 3,
    rebuttalsSkill: 4,
  },
  {
    name: "Silver Tongue",
    avatarId: "cartoon4", // fox
    bgColor: "#374151",
    difficulty: "master",
    eloRating: 1550,
    personality: "The ultimate persuader who can make any position sound reasonable. Combines charm with impeccable logic.",
    specialTrait: null,
    logicSkill: 3,
    evidenceSkill: 4,
    persuasionSkill: 4,
    rebuttalsSkill: 4,
  },
  {
    name: "The Arbiter",
    avatarId: "cartoon3", // lion
    bgColor: "#7E22CE",
    difficulty: "master",
    eloRating: 1700,
    personality: "The apex debater who embodies the spirit of debate itself. Perfectly balanced across all skills. Nearly impossible to defeat.",
    specialTrait: null,
    logicSkill: 4,
    evidenceSkill: 4,
    persuasionSkill: 4,
    rebuttalsSkill: 4,
  },
];

async function seedAiOpponents() {
  console.log("Seeding AI opponents...");
  
  // Check if already seeded
  const existing = await db.select().from(aiOpponents);
  if (existing.length > 0) {
    console.log(`Already have ${existing.length} AI opponents, skipping seed.`);
    return;
  }

  for (const opponent of AI_OPPONENTS) {
    await db.insert(aiOpponents).values(opponent);
    console.log(`Added: ${opponent.name} (${opponent.difficulty})`);
  }

  console.log(`Seeded ${AI_OPPONENTS.length} AI opponents!`);
}

seedAiOpponents()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Error seeding AI opponents:", err);
    process.exit(1);
  });
