import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import { pool } from "./db";
import { ensureSchema } from "./ensure-schema";
import { runStartupSeed } from "./seed-startup";

// Production startup logging
function startupLog(message: string) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] [STARTUP] ${message}`);
}

const app = express();
const httpServer = createServer(app);

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false }));

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  try {
    startupLog("Starting server initialization...");
    startupLog(`Environment: ${process.env.NODE_ENV || "development"}`);
    
    // Verify database connection first
    startupLog("Verifying database connection...");
    try {
      const result = await pool.query("SELECT 1 as connected");
      if (result.rows[0]?.connected === 1) {
        startupLog("Database connection verified successfully");
      }
    } catch (dbError) {
      console.error("[STARTUP] Database connection failed:", dbError);
      throw new Error(`Database connection failed: ${dbError instanceof Error ? dbError.message : String(dbError)}`);
    }
    
    // Ensure database schema exists (creates tables if missing)
    startupLog("Ensuring database schema...");
    await ensureSchema();
    startupLog("Database schema verified");
    
    // Run startup seed (AI opponents, users, debates)
    startupLog("Running startup seed...");
    await runStartupSeed();
    startupLog("Startup seed complete");
    
    // Register routes
    startupLog("Registering routes...");
    await registerRoutes(httpServer, app);
    startupLog("Routes registered successfully");

    app.use((err: any, _req: Request, res: Response, next: NextFunction) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";

      console.error("Internal Server Error:", err);

      if (res.headersSent) {
        return next(err);
      }

      return res.status(status).json({ message });
    });

    // importantly only setup vite in development and after
    // setting up all the other routes so the catch-all route
    // doesn't interfere with the other routes
    if (process.env.NODE_ENV === "production") {
      startupLog("Setting up static file serving for production...");
      serveStatic(app);
      startupLog("Static file serving configured");
    } else {
      startupLog("Setting up Vite for development...");
      const { setupVite } = await import("./vite");
      await setupVite(httpServer, app);
      startupLog("Vite setup complete");
    }

    // ALWAYS serve the app on the port specified in the environment variable PORT
    // Other ports are firewalled. Default to 5000 if not specified.
    // this serves both the API and the client.
    // It is the only port that is not firewalled.
    const port = parseInt(process.env.PORT || "5000", 10);
    const host = "0.0.0.0";
    
    startupLog(`Attempting to bind to ${host}:${port}...`);
    
    httpServer.listen(
      {
        port,
        host,
        reusePort: true,
      },
      () => {
        startupLog(`Server successfully bound to ${host}:${port}`);
        log(`serving on port ${port}`);
      },
    );
    
    // Handle server errors
    httpServer.on("error", (error: NodeJS.ErrnoException) => {
      console.error("[STARTUP] Server error:", error);
      if (error.code === "EADDRINUSE") {
        console.error(`[STARTUP] Port ${port} is already in use`);
      }
      process.exit(1);
    });
    
  } catch (error) {
    console.error("[STARTUP] Fatal error during server initialization:", error);
    process.exit(1);
  }
})();
