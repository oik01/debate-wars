import { db } from "./db";
import { 
  debates, turns, judgments, users, userRelationships, inviteLinks,
  worldChallengeQueue, worldChallenges, worldChallengeRounds,
  pushSubscriptions, relationshipRequests, aiOpponents,
  type Debate, type InsertDebate, 
  type Turn, type InsertTurn,
  type Judgment, type DebateWithRelations,
  type User, type UserRelationship, type InviteLink, type RelationshipRequest,
  type WorldChallengeQueue, type WorldChallenge, type WorldChallengeRound,
  type WorldChallengeWithRelations,
  type PushSubscription, type InsertPushSubscription,
  type AiOpponent
} from "@shared/schema";
import { eq, or, desc, and, sql, ne, asc } from "drizzle-orm";

export interface IStorage {
  // Debates
  createDebate(debate: InsertDebate): Promise<Debate>;
  getDebate(id: number): Promise<DebateWithRelations | undefined>;
  getDebateByInviteCode(code: string): Promise<DebateWithRelations | undefined>;
  getDebates(status?: string): Promise<DebateWithRelations[]>;
  updateDebateStatus(id: number, status: string, winnerId?: string): Promise<Debate>;
  updateDebateRound(id: number, round: number): Promise<Debate>;
  joinDebate(id: number, userId: string): Promise<Debate>;
  
  // Turns
  createTurn(turn: InsertTurn): Promise<Turn>;
  getTurns(debateId: number): Promise<Turn[]>;
  
  // Judgments
  createJudgment(judgment: {
    debateId: number;
    winnerId?: string;
    explanation: string;
    creatorLogicGrade?: string;
    creatorEvidenceGrade?: string;
    creatorPersuasionGrade?: string;
    creatorRebuttalsGrade?: string;
    creatorOverallGrade?: string;
    creatorLogicExplanation?: string;
    creatorEvidenceExplanation?: string;
    creatorPersuasionExplanation?: string;
    creatorRebuttalsExplanation?: string;
    creatorOverallExplanation?: string;
    opponentLogicGrade?: string;
    opponentEvidenceGrade?: string;
    opponentPersuasionGrade?: string;
    opponentRebuttalsGrade?: string;
    opponentOverallGrade?: string;
    opponentLogicExplanation?: string;
    opponentEvidenceExplanation?: string;
    opponentPersuasionExplanation?: string;
    opponentRebuttalsExplanation?: string;
    opponentOverallExplanation?: string;
  }): Promise<Judgment>;
  deleteJudgmentByDebateId(debateId: number): Promise<void>;

  // Users & ELO
  getUser(id: string): Promise<User | undefined>;
  updateUserElo(userId: string, newElo: number, won: boolean): Promise<User>;
  updateUserGradeAverages(userId: string, grades: {
    avgLogicScore: string;
    avgEvidenceScore: string;
    avgPersuasionScore: string;
    avgRebuttalsScore: string;
    totalDebatesGraded: string;
  }): Promise<User>;
  getLeaderboard(limit?: number): Promise<(User & { rank: number })[]>;
  getUserRank(userId: string): Promise<number>;
  searchUsers(query: string): Promise<User[]>;

  // Relationships
  addRelationship(userId: string, targetUserId: string, type: string): Promise<UserRelationship>;
  removeRelationship(userId: string, targetUserId: string): Promise<void>;
  getRelationships(userId: string): Promise<{ friends: User[], enemies: User[] }>;

  // Invite Links
  createInviteLink(data: { code: string, creatorId: string, targetUserId?: string, debateId?: string, inviteType: string, expiresAt?: Date }): Promise<InviteLink>;
  getInviteLink(code: string): Promise<InviteLink | undefined>;
  markInviteUsed(code: string): Promise<void>;

  // User Profile
  updateUserProfile(userId: string, data: Partial<{
    nationality: string;
    politicalAffiliation: string;
    favoriteCategories: string;
    avatarType: string;
    customAvatarUrl: string;
    firstName: string;
    lastName: string;
    onboardingCompleted: string;
  }>): Promise<User>;

  // World Challenge
  joinWorldChallengeQueue(userId: string, category: string): Promise<{ matched: boolean, challenge?: WorldChallengeWithRelations }>;
  leaveWorldChallengeQueue(userId: string): Promise<void>;
  getWorldChallenge(id: number): Promise<WorldChallengeWithRelations | undefined>;
  getWorldChallengeByInviteCode(code: string): Promise<WorldChallengeWithRelations | undefined>;
  getUserActiveChallenge(userId: string): Promise<WorldChallengeWithRelations | undefined>;
  setPlayerReady(challengeId: number, playerId: string): Promise<WorldChallenge>;
  startChallengeDebate(challengeId: number): Promise<{ challenge: WorldChallenge, debate: Debate }>;
  updateChallengeRoundWinner(challengeId: number, roundNumber: number, winnerId: string): Promise<WorldChallenge>;
  advanceChallengeRound(challengeId: number): Promise<WorldChallenge>;
  completeChallengeWithAI(challengeId: number): Promise<WorldChallenge>;
  getUserChallengeStats(userId: string): Promise<{
    totalChallenges: number;
    wins: number;
    losses: number;
    winRate: number;
    bestCategory: string | null;
    currentStreak: number;
    badges: {
      categoryMaster: string | null;
      perfectWins: number;
      underdogWins: number;
    };
  }>;
  getUserChallengeHistory(userId: string, limit: number): Promise<WorldChallengeWithRelations[]>;
  createPrivateChallenge(userId: string, category: string): Promise<WorldChallengeWithRelations>;
  joinChallengeByInviteCode(userId: string, code: string): Promise<WorldChallengeWithRelations>;
  getPendingChallenges(userId: string): Promise<WorldChallengeWithRelations[]>;
  cancelChallenge(challengeId: number, userId: string): Promise<void>;
  
  // Push Subscriptions
  savePushSubscription(userId: string, subscription: { endpoint: string, p256dh: string, auth: string }): Promise<PushSubscription>;
  deletePushSubscription(userId: string, endpoint: string): Promise<void>;
  getUserPushSubscriptions(userId: string): Promise<PushSubscription[]>;

  // Political Affiliation
  updatePoliticalAffiliation(userId: string, affiliation: string): Promise<User>;
  canChangePoliticalAffiliation(userId: string): Promise<{ canChange: boolean, nextChangeDate?: Date }>;

  // Relationship Requests
  createRelationshipRequest(senderId: string, receiverId: string, requestType: string): Promise<RelationshipRequest>;
  getPendingRequestsForUser(userId: string): Promise<(RelationshipRequest & { sender: User })[]>;
  getSentRequests(userId: string): Promise<(RelationshipRequest & { receiver: User })[]>;
  acceptRelationshipRequest(requestId: string, userId: string): Promise<UserRelationship>;
  declineRelationshipRequest(requestId: string, userId: string): Promise<void>;
  getExistingRequest(senderId: string, receiverId: string): Promise<RelationshipRequest | undefined>;
  getExistingRequestBothDirections(userId1: string, userId2: string): Promise<{ request: RelationshipRequest, direction: 'sent' | 'received' } | undefined>;
  
  // AI Opponents
  getAiOpponents(): Promise<AiOpponent[]>;
  getAiOpponent(id: number): Promise<AiOpponent | undefined>;
  updateAiOpponentStats(id: number, won: boolean): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async createDebate(debate: InsertDebate): Promise<Debate> {
    const [newDebate] = await db.insert(debates).values(debate).returning();
    return newDebate;
  }

  async getDebate(id: number): Promise<DebateWithRelations | undefined> {
    const debate = await db.query.debates.findFirst({
      where: eq(debates.id, id),
      with: {
        creator: true,
        opponent: true,
        turns: {
          orderBy: (turns, { asc }) => [asc(turns.createdAt)],
          with: {
            user: true
          }
        },
        judgment: true,
        aiOpponent: true,
      },
    });
    return debate;
  }

  async getDebateByInviteCode(code: string): Promise<DebateWithRelations | undefined> {
    const debate = await db.query.debates.findFirst({
      where: eq(debates.inviteCode, code),
      with: {
        creator: true,
        opponent: true,
        turns: {
          orderBy: (turns, { asc }) => [asc(turns.createdAt)],
          with: {
            user: true
          }
        },
        judgment: true,
        aiOpponent: true,
      },
    });
    return debate;
  }

  async getDebates(status?: string): Promise<DebateWithRelations[]> {
    const whereClause = status ? eq(debates.status, status) : undefined;
    
    return db.query.debates.findMany({
      where: whereClause,
      orderBy: [desc(debates.createdAt)],
      with: {
        creator: true,
        opponent: true,
        judgment: true,
      },
      limit: 50,
    });
  }

  async getDebatesByUser(userId: string): Promise<DebateWithRelations[]> {
    return db.query.debates.findMany({
      where: or(eq(debates.creatorId, userId), eq(debates.opponentId, userId)),
      orderBy: [desc(debates.createdAt)],
      with: {
        creator: true,
        opponent: true,
        judgment: true,
      },
      limit: 50,
    });
  }

  async updateDebateStatus(id: number, status: string, winnerId?: string): Promise<Debate> {
    const [updated] = await db.update(debates)
      .set({ status, winnerId })
      .where(eq(debates.id, id))
      .returning();
    return updated;
  }

  async updateDebateRound(id: number, round: number): Promise<Debate> {
    const [updated] = await db.update(debates)
      .set({ currentRound: round })
      .where(eq(debates.id, id))
      .returning();
    return updated;
  }

  async joinDebate(id: number, userId: string): Promise<Debate> {
    const [updated] = await db.update(debates)
      .set({ opponentId: userId, status: "active" })
      .where(eq(debates.id, id))
      .returning();
    return updated;
  }

  async createTurn(turn: InsertTurn): Promise<Turn> {
    const [newTurn] = await db.insert(turns).values(turn).returning();
    return newTurn;
  }

  async getTurns(debateId: number): Promise<Turn[]> {
    return db.select().from(turns).where(eq(turns.debateId, debateId)).orderBy(turns.createdAt);
  }

  async createJudgment(data: {
    debateId: number;
    winnerId?: string;
    explanation: string;
    creatorLogicGrade?: string;
    creatorEvidenceGrade?: string;
    creatorPersuasionGrade?: string;
    creatorRebuttalsGrade?: string;
    creatorOverallGrade?: string;
    creatorLogicExplanation?: string;
    creatorEvidenceExplanation?: string;
    creatorPersuasionExplanation?: string;
    creatorRebuttalsExplanation?: string;
    creatorOverallExplanation?: string;
    opponentLogicGrade?: string;
    opponentEvidenceGrade?: string;
    opponentPersuasionGrade?: string;
    opponentRebuttalsGrade?: string;
    opponentOverallGrade?: string;
    opponentLogicExplanation?: string;
    opponentEvidenceExplanation?: string;
    opponentPersuasionExplanation?: string;
    opponentRebuttalsExplanation?: string;
    opponentOverallExplanation?: string;
  }): Promise<Judgment> {
    const [judgment] = await db.insert(judgments).values(data).returning();
    return judgment;
  }

  async deleteJudgmentByDebateId(debateId: number): Promise<void> {
    await db.delete(judgments).where(eq(judgments.debateId, debateId));
  }

  // User & ELO functions
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async updateUserElo(userId: string, newElo: number, won: boolean): Promise<User> {
    const user = await this.getUser(userId);
    const currentWins = parseInt(user?.wins || "0");
    const currentLosses = parseInt(user?.losses || "0");
    
    const [updated] = await db.update(users)
      .set({ 
        eloRating: newElo.toString(),
        wins: won ? (currentWins + 1).toString() : currentWins.toString(),
        losses: won ? currentLosses.toString() : (currentLosses + 1).toString(),
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async updateUserGradeAverages(userId: string, grades: {
    avgLogicScore: string;
    avgEvidenceScore: string;
    avgPersuasionScore: string;
    avgRebuttalsScore: string;
    totalDebatesGraded: string;
  }): Promise<User> {
    const [updated] = await db.update(users)
      .set({
        avgLogicScore: grades.avgLogicScore,
        avgEvidenceScore: grades.avgEvidenceScore,
        avgPersuasionScore: grades.avgPersuasionScore,
        avgRebuttalsScore: grades.avgRebuttalsScore,
        totalDebatesGraded: grades.totalDebatesGraded,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async getLeaderboard(limit: number = 50): Promise<(User & { rank: number })[]> {
    // Use DENSE_RANK to handle ties - users with same ELO get same rank
    const result = await db.execute(sql`
      SELECT *, DENSE_RANK() OVER (ORDER BY CAST(elo_rating AS INTEGER) DESC) as rank
      FROM users
      ORDER BY CAST(elo_rating AS INTEGER) DESC
      LIMIT ${limit}
    `);
    
    return result.rows.map((row: any) => ({
      id: row.id,
      email: row.email,
      firstName: row.first_name,
      lastName: row.last_name,
      profileImageUrl: row.profile_image_url,
      eloRating: row.elo_rating,
      wins: row.wins,
      losses: row.losses,
      avatarType: row.avatar_type,
      customAvatarUrl: row.custom_avatar_url,
      nationality: row.nationality,
      politicalAffiliation: row.political_affiliation,
      favoriteCategories: row.favorite_categories,
      logicAvg: row.logic_avg,
      evidenceAvg: row.evidence_avg,
      persuasionAvg: row.persuasion_avg,
      rebuttalsAvg: row.rebuttals_avg,
      totalDebatesGraded: row.total_debates_graded,
      affiliationChangedAt: row.affiliation_changed_at,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      rank: parseInt(row.rank, 10)
    }));
  }

  async getUserRank(userId: string): Promise<number> {
    // Use DENSE_RANK to get the user's rank, consistent with leaderboard
    const result = await db.execute(sql`
      SELECT rank FROM (
        SELECT id, DENSE_RANK() OVER (ORDER BY CAST(elo_rating AS INTEGER) DESC) as rank
        FROM users
      ) ranked
      WHERE id = ${userId}
    `);
    
    if (result.rows.length === 0) return 0;
    return parseInt((result.rows[0] as any).rank, 10);
  }

  // Relationships
  async addRelationship(userId: string, targetUserId: string, type: string): Promise<UserRelationship> {
    // Remove existing relationship if any
    await db.delete(userRelationships)
      .where(and(
        eq(userRelationships.userId, userId),
        eq(userRelationships.targetUserId, targetUserId)
      ));
    
    const [rel] = await db.insert(userRelationships)
      .values({ userId, targetUserId, relationshipType: type })
      .returning();
    return rel;
  }

  async removeRelationship(userId: string, targetUserId: string): Promise<void> {
    await db.delete(userRelationships)
      .where(and(
        eq(userRelationships.userId, userId),
        eq(userRelationships.targetUserId, targetUserId)
      ));
  }

  async getRelationships(userId: string): Promise<{ friends: User[], enemies: User[] }> {
    const rels = await db.select().from(userRelationships)
      .where(eq(userRelationships.userId, userId));
    
    const friendIds = rels.filter(r => r.relationshipType === 'friend').map(r => r.targetUserId);
    const enemyIds = rels.filter(r => r.relationshipType === 'enemy').map(r => r.targetUserId);
    
    const friends = friendIds.length > 0 
      ? await db.select().from(users).where(sql`${users.id} IN (${sql.join(friendIds.map(id => sql`${id}`), sql`, `)})`)
      : [];
    const enemies = enemyIds.length > 0 
      ? await db.select().from(users).where(sql`${users.id} IN (${sql.join(enemyIds.map(id => sql`${id}`), sql`, `)})`)
      : [];
    
    return { friends, enemies };
  }

  // Invite Links
  async createInviteLink(data: { code: string, creatorId: string, targetUserId?: string, debateId?: string, inviteType: string, expiresAt?: Date }): Promise<InviteLink> {
    const [link] = await db.insert(inviteLinks).values(data).returning();
    return link;
  }

  async getInviteLink(code: string): Promise<InviteLink | undefined> {
    const [link] = await db.select().from(inviteLinks).where(eq(inviteLinks.code, code));
    return link;
  }

  async markInviteUsed(code: string): Promise<void> {
    await db.update(inviteLinks).set({ used: "true" }).where(eq(inviteLinks.code, code));
  }

  async searchUsers(query: string): Promise<User[]> {
    return db.select().from(users)
      .where(sql`LOWER(${users.email}) LIKE LOWER(${'%' + query + '%'}) OR LOWER(${users.firstName}) LIKE LOWER(${'%' + query + '%'})`)
      .limit(20);
  }

  async updateUserProfile(userId: string, data: Partial<{
    nationality: string;
    politicalAffiliation: string;
    favoriteCategories: string;
    avatarType: string;
    customAvatarUrl: string;
    firstName: string;
    lastName: string;
    onboardingCompleted: string;
  }>): Promise<User> {
    // Use raw SQL with COALESCE to only update provided fields
    // Use SELECT * which gracefully handles missing columns in mapRowToUser
    const result = await db.execute(sql`
      UPDATE users 
      SET 
        nationality = COALESCE(${data.nationality ?? null}, nationality),
        political_affiliation = COALESCE(${data.politicalAffiliation ?? null}, political_affiliation),
        favorite_categories = COALESCE(${data.favoriteCategories ?? null}, favorite_categories),
        avatar_type = COALESCE(${data.avatarType ?? null}, avatar_type),
        custom_avatar_url = COALESCE(${data.customAvatarUrl ?? null}, custom_avatar_url),
        first_name = COALESCE(${data.firstName ?? null}, first_name),
        last_name = COALESCE(${data.lastName ?? null}, last_name),
        onboarding_completed = COALESCE(${data.onboardingCompleted ?? null}, onboarding_completed),
        updated_at = NOW()
      WHERE id = ${userId}
      RETURNING *
    `);
    
    if (result.rows.length === 0) {
      throw new Error(`User ${userId} not found`);
    }
    
    return this.mapRowToUser(result.rows[0]);
  }
  
  // Helper to map snake_case database row to camelCase User type
  private mapRowToUser(row: any): User {
    return {
      id: row.id,
      email: row.email,
      firstName: row.first_name,
      lastName: row.last_name,
      profileImageUrl: row.profile_image_url,
      eloRating: row.elo_rating || "1000",
      wins: row.wins || "0",
      losses: row.losses || "0",
      nationality: row.nationality || null,
      politicalAffiliation: row.political_affiliation || null,
      politicalAffiliationLastChanged: row.political_affiliation_last_changed || null,
      favoriteCategories: row.favorite_categories || null,
      avatarType: row.avatar_type || "default",
      customAvatarUrl: row.custom_avatar_url || null,
      onboardingCompleted: row.onboarding_completed || "false",
      avgLogicScore: row.avg_logic_score || "0",
      avgEvidenceScore: row.avg_evidence_score || "0",
      avgPersuasionScore: row.avg_persuasion_score || "0",
      avgRebuttalsScore: row.avg_rebuttals_score || "0",
      totalDebatesGraded: row.total_debates_graded || "0",
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    };
  }

  // World Challenge Methods
  async joinWorldChallengeQueue(userId: string, category: string): Promise<{ matched: boolean, challenge?: WorldChallengeWithRelations }> {
    // First check if user already has an active challenge
    const existingChallenge = await this.getUserActiveChallenge(userId);
    if (existingChallenge) {
      return { matched: true, challenge: existingChallenge };
    }

    // Remove any existing queue entries for this user
    await db.delete(worldChallengeQueue).where(eq(worldChallengeQueue.userId, userId));

    // Check for another player in queue for same category
    const [waitingPlayer] = await db.select()
      .from(worldChallengeQueue)
      .where(and(
        eq(worldChallengeQueue.category, category),
        ne(worldChallengeQueue.userId, userId)
      ))
      .orderBy(asc(worldChallengeQueue.joinedAt))
      .limit(1);

    if (waitingPlayer) {
      // Match found - remove them from queue and create challenge
      await db.delete(worldChallengeQueue).where(eq(worldChallengeQueue.id, waitingPlayer.id));

      // Generate 3 topics for this category (will be done via AI later)
      const topics = [
        `Topic 1 for ${category} - Generated debate topic`,
        `Topic 2 for ${category} - Generated debate topic`,
        `Topic 3 for ${category} - Generated debate topic`,
      ];

      // Create the challenge with 30 min research deadline
      const researchDeadline = new Date(Date.now() + 30 * 60 * 1000);
      
      const [challenge] = await db.insert(worldChallenges).values({
        category,
        player1Id: waitingPlayer.userId,
        player2Id: userId,
        status: "researching",
        researchDeadline,
      }).returning();

      // Create the 3 rounds
      for (let i = 1; i <= 3; i++) {
        await db.insert(worldChallengeRounds).values({
          challengeId: challenge.id,
          roundNumber: i,
          topic: topics[i - 1],
          status: i === 1 ? "researching" : "pending",
        });
      }

      const fullChallenge = await this.getWorldChallenge(challenge.id);
      return { matched: true, challenge: fullChallenge };
    } else {
      // No match - add to queue
      await db.insert(worldChallengeQueue).values({ userId, category });
      return { matched: false };
    }
  }

  async leaveWorldChallengeQueue(userId: string): Promise<void> {
    await db.delete(worldChallengeQueue).where(eq(worldChallengeQueue.userId, userId));
  }

  async getWorldChallenge(id: number): Promise<WorldChallengeWithRelations | undefined> {
    const challenge = await db.query.worldChallenges.findFirst({
      where: eq(worldChallenges.id, id),
      with: {
        player1: true,
        player2: true,
        rounds: {
          orderBy: (rounds, { asc }) => [asc(rounds.roundNumber)],
        },
      },
    });
    return challenge;
  }

  async getUserActiveChallenge(userId: string): Promise<WorldChallengeWithRelations | undefined> {
    const challenge = await db.query.worldChallenges.findFirst({
      where: and(
        or(
          eq(worldChallenges.player1Id, userId),
          eq(worldChallenges.player2Id, userId)
        ),
        or(
          eq(worldChallenges.status, "matching"),
          eq(worldChallenges.status, "waiting"),
          eq(worldChallenges.status, "researching"),
          eq(worldChallenges.status, "debating")
        )
      ),
      with: {
        player1: true,
        player2: true,
        rounds: {
          orderBy: (rounds, { asc }) => [asc(rounds.roundNumber)],
        },
      },
    });
    return challenge;
  }

  async getWorldChallengeByInviteCode(code: string): Promise<WorldChallengeWithRelations | undefined> {
    const challenge = await db.query.worldChallenges.findFirst({
      where: eq(worldChallenges.inviteCode, code),
      with: {
        player1: true,
        player2: true,
        rounds: {
          orderBy: (rounds, { asc }) => [asc(rounds.roundNumber)],
        },
      },
    });
    return challenge;
  }

  async createPrivateChallenge(userId: string, category: string): Promise<WorldChallengeWithRelations> {
    const existingChallenge = await this.getUserActiveChallenge(userId);
    if (existingChallenge) {
      throw new Error("You already have an active challenge");
    }

    await db.delete(worldChallengeQueue).where(eq(worldChallengeQueue.userId, userId));

    const inviteCode = Math.random().toString(36).substring(2, 10).toUpperCase();

    const topics = [
      `Topic 1 for ${category} - Generated debate topic`,
      `Topic 2 for ${category} - Generated debate topic`,
      `Topic 3 for ${category} - Generated debate topic`,
    ];

    const [challenge] = await db.insert(worldChallenges).values({
      category,
      player1Id: userId,
      status: "waiting",
      inviteCode,
      isPrivate: true,
    }).returning();

    for (let i = 1; i <= 3; i++) {
      await db.insert(worldChallengeRounds).values({
        challengeId: challenge.id,
        roundNumber: i,
        topic: topics[i - 1],
        status: "pending",
      });
    }

    const fullChallenge = await this.getWorldChallenge(challenge.id);
    return fullChallenge!;
  }

  async joinChallengeByInviteCode(userId: string, code: string): Promise<WorldChallengeWithRelations> {
    const existingChallenge = await this.getUserActiveChallenge(userId);
    if (existingChallenge) {
      throw new Error("You already have an active challenge");
    }

    const challenge = await this.getWorldChallengeByInviteCode(code);
    if (!challenge) {
      throw new Error("Challenge not found");
    }

    if (challenge.status !== "waiting") {
      throw new Error("Challenge is no longer available");
    }

    if (challenge.player1Id === userId) {
      throw new Error("You cannot join your own challenge");
    }

    const researchDeadline = new Date(Date.now() + 30 * 60 * 1000);

    const [updated] = await db.update(worldChallenges)
      .set({
        player2Id: userId,
        status: "researching",
        researchDeadline,
        updatedAt: new Date(),
      })
      .where(eq(worldChallenges.id, challenge.id))
      .returning();

    await db.update(worldChallengeRounds)
      .set({ status: "researching" })
      .where(and(
        eq(worldChallengeRounds.challengeId, challenge.id),
        eq(worldChallengeRounds.roundNumber, 1)
      ));

    const fullChallenge = await this.getWorldChallenge(updated.id);
    return fullChallenge!;
  }

  async getPendingChallenges(userId: string): Promise<WorldChallengeWithRelations[]> {
    const challenges = await db.query.worldChallenges.findMany({
      where: and(
        eq(worldChallenges.status, "waiting"),
        eq(worldChallenges.isPrivate, false),
        ne(worldChallenges.player1Id, userId)
      ),
      with: {
        player1: true,
        player2: true,
        rounds: {
          orderBy: (rounds, { asc }) => [asc(rounds.roundNumber)],
        },
      },
      orderBy: (challenges, { desc }) => [desc(challenges.createdAt)],
      limit: 20,
    });
    return challenges;
  }

  async cancelChallenge(challengeId: number, userId: string): Promise<void> {
    const challenge = await this.getWorldChallenge(challengeId);
    if (!challenge) {
      throw new Error("Challenge not found");
    }
    if (challenge.player1Id !== userId) {
      throw new Error("You can only cancel your own challenges");
    }
    if (challenge.status !== "waiting") {
      throw new Error("Can only cancel challenges that are waiting for an opponent");
    }
    
    await db.delete(worldChallengeRounds).where(eq(worldChallengeRounds.challengeId, challengeId));
    await db.delete(worldChallenges).where(eq(worldChallenges.id, challengeId));
  }

  async setPlayerReady(challengeId: number, playerId: string): Promise<WorldChallenge> {
    const challenge = await this.getWorldChallenge(challengeId);
    if (!challenge) throw new Error("Challenge not found");

    const updateData: Partial<WorldChallenge> = {};
    if (challenge.player1Id === playerId) {
      updateData.player1Ready = true;
    } else if (challenge.player2Id === playerId) {
      updateData.player2Ready = true;
    }

    const [updated] = await db.update(worldChallenges)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(worldChallenges.id, challengeId))
      .returning();

    return updated;
  }

  async startChallengeDebate(challengeId: number): Promise<{ challenge: WorldChallenge, debate: Debate }> {
    const challenge = await this.getWorldChallenge(challengeId);
    if (!challenge || !challenge.rounds) throw new Error("Challenge not found");

    const currentRound = challenge.rounds.find(r => r.roundNumber === challenge.currentRound);
    if (!currentRound) throw new Error("Round not found");

    // Create debate for this round
    const debate = await this.createDebate({
      topic: currentRound.topic,
      category: challenge.category,
      creatorId: challenge.player1Id,
      opponentId: challenge.player2Id || "AI_OPPONENT",
      creatorSide: "pro",
      opponentType: challenge.player2IsAI ? "ai" : "friend",
    });

    // Update round with debate ID
    await db.update(worldChallengeRounds)
      .set({ debateId: debate.id, status: "debating" })
      .where(eq(worldChallengeRounds.id, currentRound.id));

    // Update challenge status
    const [updated] = await db.update(worldChallenges)
      .set({ 
        status: "debating", 
        player1Ready: false, 
        player2Ready: false,
        updatedAt: new Date() 
      })
      .where(eq(worldChallenges.id, challengeId))
      .returning();

    return { challenge: updated, debate };
  }

  async updateChallengeRoundWinner(challengeId: number, roundNumber: number, winnerId: string): Promise<WorldChallenge> {
    const challenge = await this.getWorldChallenge(challengeId);
    if (!challenge) throw new Error("Challenge not found");

    // Update round winner
    await db.update(worldChallengeRounds)
      .set({ winnerId, status: "judged" })
      .where(and(
        eq(worldChallengeRounds.challengeId, challengeId),
        eq(worldChallengeRounds.roundNumber, roundNumber)
      ));

    // Update player scores
    const scoreUpdate: Partial<WorldChallenge> = {};
    if (winnerId === challenge.player1Id) {
      scoreUpdate.player1Score = (challenge.player1Score || 0) + 1;
    } else if (winnerId === challenge.player2Id) {
      scoreUpdate.player2Score = (challenge.player2Score || 0) + 1;
    }

    const [updated] = await db.update(worldChallenges)
      .set({ ...scoreUpdate, updatedAt: new Date() })
      .where(eq(worldChallenges.id, challengeId))
      .returning();

    return updated;
  }

  async advanceChallengeRound(challengeId: number): Promise<WorldChallenge> {
    const challenge = await this.getWorldChallenge(challengeId);
    if (!challenge) throw new Error("Challenge not found");

    const newRound = (challenge.currentRound || 1) + 1;

    if (newRound > 3) {
      // Challenge complete - determine winner
      const winnerId = (challenge.player1Score || 0) > (challenge.player2Score || 0) 
        ? challenge.player1Id 
        : (challenge.player2Score || 0) > (challenge.player1Score || 0)
          ? challenge.player2Id
          : null;

      const [updated] = await db.update(worldChallenges)
        .set({ 
          status: "completed", 
          winnerId,
          updatedAt: new Date() 
        })
        .where(eq(worldChallenges.id, challengeId))
        .returning();

      return updated;
    }

    // Set next round to researching
    await db.update(worldChallengeRounds)
      .set({ status: "researching" })
      .where(and(
        eq(worldChallengeRounds.challengeId, challengeId),
        eq(worldChallengeRounds.roundNumber, newRound)
      ));

    // Set new research deadline
    const researchDeadline = new Date(Date.now() + 30 * 60 * 1000);

    const [updated] = await db.update(worldChallenges)
      .set({ 
        currentRound: newRound, 
        status: "researching",
        researchDeadline,
        player1Ready: false,
        player2Ready: false,
        updatedAt: new Date() 
      })
      .where(eq(worldChallenges.id, challengeId))
      .returning();

    return updated;
  }

  async completeChallengeWithAI(challengeId: number): Promise<WorldChallenge> {
    const [updated] = await db.update(worldChallenges)
      .set({ 
        player2IsAI: true,
        player2Ready: true,
        updatedAt: new Date() 
      })
      .where(eq(worldChallenges.id, challengeId))
      .returning();

    return updated;
  }

  async getWorldChallengeRoundByDebateId(debateId: number): Promise<{ round: WorldChallengeRound; challenge: WorldChallenge } | null> {
    const round = await db.query.worldChallengeRounds.findFirst({
      where: eq(worldChallengeRounds.debateId, debateId),
    });

    if (!round) return null;

    const challenge = await this.getWorldChallenge(round.challengeId);
    if (!challenge) return null;

    return { round, challenge };
  }

  async getUserChallengeStats(userId: string): Promise<{
    totalChallenges: number;
    wins: number;
    losses: number;
    winRate: number;
    bestCategory: string | null;
    currentStreak: number;
    badges: {
      categoryMaster: string | null;
      perfectWins: number;
      underdogWins: number;
    };
  }> {
    const completedChallenges = await db.query.worldChallenges.findMany({
      where: and(
        eq(worldChallenges.status, "completed"),
        or(
          eq(worldChallenges.player1Id, userId),
          eq(worldChallenges.player2Id, userId)
        )
      ),
      orderBy: (wc, { desc }) => [desc(wc.id)],
      with: {
        player1: true,
        player2: true,
      },
    });

    const totalChallenges = completedChallenges.length;
    const wins = completedChallenges.filter(c => c.winnerId === userId).length;
    const losses = totalChallenges - wins;
    const winRate = totalChallenges > 0 ? Math.round((wins / totalChallenges) * 100) : 0;

    const categoryWins: Record<string, number> = {};
    for (const c of completedChallenges) {
      if (c.winnerId === userId) {
        categoryWins[c.category] = (categoryWins[c.category] || 0) + 1;
      }
    }
    const bestCategory = Object.entries(categoryWins).sort((a, b) => b[1] - a[1])[0]?.[0] || null;

    let currentStreak = 0;
    for (const c of completedChallenges) {
      if (c.winnerId === userId) {
        currentStreak++;
      } else {
        break;
      }
    }

    // Calculate gamification badges
    // Category Master: 5+ wins in a category
    const categoryMaster = Object.entries(categoryWins).find(([_, count]) => count >= 5)?.[0] || null;

    // Perfect wins: Won 3-0 against opponent
    let perfectWins = 0;
    for (const c of completedChallenges) {
      if (c.winnerId === userId) {
        const isPlayer1 = c.player1Id === userId;
        const myScore = isPlayer1 ? c.player1Score : c.player2Score;
        const opponentScore = isPlayer1 ? c.player2Score : c.player1Score;
        if (myScore === 3 && opponentScore === 0) {
          perfectWins++;
        }
      }
    }

    // Underdog wins: Won against higher ELO opponent
    let underdogWins = 0;
    for (const c of completedChallenges) {
      if (c.winnerId === userId) {
        const isPlayer1 = c.player1Id === userId;
        const myUser = isPlayer1 ? c.player1 : c.player2;
        const opponent = isPlayer1 ? c.player2 : c.player1;
        if (opponent && myUser) {
          const myEloNum = parseInt(myUser.eloRating || "1000");
          const opponentEloNum = parseInt(opponent.eloRating || "1000");
          if (opponentEloNum > myEloNum + 100) {
            underdogWins++;
          }
        }
      }
    }

    return { 
      totalChallenges, wins, losses, winRate, bestCategory, currentStreak,
      badges: {
        categoryMaster,
        perfectWins,
        underdogWins,
      }
    };
  }

  async getUserChallengeHistory(userId: string, limit: number): Promise<WorldChallengeWithRelations[]> {
    const challenges = await db.query.worldChallenges.findMany({
      where: and(
        eq(worldChallenges.status, "completed"),
        or(
          eq(worldChallenges.player1Id, userId),
          eq(worldChallenges.player2Id, userId)
        )
      ),
      orderBy: (wc, { desc }) => [desc(wc.id)],
      limit,
      with: {
        player1: true,
        player2: true,
        rounds: true,
      },
    });

    return challenges;
  }

  async savePushSubscription(userId: string, subscription: { endpoint: string, p256dh: string, auth: string }): Promise<PushSubscription> {
    await db.delete(pushSubscriptions)
      .where(and(
        eq(pushSubscriptions.userId, userId),
        eq(pushSubscriptions.endpoint, subscription.endpoint)
      ));

    const [newSub] = await db.insert(pushSubscriptions)
      .values({
        userId,
        endpoint: subscription.endpoint,
        p256dh: subscription.p256dh,
        auth: subscription.auth,
      })
      .returning();

    return newSub;
  }

  async deletePushSubscription(userId: string, endpoint: string): Promise<void> {
    await db.delete(pushSubscriptions)
      .where(and(
        eq(pushSubscriptions.userId, userId),
        eq(pushSubscriptions.endpoint, endpoint)
      ));
  }

  async getUserPushSubscriptions(userId: string): Promise<PushSubscription[]> {
    return db.query.pushSubscriptions.findMany({
      where: eq(pushSubscriptions.userId, userId),
    });
  }

  // Political Affiliation Methods
  async updatePoliticalAffiliation(userId: string, affiliation: string): Promise<User> {
    const [updated] = await db.update(users)
      .set({
        politicalAffiliation: affiliation,
        politicalAffiliationLastChanged: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async canChangePoliticalAffiliation(userId: string): Promise<{ canChange: boolean, nextChangeDate?: Date }> {
    const user = await this.getUser(userId);
    if (!user) return { canChange: false };
    
    const lastChanged = user.politicalAffiliationLastChanged;
    if (!lastChanged) {
      return { canChange: true };
    }
    
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    if (lastChanged < thirtyDaysAgo) {
      return { canChange: true };
    }
    
    const nextChangeDate = new Date(lastChanged);
    nextChangeDate.setDate(nextChangeDate.getDate() + 30);
    
    return { canChange: false, nextChangeDate };
  }

  // Relationship Request Methods
  async createRelationshipRequest(senderId: string, receiverId: string, requestType: string): Promise<RelationshipRequest> {
    // Delete any existing pending request from this sender to this receiver
    await db.delete(relationshipRequests)
      .where(and(
        eq(relationshipRequests.senderId, senderId),
        eq(relationshipRequests.receiverId, receiverId),
        eq(relationshipRequests.status, "pending")
      ));
    
    const [request] = await db.insert(relationshipRequests)
      .values({ senderId, receiverId, requestType })
      .returning();
    return request;
  }

  async getPendingRequestsForUser(userId: string): Promise<(RelationshipRequest & { sender: User })[]> {
    const requests = await db.query.relationshipRequests.findMany({
      where: and(
        eq(relationshipRequests.receiverId, userId),
        eq(relationshipRequests.status, "pending")
      ),
    });
    
    // Fetch sender info for each request
    const results = await Promise.all(requests.map(async (request) => {
      const sender = await this.getUser(request.senderId);
      return { ...request, sender: sender! };
    }));
    
    return results.filter(r => r.sender);
  }

  async getSentRequests(userId: string): Promise<(RelationshipRequest & { receiver: User })[]> {
    const requests = await db.query.relationshipRequests.findMany({
      where: and(
        eq(relationshipRequests.senderId, userId),
        eq(relationshipRequests.status, "pending")
      ),
    });
    
    // Fetch receiver info for each request
    const results = await Promise.all(requests.map(async (request) => {
      const receiver = await this.getUser(request.receiverId);
      return { ...request, receiver: receiver! };
    }));
    
    return results.filter(r => r.receiver);
  }

  async acceptRelationshipRequest(requestId: string, userId: string): Promise<UserRelationship> {
    const request = await db.query.relationshipRequests.findFirst({
      where: and(
        eq(relationshipRequests.id, requestId),
        eq(relationshipRequests.receiverId, userId),
        eq(relationshipRequests.status, "pending")
      ),
    });
    
    if (!request) {
      throw new Error("Request not found");
    }
    
    // Update request status
    await db.update(relationshipRequests)
      .set({ status: "accepted" })
      .where(eq(relationshipRequests.id, requestId));
    
    // Create mutual relationships - both users become friends/rivals with each other
    const relationType = request.requestType === "rival" ? "enemy" : "friend";
    await this.addRelationship(request.senderId, request.receiverId, relationType);
    const relationship = await this.addRelationship(request.receiverId, request.senderId, relationType);
    
    return relationship;
  }

  async declineRelationshipRequest(requestId: string, userId: string): Promise<void> {
    await db.update(relationshipRequests)
      .set({ status: "declined" })
      .where(and(
        eq(relationshipRequests.id, requestId),
        eq(relationshipRequests.receiverId, userId)
      ));
  }

  async getExistingRequest(senderId: string, receiverId: string): Promise<RelationshipRequest | undefined> {
    return db.query.relationshipRequests.findFirst({
      where: and(
        eq(relationshipRequests.senderId, senderId),
        eq(relationshipRequests.receiverId, receiverId),
        eq(relationshipRequests.status, "pending")
      ),
    });
  }

  async getExistingRequestBothDirections(userId1: string, userId2: string): Promise<{ request: RelationshipRequest, direction: 'sent' | 'received' } | undefined> {
    // Check if userId1 sent a request to userId2
    const sentRequest = await db.query.relationshipRequests.findFirst({
      where: and(
        eq(relationshipRequests.senderId, userId1),
        eq(relationshipRequests.receiverId, userId2),
        eq(relationshipRequests.status, "pending")
      ),
    });
    
    if (sentRequest) {
      return { request: sentRequest, direction: 'sent' };
    }
    
    // Check if userId2 sent a request to userId1
    const receivedRequest = await db.query.relationshipRequests.findFirst({
      where: and(
        eq(relationshipRequests.senderId, userId2),
        eq(relationshipRequests.receiverId, userId1),
        eq(relationshipRequests.status, "pending")
      ),
    });
    
    if (receivedRequest) {
      return { request: receivedRequest, direction: 'received' };
    }
    
    return undefined;
  }

  // AI Opponents
  async getAiOpponents(): Promise<AiOpponent[]> {
    return db.select().from(aiOpponents).orderBy(asc(aiOpponents.eloRating));
  }

  async getAiOpponent(id: number): Promise<AiOpponent | undefined> {
    const [opponent] = await db.select().from(aiOpponents).where(eq(aiOpponents.id, id));
    return opponent;
  }

  async updateAiOpponentStats(id: number, won: boolean): Promise<void> {
    if (won) {
      await db.update(aiOpponents)
        .set({ wins: sql`${aiOpponents.wins} + 1` })
        .where(eq(aiOpponents.id, id));
    } else {
      await db.update(aiOpponents)
        .set({ losses: sql`${aiOpponents.losses} + 1` })
        .where(eq(aiOpponents.id, id));
    }
  }
}

export const storage = new DatabaseStorage();
