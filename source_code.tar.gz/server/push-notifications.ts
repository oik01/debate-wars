import webpush from 'web-push';
import { db } from './db';
import { pushSubscriptions } from '@shared/schema';
import { eq } from 'drizzle-orm';

const vapidPublicKey = process.env.VAPID_PUBLIC_KEY;
const vapidPrivateKey = process.env.VAPID_PRIVATE_KEY;

if (vapidPublicKey && vapidPrivateKey) {
  webpush.setVapidDetails(
    'mailto:notifications@debatewars.app',
    vapidPublicKey,
    vapidPrivateKey
  );
}

export interface NotificationPayload {
  title: string;
  body: string;
  icon?: string;
  url?: string;
  tag?: string;
}

export async function sendPushNotification(
  userId: string,
  payload: NotificationPayload
): Promise<void> {
  if (!vapidPublicKey || !vapidPrivateKey) {
    console.warn('VAPID keys not configured, skipping push notification');
    return;
  }

  const subscriptions = await db.query.pushSubscriptions.findMany({
    where: eq(pushSubscriptions.userId, userId),
  });

  if (subscriptions.length === 0) {
    return;
  }

  const notificationPayload = JSON.stringify({
    title: payload.title,
    body: payload.body,
    icon: payload.icon || '/icon-192.png',
    url: payload.url || '/',
    tag: payload.tag,
  });

  const sendPromises = subscriptions.map(async (sub) => {
    try {
      await webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: {
            p256dh: sub.p256dh,
            auth: sub.auth,
          },
        },
        notificationPayload
      );
    } catch (error: any) {
      if (error.statusCode === 410 || error.statusCode === 404) {
        await db.delete(pushSubscriptions).where(eq(pushSubscriptions.id, sub.id));
      }
      console.error(`Push notification failed for subscription ${sub.id}:`, error.message);
    }
  });

  await Promise.all(sendPromises);
}

export async function notifyTurnReady(userId: string, debateTopic: string, debateId: number) {
  await sendPushNotification(userId, {
    title: "Your Turn to Debate!",
    body: `It's your turn in the debate: "${debateTopic}"`,
    url: `/debate/${debateId}`,
    tag: `debate-turn-${debateId}`,
  });
}

export async function notifyChallengeAccepted(userId: string, opponentName: string, challengeId: number) {
  await sendPushNotification(userId, {
    title: "Challenge Accepted!",
    body: `${opponentName} has accepted your World Challenge!`,
    url: `/world-challenge`,
    tag: `challenge-accepted-${challengeId}`,
  });
}

export async function notifyDebateJoined(userId: string, opponentName: string, debateId: number, debateTopic: string) {
  await sendPushNotification(userId, {
    title: "Someone Joined Your Debate!",
    body: `${opponentName} has joined: "${debateTopic}"`,
    url: `/debate/${debateId}`,
    tag: `debate-joined-${debateId}`,
  });
}

export async function notifyJudgmentReady(userId: string, debateTopic: string, debateId: number, won: boolean) {
  await sendPushNotification(userId, {
    title: won ? "Victory! You Won!" : "Debate Judged",
    body: won ? `Congratulations! You won the debate: "${debateTopic}"` : `The debate "${debateTopic}" has been judged`,
    url: `/debate/${debateId}`,
    tag: `judgment-${debateId}`,
  });
}

export async function notifyWorldChallengeRoundComplete(
  userId: string, 
  roundNumber: number, 
  challengeId: number,
  won: boolean
) {
  await sendPushNotification(userId, {
    title: won ? `Round ${roundNumber} Victory!` : `Round ${roundNumber} Complete`,
    body: won ? `You won round ${roundNumber}!` : `Round ${roundNumber} has been judged`,
    url: `/world-challenge`,
    tag: `world-round-${challengeId}-${roundNumber}`,
  });
}

export async function notifyWorldChallengeComplete(
  userId: string,
  challengeId: number,
  won: boolean,
  score: string
) {
  await sendPushNotification(userId, {
    title: won ? "World Challenge Victory!" : "World Challenge Complete",
    body: won ? `Congratulations! You won the challenge ${score}!` : `Challenge complete. Final score: ${score}`,
    url: `/world-challenge`,
    tag: `world-complete-${challengeId}`,
  });
}
