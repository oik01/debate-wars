import { pool } from "./db";

export async function ensureSchema(): Promise<void> {
  console.log("[SCHEMA] Checking and creating database tables if needed...");
  
  const client = await pool.connect();
  try {
    // First, create all tables if they don't exist
    // Column names MUST match Drizzle ORM schema definitions exactly!
    await client.query(`
      -- Users table (from auth) - matches shared/models/auth.ts
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT,
        first_name TEXT,
        last_name TEXT,
        profile_image_url TEXT,
        elo_rating TEXT DEFAULT '1000',
        wins TEXT DEFAULT '0',
        losses TEXT DEFAULT '0',
        nationality TEXT,
        political_affiliation TEXT,
        political_affiliation_last_changed TIMESTAMP,
        avatar_type TEXT DEFAULT 'default',
        custom_avatar_url TEXT,
        onboarding_completed TEXT DEFAULT 'false',
        favorite_categories TEXT,
        avg_logic_score TEXT DEFAULT '0',
        avg_evidence_score TEXT DEFAULT '0',
        avg_persuasion_score TEXT DEFAULT '0',
        avg_rebuttals_score TEXT DEFAULT '0',
        total_debates_graded TEXT DEFAULT '0',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Sessions table (for auth)
      CREATE TABLE IF NOT EXISTS sessions (
        sid VARCHAR NOT NULL COLLATE "default",
        sess JSONB NOT NULL,
        expire TIMESTAMP(6) NOT NULL,
        PRIMARY KEY (sid)
      );
      CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON sessions (expire);

      -- AI Opponents table - matches shared/schema.ts
      CREATE TABLE IF NOT EXISTS ai_opponents (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        avatar_id TEXT NOT NULL,
        bg_color TEXT NOT NULL,
        difficulty TEXT NOT NULL,
        elo_rating INTEGER NOT NULL DEFAULT 1000,
        personality TEXT NOT NULL,
        special_trait TEXT,
        logic_skill INTEGER DEFAULT 2,
        evidence_skill INTEGER DEFAULT 2,
        persuasion_skill INTEGER DEFAULT 2,
        rebuttals_skill INTEGER DEFAULT 2,
        wins INTEGER DEFAULT 0,
        losses INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Debates table - matches shared/schema.ts
      CREATE TABLE IF NOT EXISTS debates (
        id SERIAL PRIMARY KEY,
        topic TEXT NOT NULL,
        category TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'waiting',
        creator_id TEXT NOT NULL,
        opponent_id TEXT,
        winner_id TEXT,
        creator_side TEXT NOT NULL DEFAULT 'pro',
        opponent_type TEXT NOT NULL DEFAULT 'open',
        target_user_id TEXT,
        ai_opponent_id INTEGER,
        current_round INTEGER NOT NULL DEFAULT 1,
        invite_code TEXT,
        creator_affiliation TEXT,
        required_affiliation TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Turns table - matches shared/schema.ts
      CREATE TABLE IF NOT EXISTS turns (
        id SERIAL PRIMARY KEY,
        debate_id INTEGER NOT NULL,
        user_id TEXT NOT NULL,
        transcript TEXT NOT NULL,
        side TEXT NOT NULL,
        round_number INTEGER NOT NULL DEFAULT 1,
        audio_url TEXT,
        is_ai BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Judgments table - matches shared/schema.ts
      CREATE TABLE IF NOT EXISTS judgments (
        id SERIAL PRIMARY KEY,
        debate_id INTEGER NOT NULL,
        winner_id TEXT,
        explanation TEXT NOT NULL,
        creator_logic_grade TEXT,
        creator_evidence_grade TEXT,
        creator_persuasion_grade TEXT,
        creator_rebuttals_grade TEXT,
        creator_overall_grade TEXT,
        creator_logic_explanation TEXT,
        creator_evidence_explanation TEXT,
        creator_persuasion_explanation TEXT,
        creator_rebuttals_explanation TEXT,
        creator_overall_explanation TEXT,
        opponent_logic_grade TEXT,
        opponent_evidence_grade TEXT,
        opponent_persuasion_grade TEXT,
        opponent_rebuttals_grade TEXT,
        opponent_overall_grade TEXT,
        opponent_logic_explanation TEXT,
        opponent_evidence_explanation TEXT,
        opponent_persuasion_explanation TEXT,
        opponent_rebuttals_explanation TEXT,
        opponent_overall_explanation TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- User relationships table - matches shared/models/auth.ts
      -- Column names: user_id, target_user_id, relationship_type
      CREATE TABLE IF NOT EXISTS user_relationships (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
        user_id TEXT NOT NULL,
        target_user_id TEXT NOT NULL,
        relationship_type TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Invite links table - matches shared/models/auth.ts
      -- Column names: code, creator_id, target_user_id, debate_id, invite_type, used, expires_at
      CREATE TABLE IF NOT EXISTS invite_links (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
        code TEXT NOT NULL UNIQUE,
        creator_id TEXT NOT NULL,
        target_user_id TEXT,
        debate_id TEXT,
        invite_type TEXT NOT NULL,
        used TEXT DEFAULT 'false',
        expires_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Push subscriptions table - matches shared/schema.ts
      CREATE TABLE IF NOT EXISTS push_subscriptions (
        id SERIAL PRIMARY KEY,
        user_id TEXT NOT NULL,
        endpoint TEXT NOT NULL,
        p256dh TEXT NOT NULL,
        auth TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Relationship requests table - matches shared/models/auth.ts
      -- Column names: sender_id, receiver_id, request_type, status
      CREATE TABLE IF NOT EXISTS relationship_requests (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
        sender_id TEXT NOT NULL,
        receiver_id TEXT NOT NULL,
        request_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- World challenge queue table - matches shared/schema.ts
      CREATE TABLE IF NOT EXISTS world_challenge_queue (
        id SERIAL PRIMARY KEY,
        user_id TEXT NOT NULL,
        category TEXT NOT NULL,
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- World challenges table - matches shared/schema.ts
      CREATE TABLE IF NOT EXISTS world_challenges (
        id SERIAL PRIMARY KEY,
        category TEXT NOT NULL,
        player1_id TEXT NOT NULL,
        player2_id TEXT,
        status TEXT NOT NULL DEFAULT 'matching',
        current_round INTEGER NOT NULL DEFAULT 1,
        player1_score INTEGER DEFAULT 0,
        player2_score INTEGER DEFAULT 0,
        winner_id TEXT,
        research_deadline TIMESTAMP,
        player1_ready BOOLEAN DEFAULT FALSE,
        player2_ready BOOLEAN DEFAULT FALSE,
        player2_is_ai BOOLEAN DEFAULT FALSE,
        invite_code TEXT,
        is_private BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- World challenge rounds table - matches shared/schema.ts
      CREATE TABLE IF NOT EXISTS world_challenge_rounds (
        id SERIAL PRIMARY KEY,
        challenge_id INTEGER NOT NULL,
        round_number INTEGER NOT NULL,
        topic TEXT NOT NULL,
        debate_id INTEGER,
        winner_id TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Conversations table (for chat)
      CREATE TABLE IF NOT EXISTS conversations (
        id SERIAL PRIMARY KEY,
        user_id TEXT NOT NULL,
        title TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Messages table (for chat)
      CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        conversation_id INTEGER NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    
    console.log("[SCHEMA] Base tables created/verified");
    
    // Now add any missing columns to existing tables
    // This handles schema migrations for production where tables already exist with old column names
    console.log("[SCHEMA] Adding any missing columns to existing tables...");
    
    // Users table - add missing columns
    const userColumns = [
      { name: 'elo_rating', type: "TEXT DEFAULT '1000'" },
      { name: 'wins', type: "TEXT DEFAULT '0'" },
      { name: 'losses', type: "TEXT DEFAULT '0'" },
      { name: 'nationality', type: 'TEXT' },
      { name: 'political_affiliation', type: 'TEXT' },
      { name: 'political_affiliation_last_changed', type: 'TIMESTAMP' },
      { name: 'avatar_type', type: "TEXT DEFAULT 'default'" },
      { name: 'custom_avatar_url', type: 'TEXT' },
      { name: 'onboarding_completed', type: "TEXT DEFAULT 'false'" },
      { name: 'favorite_categories', type: 'TEXT' },
      { name: 'avg_logic_score', type: "TEXT DEFAULT '0'" },
      { name: 'avg_evidence_score', type: "TEXT DEFAULT '0'" },
      { name: 'avg_persuasion_score', type: "TEXT DEFAULT '0'" },
      { name: 'avg_rebuttals_score', type: "TEXT DEFAULT '0'" },
      { name: 'total_debates_graded', type: "TEXT DEFAULT '0'" },
      { name: 'updated_at', type: 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP' },
    ];
    
    for (const col of userColumns) {
      try {
        await client.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS ${col.name} ${col.type}`);
      } catch (e: any) {
        if (!e.message?.includes('already exists')) {
          console.log(`[SCHEMA] Note: users.${col.name} - ${e.message}`);
        }
      }
    }
    
    // AI Opponents table - add missing columns
    const aiOpponentColumns = [
      { name: 'wins', type: 'INTEGER DEFAULT 0' },
      { name: 'losses', type: 'INTEGER DEFAULT 0' },
      { name: 'logic_skill', type: 'INTEGER DEFAULT 2' },
      { name: 'evidence_skill', type: 'INTEGER DEFAULT 2' },
      { name: 'persuasion_skill', type: 'INTEGER DEFAULT 2' },
      { name: 'rebuttals_skill', type: 'INTEGER DEFAULT 2' },
      { name: 'special_trait', type: 'TEXT' },
    ];
    
    for (const col of aiOpponentColumns) {
      try {
        await client.query(`ALTER TABLE ai_opponents ADD COLUMN IF NOT EXISTS ${col.name} ${col.type}`);
      } catch (e: any) {
        if (!e.message?.includes('already exists')) {
          console.log(`[SCHEMA] Note: ai_opponents.${col.name} - ${e.message}`);
        }
      }
    }
    
    // User relationships table - add missing columns (for renamed columns)
    try {
      await client.query(`ALTER TABLE user_relationships ADD COLUMN IF NOT EXISTS target_user_id TEXT`);
    } catch (e: any) {
      console.log(`[SCHEMA] Note: user_relationships.target_user_id - ${e.message}`);
    }
    
    // Relationship requests table - add missing columns (for renamed columns)
    const relationshipRequestColumns = [
      { name: 'sender_id', type: 'TEXT' },
      { name: 'receiver_id', type: 'TEXT' },
      { name: 'request_type', type: 'TEXT' },
    ];
    
    for (const col of relationshipRequestColumns) {
      try {
        await client.query(`ALTER TABLE relationship_requests ADD COLUMN IF NOT EXISTS ${col.name} ${col.type}`);
      } catch (e: any) {
        if (!e.message?.includes('already exists')) {
          console.log(`[SCHEMA] Note: relationship_requests.${col.name} - ${e.message}`);
        }
      }
    }
    
    // Invite links table - add missing columns
    const inviteLinkColumns = [
      { name: 'creator_id', type: 'TEXT' },
      { name: 'target_user_id', type: 'TEXT' },
      { name: 'debate_id', type: 'TEXT' },
      { name: 'invite_type', type: 'TEXT' },
      { name: 'used', type: "TEXT DEFAULT 'false'" },
      { name: 'expires_at', type: 'TIMESTAMP' },
    ];
    
    for (const col of inviteLinkColumns) {
      try {
        await client.query(`ALTER TABLE invite_links ADD COLUMN IF NOT EXISTS ${col.name} ${col.type}`);
      } catch (e: any) {
        if (!e.message?.includes('already exists')) {
          console.log(`[SCHEMA] Note: invite_links.${col.name} - ${e.message}`);
        }
      }
    }
    
    // World challenges table - add missing columns
    const worldChallengeColumns = [
      { name: 'category', type: 'TEXT' },
      { name: 'research_deadline', type: 'TIMESTAMP' },
      { name: 'player1_ready', type: 'BOOLEAN DEFAULT FALSE' },
      { name: 'player2_ready', type: 'BOOLEAN DEFAULT FALSE' },
      { name: 'player2_is_ai', type: 'BOOLEAN DEFAULT FALSE' },
      { name: 'invite_code', type: 'TEXT' },
      { name: 'is_private', type: 'BOOLEAN DEFAULT FALSE' },
      { name: 'updated_at', type: 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP' },
    ];
    
    for (const col of worldChallengeColumns) {
      try {
        await client.query(`ALTER TABLE world_challenges ADD COLUMN IF NOT EXISTS ${col.name} ${col.type}`);
      } catch (e: any) {
        if (!e.message?.includes('already exists')) {
          console.log(`[SCHEMA] Note: world_challenges.${col.name} - ${e.message}`);
        }
      }
    }
    
    console.log("[SCHEMA] Missing columns added successfully");
    console.log("[SCHEMA] Database schema verification complete");
    
  } catch (error: any) {
    console.error("[SCHEMA] Error ensuring schema:", error?.message || error);
    throw error;
  } finally {
    client.release();
  }
}
