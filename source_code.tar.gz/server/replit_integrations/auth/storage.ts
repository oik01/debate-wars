import { users, type User, type UpsertUser } from "@shared/models/auth";
import { db } from "../../db";
import { eq, sql } from "drizzle-orm";

// Interface for auth storage operations
// (IMPORTANT) These user operations are mandatory for Replit Auth.
export interface IAuthStorage {
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
}

// Helper to map snake_case database row to camelCase User type
// This avoids referencing columns that may not exist in production
function mapRowToUser(row: any): User {
  return {
    id: row.id,
    email: row.email,
    firstName: row.first_name,
    lastName: row.last_name,
    profileImageUrl: row.profile_image_url,
    eloRating: row.elo_rating || "1000",
    wins: row.wins || "0",
    losses: row.losses || "0",
    nationality: row.nationality || null,
    politicalAffiliation: row.political_affiliation || null,
    politicalAffiliationLastChanged: row.political_affiliation_last_changed || null,
    favoriteCategories: row.favorite_categories || null,
    avatarType: row.avatar_type || "default",
    customAvatarUrl: row.custom_avatar_url || null,
    onboardingCompleted: row.onboarding_completed || "false",
    avgLogicScore: row.avg_logic_score || "0",
    avgEvidenceScore: row.avg_evidence_score || "0",
    avgPersuasionScore: row.avg_persuasion_score || "0",
    avgRebuttalsScore: row.avg_rebuttals_score || "0",
    totalDebatesGraded: row.total_debates_graded || "0",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

class AuthStorage implements IAuthStorage {
  async getUser(id: string): Promise<User | undefined> {
    // Use SELECT * to avoid referencing specific columns that may not exist 
    // in production database. mapRowToUser handles missing columns gracefully.
    const result = await db.execute(sql`
      SELECT * FROM users WHERE id = ${id}
    `);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return mapRowToUser(result.rows[0]);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // ID is required for auth - if missing, something is very wrong
    if (!userData.id) {
      throw new Error('[AUTH] Cannot create user without id');
    }
    const userId = userData.id;

    try {
      // Try full upsert with all common columns
      const result = await db.execute(sql`
        INSERT INTO users (id, email, first_name, last_name, profile_image_url, created_at, updated_at)
        VALUES (
          ${userData.id},
          ${userData.email || null},
          ${userData.firstName || null},
          ${userData.lastName || null},
          ${userData.profileImageUrl || null},
          NOW(),
          NOW()
        )
        ON CONFLICT (id) DO UPDATE SET
          first_name = COALESCE(${userData.firstName || null}, users.first_name),
          last_name = COALESCE(${userData.lastName || null}, users.last_name),
          profile_image_url = COALESCE(${userData.profileImageUrl || null}, users.profile_image_url),
          updated_at = NOW()
        RETURNING *
      `);
      
      console.log(`[AUTH] User upserted successfully: ${userData.id}`);
      return mapRowToUser(result.rows[0]);
    } catch (error: any) {
      console.error(`[AUTH] Primary upsert failed for ${userData.id}:`, error?.message);
      
      // Handle duplicate email conflict
      if (error.code === '23505' && error.constraint?.includes('email')) {
        console.log(`[AUTH] Email conflict for user ${userData.id}, attempting insert without email`);
        try {
          const result = await db.execute(sql`
            INSERT INTO users (id, first_name, last_name, profile_image_url, created_at, updated_at)
            VALUES (
              ${userData.id},
              ${userData.firstName || null},
              ${userData.lastName || null},
              ${userData.profileImageUrl || null},
              NOW(),
              NOW()
            )
            ON CONFLICT (id) DO UPDATE SET
              first_name = COALESCE(${userData.firstName || null}, users.first_name),
              last_name = COALESCE(${userData.lastName || null}, users.last_name),
              profile_image_url = COALESCE(${userData.profileImageUrl || null}, users.profile_image_url),
              updated_at = NOW()
            RETURNING *
          `);
          
          console.log(`[AUTH] User upserted without email: ${userData.id}`);
          return mapRowToUser(result.rows[0]);
        } catch (emailError: any) {
          console.error(`[AUTH] Email-less upsert failed:`, emailError?.message);
        }
      }

      // Last resort: try minimal insert with just id
      try {
        console.log(`[AUTH] Attempting minimal insert for ${userData.id}`);
        const result = await db.execute(sql`
          INSERT INTO users (id, created_at, updated_at)
          VALUES (${userData.id}, NOW(), NOW())
          ON CONFLICT (id) DO UPDATE SET updated_at = NOW()
          RETURNING *
        `);
        
        console.log(`[AUTH] Minimal user created: ${userData.id}`);
        return mapRowToUser(result.rows[0]);
      } catch (minimalError: any) {
        console.error(`[AUTH] Minimal insert also failed:`, minimalError?.message);
      }

      // If all database operations fail, throw error
      // The caller (auth routes) will handle creating a fallback response
      console.error(`[AUTH] All database operations failed for user ${userId}`);
      throw new Error(`Failed to create user ${userId} in database`);
    }
  }
}

export const authStorage = new AuthStorage();
