import type { Express } from "express";
import { authStorage } from "./storage";
import { isAuthenticated } from "./replitAuth";
import type { User } from "@shared/models/auth";

// Helper to create a user object from session claims (used when DB is unavailable)
function createUserFromClaims(claims: any): User {
  return {
    id: claims.sub,
    email: claims.email || null,
    firstName: claims.first_name || null,
    lastName: claims.last_name || null,
    profileImageUrl: claims.profile_image_url || null,
    eloRating: "1000",
    wins: "0",
    losses: "0",
    nationality: null,
    politicalAffiliation: null,
    politicalAffiliationLastChanged: null,
    favoriteCategories: null,
    avatarType: "default",
    customAvatarUrl: null,
    onboardingCompleted: "false",
    avgLogicScore: "0",
    avgEvidenceScore: "0",
    avgPersuasionScore: "0",
    avgRebuttalsScore: "0",
    totalDebatesGraded: "0",
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

// Register auth-specific routes
export function registerAuthRoutes(app: Express): void {
  // Get current authenticated user
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    const claims = req.user?.claims;
    const userId = claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ message: "Invalid session - no user ID" });
    }

    try {
      // First try to get existing user from DB
      let user = await authStorage.getUser(userId);
      
      // If user doesn't exist in DB, create them now
      if (!user) {
        console.log(`[AUTH] User ${userId} not found in DB, creating from session claims`);
        try {
          user = await authStorage.upsertUser({
            id: userId,
            email: claims.email,
            firstName: claims.first_name,
            lastName: claims.last_name,
            profileImageUrl: claims.profile_image_url,
          });
        } catch (upsertError) {
          console.error(`[AUTH] Failed to create user ${userId}:`, upsertError);
          // If DB completely fails, return session-based user
          console.log(`[AUTH] Returning session-based fallback user for ${userId}`);
          return res.json(createUserFromClaims(claims));
        }
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      
      // On any error, return session-based user data so auth doesn't loop
      console.log(`[AUTH] Error recovery - returning session-based user for ${userId}`);
      return res.json(createUserFromClaims(claims));
    }
  });
}
