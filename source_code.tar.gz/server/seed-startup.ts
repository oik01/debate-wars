import { db } from "./db";
import { aiOpponents, users, debates } from "@shared/schema";
import { sql } from "drizzle-orm";

const AI_OPPONENTS = [
  { name: "Benny Bumbles", avatarId: "cartoon7", bgColor: "#DB2777", difficulty: "beginner", eloRating: 650, personality: "A nervous newcomer who often forgets his points mid-sentence. Uses simple arguments and frequently says 'um' and 'well, you see...'", specialTrait: null, logicSkill: 1, evidenceSkill: 1, persuasionSkill: 1, rebuttalsSkill: 0 },
  { name: "Clueless Carl", avatarId: "cartoon5", bgColor: "#65A30D", difficulty: "beginner", eloRating: 700, personality: "A friendly but easily confused debater who often agrees with his opponent by accident. Tends to go off-topic.", specialTrait: "accidentally_agrees", logicSkill: 1, evidenceSkill: 0, persuasionSkill: 2, rebuttalsSkill: 0 },
  { name: "Sleepy Sally", avatarId: "cartoon2", bgColor: "#7C3AED", difficulty: "beginner", eloRating: 620, personality: "An owl who stays up too late and makes drowsy, meandering arguments. Sometimes trails off mid-thought...", specialTrait: null, logicSkill: 1, evidenceSkill: 1, persuasionSkill: 0, rebuttalsSkill: 1 },
  { name: "Timid Tim", avatarId: "cartoon4", bgColor: "#F97316", difficulty: "beginner", eloRating: 680, personality: "A shy debater who hedges all his positions with phrases like 'maybe' and 'I could be wrong but...'", specialTrait: null, logicSkill: 2, evidenceSkill: 1, persuasionSkill: 0, rebuttalsSkill: 1 },
  { name: "Rambling Rita", avatarId: "cartoon1", bgColor: "#EC4899", difficulty: "beginner", eloRating: 750, personality: "A chatty cat who makes some good points but buries them in endless tangents about unrelated topics.", specialTrait: "rambles", logicSkill: 2, evidenceSkill: 1, persuasionSkill: 1, rebuttalsSkill: 0 },
  { name: "Methodical Mike", avatarId: "cartoon6", bgColor: "#0891B2", difficulty: "intermediate", eloRating: 950, personality: "A structured thinker who presents arguments in numbered lists. Solid but predictable.", specialTrait: null, logicSkill: 3, evidenceSkill: 2, persuasionSkill: 2, rebuttalsSkill: 2 },
  { name: "Passionate Petra", avatarId: "cartoon3", bgColor: "#DC2626", difficulty: "intermediate", eloRating: 1000, personality: "An emotional debater who argues with heart and fire. Strong rhetoric but sometimes lets passion override logic.", specialTrait: null, logicSkill: 2, evidenceSkill: 2, persuasionSkill: 3, rebuttalsSkill: 2 },
  { name: "Stats Steve", avatarId: "cartoon2", bgColor: "#4F46E5", difficulty: "intermediate", eloRating: 1050, personality: "A data-driven debater who loves citing statistics. Strong on evidence but can be dry and miss emotional appeals.", specialTrait: null, logicSkill: 2, evidenceSkill: 4, persuasionSkill: 1, rebuttalsSkill: 2 },
  { name: "Devil's Advocate Dana", avatarId: "cartoon8", bgColor: "#4338CA", difficulty: "intermediate", eloRating: 1020, personality: "Loves to play devil's advocate and will argue any position with equal vigor. Challenges assumptions relentlessly.", specialTrait: null, logicSkill: 3, evidenceSkill: 2, persuasionSkill: 2, rebuttalsSkill: 3 },
  { name: "Balanced Bob", avatarId: "cartoon5", bgColor: "#059669", difficulty: "intermediate", eloRating: 980, personality: "A fair-minded debater who acknowledges opposing viewpoints before making his case. Well-rounded but not exceptional.", specialTrait: null, logicSkill: 2, evidenceSkill: 2, persuasionSkill: 3, rebuttalsSkill: 2 },
  { name: "Professor Pragma", avatarId: "cartoon2", bgColor: "#1E40AF", difficulty: "expert", eloRating: 1300, personality: "A highly logical academic who constructs airtight arguments with academic precision. Speaks in well-structured paragraphs.", specialTrait: null, logicSkill: 4, evidenceSkill: 3, persuasionSkill: 2, rebuttalsSkill: 3 },
  { name: "Walid Jumblatt", avatarId: "cartoon4", bgColor: "#B45309", difficulty: "expert", eloRating: 1250, personality: "A Lebanese political veteran known for dramatic position changes. Master of rhetoric who might argue one thing then completely reverse course.", specialTrait: "flip_flops_positions", logicSkill: 3, evidenceSkill: 2, persuasionSkill: 4, rebuttalsSkill: 2 },
  { name: "Lawyer Linda", avatarId: "cartoon1", bgColor: "#7C3AED", difficulty: "expert", eloRating: 1350, personality: "A sharp legal mind who picks apart arguments with surgical precision. Excellent at finding loopholes and weak points.", specialTrait: null, logicSkill: 3, evidenceSkill: 3, persuasionSkill: 3, rebuttalsSkill: 4 },
  { name: "Philosopher Phil", avatarId: "cartoon6", bgColor: "#6366F1", difficulty: "expert", eloRating: 1280, personality: "Argues from first principles and loves exploring the deeper implications of any topic. Can be abstract but profound.", specialTrait: null, logicSkill: 4, evidenceSkill: 2, persuasionSkill: 3, rebuttalsSkill: 3 },
  { name: "Rhetorical Rachel", avatarId: "cartoon3", bgColor: "#B91C1C", difficulty: "expert", eloRating: 1320, personality: "A master of persuasive techniques who uses powerful metaphors and emotional appeals. Knows how to move an audience.", specialTrait: null, logicSkill: 2, evidenceSkill: 3, persuasionSkill: 4, rebuttalsSkill: 3 },
  { name: "The Oracle", avatarId: "cartoon2", bgColor: "#0F172A", difficulty: "master", eloRating: 1650, personality: "An all-knowing presence who anticipates every argument and counterargument. Speaks with absolute confidence and devastating precision.", specialTrait: null, logicSkill: 4, evidenceSkill: 4, persuasionSkill: 4, rebuttalsSkill: 4 },
  { name: "Grandmaster Grey", avatarId: "cartoon8", bgColor: "#1F2937", difficulty: "master", eloRating: 1580, personality: "A seasoned veteran who has seen every argument before. Combines centuries of wisdom with razor-sharp wit.", specialTrait: null, logicSkill: 4, evidenceSkill: 3, persuasionSkill: 4, rebuttalsSkill: 4 },
  { name: "Iron Chancellor", avatarId: "cartoon6", bgColor: "#18181B", difficulty: "master", eloRating: 1620, personality: "An unshakeable force of pure logic who never shows emotion. Arguments are delivered like decrees, irrefutable and final.", specialTrait: null, logicSkill: 4, evidenceSkill: 4, persuasionSkill: 3, rebuttalsSkill: 4 },
  { name: "Silver Tongue", avatarId: "cartoon4", bgColor: "#374151", difficulty: "master", eloRating: 1550, personality: "The ultimate persuader who can make any position sound reasonable. Combines charm with impeccable logic.", specialTrait: null, logicSkill: 3, evidenceSkill: 4, persuasionSkill: 4, rebuttalsSkill: 4 },
  { name: "The Arbiter", avatarId: "cartoon3", bgColor: "#7E22CE", difficulty: "master", eloRating: 1700, personality: "The apex debater who embodies the spirit of debate itself. Perfectly balanced across all skills. Nearly impossible to defeat.", specialTrait: null, logicSkill: 4, evidenceSkill: 4, persuasionSkill: 4, rebuttalsSkill: 4 },
];

const SEED_USERS = [
  { id: "53696610", email: "omarkreidieh@gmail.com", firstName: null, lastName: null, eloRating: "1016", wins: "2", losses: "1", nationality: "US", politicalAffiliation: "independent", avatarType: "custom", customAvatarUrl: "/objects/uploads/043eec80-75d0-436d-9658-be2e7107e72c", onboardingCompleted: "true", favoriteCategories: "Artificial Intelligence Ethics", avgLogicScore: "3.00", avgEvidenceScore: "2.33", avgPersuasionScore: "3.00", avgRebuttalsScore: "3.67", totalDebatesGraded: "3" },
  { id: "53722878", email: "atallahjacqueline@gmail.com", firstName: null, lastName: null, eloRating: "1016", wins: "1", losses: "0", nationality: "US", politicalAffiliation: "independent", avatarType: "default", customAvatarUrl: "", onboardingCompleted: "true", favoriteCategories: "Media Objectivity and Bias", avgLogicScore: "0", avgEvidenceScore: "0", avgPersuasionScore: "0", avgRebuttalsScore: "0", totalDebatesGraded: "0" },
  { id: "53725875", email: "shireenkreidieh@gmail.com", firstName: "Sh", lastName: "Sa", eloRating: "968", wins: "0", losses: "2", nationality: "EG", politicalAffiliation: "independent", avatarType: "default", customAvatarUrl: "", onboardingCompleted: "true", favoriteCategories: null, avgLogicScore: "0", avgEvidenceScore: "0", avgPersuasionScore: "0", avgRebuttalsScore: "0", totalDebatesGraded: "0" },
];

const SEED_DEBATES = [
  { topic: "Governments should immediately impose a moratorium on the development of AI systems more powerful than GPT-4 until verifiable safety mechanisms are proven vs. such a moratorium would grant a critical advantage to adversarial nations and slow beneficial progress.", category: "Artificial Intelligence Ethics", status: "waiting", creatorId: "53696610", creatorSide: "pro", opponentType: "open", inviteCode: "AISAFETY1" },
  { topic: "The widespread deployment of advanced generative AI models capable of hyper-realistic image and video creation should be immediately restricted to prevent election interference vs. is a fundamental advancement in creative expression and free speech.", category: "Technology & Society", status: "waiting", creatorId: "53696610", creatorSide: "pro", opponentType: "friend", inviteCode: "GENAI2024" },
  { topic: "Government mandates for covering GLP-1 weight loss drugs like Ozempic, despite their high cost, are essential for public health vs. an unsustainable burden on healthcare systems.", category: "Healthcare System Reform", status: "waiting", creatorId: "53696610", creatorSide: "pro", opponentType: "friend", inviteCode: "OZEMPIC1" },
];

async function seedAiOpponents(): Promise<number> {
  let existing: any[] = [];
  try {
    existing = await db.select().from(aiOpponents);
  } catch (e: any) {
    console.log(`[SEED] Could not query AI opponents: ${e.message}`);
  }
  
  if (existing.length >= 20) {
    console.log(`[SEED] AI opponents already seeded (${existing.length} found)`);
    return existing.length;
  }
  
  console.log(`[SEED] Seeding AI opponents... (found ${existing.length}, need 20)`);
  let seeded = 0;
  for (const opponent of AI_OPPONENTS) {
    try {
      // Check if this specific opponent exists by name
      const existingOpponent = await db.execute(sql`SELECT id FROM ai_opponents WHERE name = ${opponent.name}`);
      if (existingOpponent.rows.length > 0) {
        continue;
      }
      await db.insert(aiOpponents).values(opponent);
      seeded++;
      console.log(`[SEED] Added AI opponent: ${opponent.name}`);
    } catch (e: any) {
      console.error(`[SEED] Error adding ${opponent.name}: ${e.message}`);
    }
  }
  console.log(`[SEED] Seeded ${seeded} new AI opponents (${existing.length + seeded} total)`);
  return existing.length + seeded;
}

async function seedUsers(): Promise<void> {
  console.log("[SEED] Checking users...");
  
  for (const user of SEED_USERS) {
    const result = await db.execute(sql`SELECT id FROM users WHERE id = ${user.id}`);
    if (result.rows.length > 0) {
      console.log(`[SEED] User ${user.email} already exists`);
      continue;
    }
    
    try {
      await db.execute(sql`
        INSERT INTO users (
          id, email, first_name, last_name, elo_rating, wins, losses,
          nationality, political_affiliation, avatar_type, custom_avatar_url,
          onboarding_completed, favorite_categories, avg_logic_score, avg_evidence_score,
          avg_persuasion_score, avg_rebuttals_score, total_debates_graded
        ) VALUES (
          ${user.id}, ${user.email}, ${user.firstName}, ${user.lastName},
          ${user.eloRating}, ${user.wins}, ${user.losses}, ${user.nationality},
          ${user.politicalAffiliation}, ${user.avatarType}, ${user.customAvatarUrl},
          ${user.onboardingCompleted}, ${user.favoriteCategories}, ${user.avgLogicScore},
          ${user.avgEvidenceScore}, ${user.avgPersuasionScore}, ${user.avgRebuttalsScore},
          ${user.totalDebatesGraded}
        )
        ON CONFLICT (id) DO NOTHING
      `);
      console.log(`[SEED] Added user: ${user.email}`);
    } catch (e: any) {
      console.log(`[SEED] User ${user.email} already exists or error: ${e.message}`);
    }
  }
}

async function seedDebates(): Promise<void> {
  console.log("[SEED] Checking debates...");
  
  for (const debate of SEED_DEBATES) {
    const result = await db.execute(sql`SELECT id FROM debates WHERE invite_code = ${debate.inviteCode}`);
    if (result.rows.length > 0) {
      console.log(`[SEED] Debate with code ${debate.inviteCode} already exists`);
      continue;
    }
    
    try {
      await db.execute(sql`
        INSERT INTO debates (
          topic, category, status, creator_id, creator_side, opponent_type, invite_code, current_round
        ) VALUES (
          ${debate.topic}, ${debate.category}, ${debate.status},
          ${debate.creatorId}, ${debate.creatorSide}, ${debate.opponentType},
          ${debate.inviteCode}, 1
        )
      `);
      console.log(`[SEED] Added debate: ${debate.inviteCode}`);
    } catch (e: any) {
      console.log(`[SEED] Debate error: ${e.message}`);
    }
  }
}

export async function runStartupSeed(): Promise<void> {
  console.log("[SEED] Running startup seed...");
  console.log("[SEED] Environment:", process.env.NODE_ENV);
  console.log("[SEED] Database URL prefix:", process.env.DATABASE_URL?.substring(0, 30) + "...");
  
  try {
    await seedAiOpponents();
    await seedUsers();
    await seedDebates();
    console.log("[SEED] Startup seed complete!");
  } catch (error: any) {
    console.error("[SEED] Error during startup seed:", error?.message || error);
    console.error("[SEED] Stack:", error?.stack);
  }
}

export async function getSeedStatus(): Promise<{
  aiOpponentsCount: number;
  usersCount: number;
  debatesCount: number;
}> {
  const aiOpponentsResult = await db.select().from(aiOpponents);
  const usersResult = await db.execute(sql`SELECT COUNT(*) as count FROM users`);
  const debatesResult = await db.execute(sql`SELECT COUNT(*) as count FROM debates`);
  
  return {
    aiOpponentsCount: aiOpponentsResult.length,
    usersCount: Number(usersResult.rows[0]?.count || 0),
    debatesCount: Number(debatesResult.rows[0]?.count || 0),
  };
}
