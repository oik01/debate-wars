import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";

const { Pool } = pg;

// Log fatal error and exit gracefully for missing DATABASE_URL
// This allows the error to be logged in deployment logs
if (!process.env.DATABASE_URL) {
  const timestamp = new Date().toISOString();
  console.error(`[${timestamp}] [STARTUP] FATAL: DATABASE_URL environment variable is not set`);
  console.error(`[${timestamp}] [STARTUP] Did you forget to configure deployment secrets?`);
  console.error(`[${timestamp}] [STARTUP] Ensure DATABASE_URL is set in your deployment environment.`);
  process.exit(1);
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });
