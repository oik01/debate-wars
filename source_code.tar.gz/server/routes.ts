import type { Express } from "express";
import type { Server } from "http";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { ai } from "./replit_integrations/image/client";
import { 
  notifyTurnReady, 
  notifyDebateJoined, 
  notifyJudgmentReady, 
  notifyChallengeAccepted,
  notifyWorldChallengeRoundComplete,
  notifyWorldChallengeComplete
} from "./push-notifications";
import { getSeedStatus, runStartupSeed } from "./seed-startup";

// Cache for categories and topics
let cachedCategories: string[] = [];

async function getCategories(): Promise<string[]> {
  if (cachedCategories.length > 0) return cachedCategories;
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{
        role: "user",
        parts: [{
          text: `Generate a list of exactly 30 diverse and relevant categories for a debate competition application. 
          Categories should cover a wide range of interests (e.g., Tech, Ethics, Sports, Philosophy, Pop Culture, etc.).
          Return ONLY a JSON array of strings. Do not include markdown formatting.`
        }]
      }]
    });
    
    const text = response.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
    const cleanText = text.replace(/```json/g, "").replace(/```/g, "").trim();
    cachedCategories = JSON.parse(cleanText);
    return cachedCategories;
  } catch (error) {
    console.error("Gemini category generation error:", error);
    return ["Politics", "Technology", "Ethics", "Science", "Sports", "Business", "Entertainment", "Philosophy", "Education", "Environment"];
  }
}

// Helper to generate topics using Gemini
async function generateTopics(category: string): Promise<string[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{
        role: "user",
        parts: [{
          text: `Act as an expert debate researcher and moderator specializing in current events and controversial public discourse. 

          Research task:
          1. Search for high-stakes, "hot-button" issues, recent news, and intense public debates specifically within the category: "${category}".
          2. Focus on specific events, policy decisions, or geopolitical tensions from the last 12-24 months.
          3. Generate at least 20 debate statements that are highly specific, polarizing, and timely.

          Examples of the SPECIFICITY and INTENSITY required:
          - CATEGORY: Politics -> "The U.S. should initiate a pre-emptive military strike on Iran's nuclear facilities vs. Diplomacy is the only viable path."
          - CATEGORY: Politics -> "The use of lethal force in ICE enforcement operations during [specific event] was a legitimate exercise of power vs. a criminal act."
          - CATEGORY: Technology -> "The complete ban of [specific AI model/platform] is necessary to prevent mass misinformation vs. a violation of digital freedom."

          Requirements:
          - Phrased as clear "Proposition A vs. Proposition B" or a single clear, debatable statement.
          - Avoid generic topics. Focus on the "now".
          - Return ONLY a JSON array of strings. Do not include markdown formatting or extra text.`
        }]
      }]
    });

    const text = response.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
    const cleanText = text.replace(/```json/g, "").replace(/```/g, "").trim();
    return JSON.parse(cleanText);
  } catch (error) {
    console.error("Gemini topic generation error:", error);
    return [
      `Is ${category} becoming too commercialized?`,
      `The future of ${category} depends on regulation.`,
      `Technology is ruining ${category}.`,
      `${category} education should be mandatory.`,
      `Global impact of ${category} is overrated.`
    ]; // Fallback
  }
}

// Helper to generate political debate topics based on current news
async function generatePoliticalTopics(): Promise<{ topic: string; proSide: string; conSide: string }[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{
        role: "user",
        parts: [{
          text: `Act as an expert political debate researcher specializing in US partisan politics and current events.

          Generate 10 highly partisan political debate topics that would create clear Democrat vs Republican divisions.
          
          Requirements:
          1. Focus on CURRENT political issues from the last 3-6 months (2025-2026)
          2. Topics should have a clear liberal/progressive position AND a clear conservative position
          3. Include specific recent events, legislation, court cases, or political figures when possible
          4. Topics should be genuinely divisive along party lines
          
          Examples of the format needed:
          - Topic: "The January 6th prosecutions are politically motivated"
          - Topic: "Student loan forgiveness is government overreach"
          - Topic: "Border security requires building physical barriers"
          
          Return a JSON array with objects containing:
          - "topic": The debate statement (phrased as a position to argue FOR or AGAINST)
          - "proSide": What the PRO side is arguing (usually aligns with one party)
          - "conSide": What the CON side is arguing (usually aligns with the other party)
          
          Return ONLY a valid JSON array. No markdown formatting.`
        }]
      }]
    });

    const text = response.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
    const cleanText = text.replace(/```json/g, "").replace(/```/g, "").trim();
    return JSON.parse(cleanText);
  } catch (error) {
    console.error("Political topic generation error:", error);
    return [
      { topic: "The federal government should have more control over state elections", proSide: "Federal oversight ensures fair elections", conSide: "States rights should be preserved" },
      { topic: "Universal healthcare is a fundamental right", proSide: "Healthcare access should be guaranteed", conSide: "Free market healthcare is more efficient" },
      { topic: "Climate change requires immediate government action", proSide: "Government must lead climate action", conSide: "Market solutions are better than regulation" },
      { topic: "Immigration policy should prioritize humanitarian concerns", proSide: "Compassion should guide immigration", conSide: "Border security must come first" },
      { topic: "Gun control legislation reduces violence", proSide: "Stricter gun laws save lives", conSide: "Second Amendment rights must be protected" }
    ];
  }
}

// ELO calculation helper
function calculateElo(winnerElo: number, loserElo: number, kFactor: number = 32): { newWinnerElo: number, newLoserElo: number } {
  const expectedWinner = 1 / (1 + Math.pow(10, (loserElo - winnerElo) / 400));
  const expectedLoser = 1 / (1 + Math.pow(10, (winnerElo - loserElo) / 400));
  
  const newWinnerElo = Math.round(winnerElo + kFactor * (1 - expectedWinner));
  const newLoserElo = Math.round(loserElo + kFactor * (0 - expectedLoser));
  
  return { newWinnerElo, newLoserElo: Math.max(100, newLoserElo) }; // Min ELO of 100
}

// Helper to clean up transcript - removes repetitions and truncates
function cleanTranscript(text: string): string {
  if (!text) return text;
  
  // First pass: remove progressive phrase building like "I I think I think I think I won"
  // This pattern happens when speech recognition keeps re-recognizing the beginning
  let cleanedText = text;
  
  // Remove patterns where phrases progressively build (common speech recognition issue)
  // Match patterns like "word word word2 word word2 word3 word word2 word3 word4"
  for (let attempts = 0; attempts < 5; attempts++) {
    const words = cleanedText.split(/\s+/);
    const result: string[] = [];
    let i = 0;
    
    while (i < words.length) {
      // Check if current position starts a repeated phrase from result
      let foundRepeat = false;
      
      // Look for overlapping repetitions (2-15 word phrases)
      for (let phraseLen = 2; phraseLen <= Math.min(15, result.length); phraseLen++) {
        const recentPhrase = result.slice(-phraseLen).join(' ').toLowerCase();
        const currentPhrase = words.slice(i, i + phraseLen).join(' ').toLowerCase();
        
        if (recentPhrase === currentPhrase) {
          // Skip this repeated phrase
          i += phraseLen;
          foundRepeat = true;
          break;
        }
      }
      
      if (!foundRepeat) {
        // Skip single consecutive word repetition
        if (result.length > 0 && 
            words[i]?.toLowerCase() === result[result.length - 1]?.toLowerCase()) {
          i++;
          continue;
        }
        result.push(words[i]);
        i++;
      }
    }
    
    const newText = result.join(' ');
    if (newText === cleanedText) break; // No more changes
    cleanedText = newText;
  }
  
  // Truncate to reasonable length (max ~500 words)
  const finalWords = cleanedText.split(/\s+/).slice(0, 500);
  return finalWords.join(' ').trim();
}

// Helper to judge debate - considers all three rounds
async function judgeDebate(debateId: number) {
  try {
    const debate = await storage.getDebate(debateId);
    if (!debate || !debate.turns || debate.turns.length < 6) return;

    // Update status to judging
    await storage.updateDebateStatus(debateId, "judging");

    // Organize turns by round and side
    const proTurns = debate.turns.filter(t => t.side === "pro").sort((a, b) => a.roundNumber - b.roundNumber);
    const conTurns = debate.turns.filter(t => t.side === "con").sort((a, b) => a.roundNumber - b.roundNumber);

    if (proTurns.length < 3 || conTurns.length < 3) return;

    const prompt = `
      You are an expert debate judge. Analyze the following three-round debate on the topic: "${debate.topic}".
      
      === ROUND 1 (60 seconds each) ===
      PRO Opening: "${proTurns[0]?.transcript}"
      CON Opening: "${conTurns[0]?.transcript}"
      
      === ROUND 2 (60 seconds each) ===
      PRO Rebuttal: "${proTurns[1]?.transcript}"
      CON Rebuttal: "${conTurns[1]?.transcript}"
      
      === ROUND 3 - FINAL (30 seconds each, order reversed) ===
      CON Closing: "${conTurns[2]?.transcript}"
      PRO Closing: "${proTurns[2]?.transcript}"

      Grade each debater on the following categories using letter grades (A, B, C, D, or F):
      1. Logic & Reasoning - How well-structured and logical were their arguments?
      2. Evidence & Examples - Did they support claims with facts, examples, or data?
      3. Persuasion - How compelling and convincing was their delivery?
      4. Rebuttals - Did they effectively counter opposing points?
      
      Also provide an overall grade for each debater.
      
      Return a JSON object with this exact structure (no markdown):
      {
        "winnerSide": "pro" or "con",
        "explanation": "A comprehensive analysis of the debate highlighting key moments and explaining why the winner prevailed.",
        "proGrades": {
          "logic": { "grade": "A/B/C/D/F", "explanation": "Brief explanation for this grade" },
          "evidence": { "grade": "A/B/C/D/F", "explanation": "Brief explanation for this grade" },
          "persuasion": { "grade": "A/B/C/D/F", "explanation": "Brief explanation for this grade" },
          "rebuttals": { "grade": "A/B/C/D/F", "explanation": "Brief explanation for this grade" },
          "overall": { "grade": "A/B/C/D/F", "explanation": "Brief overall assessment" }
        },
        "conGrades": {
          "logic": { "grade": "A/B/C/D/F", "explanation": "Brief explanation for this grade" },
          "evidence": { "grade": "A/B/C/D/F", "explanation": "Brief explanation for this grade" },
          "persuasion": { "grade": "A/B/C/D/F", "explanation": "Brief explanation for this grade" },
          "rebuttals": { "grade": "A/B/C/D/F", "explanation": "Brief explanation for this grade" },
          "overall": { "grade": "A/B/C/D/F", "explanation": "Brief overall assessment" }
        }
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: "user", parts: [{ text: prompt }] }]
    });

    const text = response.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
    // Remove markdown, control characters, and clean up for JSON parsing
    let cleanText = text
      .replace(/```json/g, "")
      .replace(/```/g, "")
      .replace(/[\x00-\x1F\x7F]/g, " ") // Remove control characters
      .replace(/\n/g, " ")
      .replace(/\r/g, " ")
      .replace(/\t/g, " ")
      .trim();
    
    // Extract JSON object from the text
    const jsonMatch = cleanText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON object found in response");
    }
    
    // Define types for grades
    type GradeCategory = { grade: string; explanation: string };
    type DebaterGrades = {
      logic: GradeCategory;
      evidence: GradeCategory;
      persuasion: GradeCategory;
      rebuttals: GradeCategory;
      overall: GradeCategory;
    };
    
    const defaultGrades: DebaterGrades = {
      logic: { grade: "C", explanation: "Unable to fully assess" },
      evidence: { grade: "C", explanation: "Unable to fully assess" },
      persuasion: { grade: "C", explanation: "Unable to fully assess" },
      rebuttals: { grade: "C", explanation: "Unable to fully assess" },
      overall: { grade: "C", explanation: "Unable to fully assess" }
    };
    
    // Try to parse JSON, with fallback extraction if it fails
    let judgment: { 
      winnerSide: string; 
      explanation: string;
      proGrades?: DebaterGrades;
      conGrades?: DebaterGrades;
    };
    try {
      judgment = JSON.parse(jsonMatch[0]);
    } catch (parseError) {
      console.log("Initial JSON parse failed, trying fallback extraction");
      // Fallback: extract winnerSide and explanation using regex
      const winnerMatch = cleanText.match(/"winnerSide"\s*:\s*"(pro|con)"/i);
      const explanationMatch = cleanText.match(/"explanation"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/);
      
      if (!winnerMatch) {
        // Try to find winner from context
        const proWinMatch = cleanText.match(/winner[^"]*pro/i) || cleanText.match(/pro[^"]*wins/i) || cleanText.match(/pro[^"]*prevail/i);
        const conWinMatch = cleanText.match(/winner[^"]*con/i) || cleanText.match(/con[^"]*wins/i) || cleanText.match(/con[^"]*prevail/i);
        
        if (!proWinMatch && !conWinMatch) {
          throw new Error("Could not determine winner from AI response");
        }
        
        const extractedWinner = proWinMatch ? "pro" : "con";
        judgment = {
          winnerSide: extractedWinner,
          explanation: "The AI judge has determined a winner based on the quality of arguments presented. Due to technical limitations, a detailed explanation could not be extracted.",
          proGrades: defaultGrades,
          conGrades: defaultGrades
        };
      } else {
        judgment = {
          winnerSide: winnerMatch[1].toLowerCase(),
          explanation: explanationMatch ? explanationMatch[1] : "The debate has been judged based on argument quality, evidence, rebuttals, and persuasiveness.",
          proGrades: defaultGrades,
          conGrades: defaultGrades
        };
      }
    }
    
    // Ensure grades exist with defaults
    const proGrades = judgment.proGrades || defaultGrades;
    const conGrades = judgment.conGrades || defaultGrades;
    
    // Map pro/con grades to creator/opponent based on which side they took
    const creatorGrades = debate.creatorSide === "pro" ? proGrades : conGrades;
    const opponentGrades = debate.creatorSide === "pro" ? conGrades : proGrades;

    const winnerId = judgment.winnerSide === "pro" 
      ? debate.creatorSide === "pro" ? debate.creatorId : debate.opponentId
      : debate.creatorSide === "con" ? debate.creatorId : debate.opponentId;

    const loserId = winnerId === debate.creatorId ? debate.opponentId : debate.creatorId;

    await storage.createJudgment({
      debateId,
      winnerId: winnerId!,
      explanation: judgment.explanation,
      // Creator grades
      creatorLogicGrade: creatorGrades.logic.grade,
      creatorEvidenceGrade: creatorGrades.evidence.grade,
      creatorPersuasionGrade: creatorGrades.persuasion.grade,
      creatorRebuttalsGrade: creatorGrades.rebuttals.grade,
      creatorOverallGrade: creatorGrades.overall.grade,
      creatorLogicExplanation: creatorGrades.logic.explanation,
      creatorEvidenceExplanation: creatorGrades.evidence.explanation,
      creatorPersuasionExplanation: creatorGrades.persuasion.explanation,
      creatorRebuttalsExplanation: creatorGrades.rebuttals.explanation,
      creatorOverallExplanation: creatorGrades.overall.explanation,
      // Opponent grades
      opponentLogicGrade: opponentGrades.logic.grade,
      opponentEvidenceGrade: opponentGrades.evidence.grade,
      opponentPersuasionGrade: opponentGrades.persuasion.grade,
      opponentRebuttalsGrade: opponentGrades.rebuttals.grade,
      opponentOverallGrade: opponentGrades.overall.grade,
      opponentLogicExplanation: opponentGrades.logic.explanation,
      opponentEvidenceExplanation: opponentGrades.evidence.explanation,
      opponentPersuasionExplanation: opponentGrades.persuasion.explanation,
      opponentRebuttalsExplanation: opponentGrades.rebuttals.explanation,
      opponentOverallExplanation: opponentGrades.overall.explanation
    });
    
    // Helper to convert grade to numeric score (for averaging)
    const gradeToScore = (grade: string): number => {
      switch (grade.toUpperCase()) {
        case "A": return 4;
        case "B": return 3;
        case "C": return 2;
        case "D": return 1;
        case "F": return 0;
        default: return 2;
      }
    };
    
    // Update user profile grade averages
    const updateUserGrades = async (userId: string, grades: DebaterGrades) => {
      if (!userId || userId === "AI_OPPONENT") return;
      const user = await storage.getUser(userId);
      if (!user) return;
      
      const currentTotal = parseInt(user.totalDebatesGraded || "0");
      const newTotal = currentTotal + 1;
      
      // Calculate new running averages
      const calcNewAvg = (currentAvg: string, newScore: number) => {
        const current = parseFloat(currentAvg || "0");
        return ((current * currentTotal + newScore) / newTotal).toFixed(2);
      };
      
      await storage.updateUserGradeAverages(userId, {
        avgLogicScore: calcNewAvg(user.avgLogicScore || "0", gradeToScore(grades.logic.grade)),
        avgEvidenceScore: calcNewAvg(user.avgEvidenceScore || "0", gradeToScore(grades.evidence.grade)),
        avgPersuasionScore: calcNewAvg(user.avgPersuasionScore || "0", gradeToScore(grades.persuasion.grade)),
        avgRebuttalsScore: calcNewAvg(user.avgRebuttalsScore || "0", gradeToScore(grades.rebuttals.grade)),
        totalDebatesGraded: newTotal.toString()
      });
    };
    
    // Update both users' grade averages
    await updateUserGrades(debate.creatorId, creatorGrades);
    if (debate.opponentId) {
      await updateUserGrades(debate.opponentId, opponentGrades);
    }

    await storage.updateDebateStatus(debateId, "completed", winnerId!);

    // Notify both players about the judgment
    if (winnerId) {
      notifyJudgmentReady(winnerId, debate.topic, debateId, true).catch(console.error);
    }
    if (loserId && loserId !== "AI_OPPONENT") {
      notifyJudgmentReady(loserId, debate.topic, debateId, false).catch(console.error);
    }

    // Update ELO ratings - skip for AI opponent debates (practice mode)
    const isAIDebate = !!debate.aiOpponentId;
    if (winnerId && loserId && !isAIDebate) {
      const winner = await storage.getUser(winnerId);
      const loser = await storage.getUser(loserId);
      
      if (winner && loser) {
        const winnerElo = parseInt(winner.eloRating || "1000");
        const loserElo = parseInt(loser.eloRating || "1000");
        const { newWinnerElo, newLoserElo } = calculateElo(winnerElo, loserElo);
        
        await storage.updateUserElo(winnerId, newWinnerElo, true);
        await storage.updateUserElo(loserId, newLoserElo, false);
      }
    }

    // Check if this debate is part of a world challenge and update the round
    const challengeRound = await storage.getWorldChallengeRoundByDebateId(debateId);
    if (challengeRound && winnerId) {
      const { round, challenge } = challengeRound;
      // Update round winner
      await storage.updateChallengeRoundWinner(challenge.id, round.roundNumber, winnerId);
      // Advance to next round or complete challenge
      await storage.advanceChallengeRound(challenge.id);
    }

  } catch (error) {
    console.error("Judging error:", error);
    console.error("Error details:", error instanceof Error ? error.message : String(error));
    // On error, mark as completed with explanation
    try {
      await storage.updateDebateStatus(debateId, "completed");
      // Create a fallback judgment with tie
      await storage.createJudgment({
        debateId,
        winnerId: undefined,
        explanation: "The AI judge was unable to render a decision. This may be due to technical difficulties. The debate has been marked as a tie."
      });
    } catch (e) {
      console.error("Failed to recover from judging error:", e);
    }
  }
}

// Helper to generate AI opponent argument
interface AiOpponentData {
  name: string;
  personality: string;
  specialTrait: string | null;
  logicSkill: number;
  evidenceSkill: number;
  persuasionSkill: number;
  rebuttalsSkill: number;
  difficulty: string;
}

async function fetchAiOpponentData(aiOpponentId: number | null | undefined): Promise<AiOpponentData | null> {
  if (!aiOpponentId) return null;
  const opponent = await storage.getAiOpponent(aiOpponentId);
  if (!opponent) return null;
  return {
    name: opponent.name,
    personality: opponent.personality,
    specialTrait: opponent.specialTrait,
    logicSkill: opponent.logicSkill,
    evidenceSkill: opponent.evidenceSkill,
    persuasionSkill: opponent.persuasionSkill,
    rebuttalsSkill: opponent.rebuttalsSkill,
    difficulty: opponent.difficulty,
  };
}

function getSkillInstructions(aiOpponent: AiOpponentData | null): string {
  if (!aiOpponent) return "";
  
  const skills = {
    logic: aiOpponent.logicSkill,
    evidence: aiOpponent.evidenceSkill,
    persuasion: aiOpponent.persuasionSkill,
    rebuttals: aiOpponent.rebuttalsSkill,
  };
  
  const instructions: string[] = [];
  
  // Logic skill
  if (skills.logic <= 1) {
    instructions.push("Make occasional logical fallacies or weak reasoning");
  } else if (skills.logic === 4) {
    instructions.push("Use impeccable logical reasoning with clear cause-and-effect chains");
  }
  
  // Evidence skill
  if (skills.evidence <= 1) {
    instructions.push("Rarely cite specific facts or studies");
  } else if (skills.evidence === 4) {
    instructions.push("Reference specific statistics, studies, and credible sources");
  }
  
  // Persuasion skill
  if (skills.persuasion <= 1) {
    instructions.push("Be somewhat dry and unconvincing in delivery");
  } else if (skills.persuasion === 4) {
    instructions.push("Use powerful rhetorical techniques, metaphors, and emotional appeals");
  }
  
  // Rebuttals skill
  if (skills.rebuttals <= 1) {
    instructions.push("Sometimes miss obvious counterarguments or fail to address key points");
  } else if (skills.rebuttals === 4) {
    instructions.push("Systematically address and dismantle every opposing argument");
  }
  
  return instructions.length > 0 ? "\n\nSkill adjustments:\n- " + instructions.join("\n- ") : "";
}

function getSpecialTraitInstructions(aiOpponent: AiOpponentData | null, round: number): string {
  if (!aiOpponent || !aiOpponent.specialTrait) return "";
  
  switch (aiOpponent.specialTrait) {
    case "flip_flops_positions":
      if (round === 2) {
        return "\n\nSPECIAL BEHAVIOR: In this round, you should contradict some of your previous arguments. Express doubt about your earlier position and maybe even agree with parts of your opponent's argument, before trying to recover your original stance. This inconsistency is intentional.";
      } else if (round === 3) {
        return "\n\nSPECIAL BEHAVIOR: In your closing, you may flip-flop between positions, seeming uncertain. You might say something like 'On second thought...' or 'Having considered my opponent's points, perhaps...' before switching back.";
      }
      return "";
    
    case "accidentally_agrees":
      if (round > 1) {
        return "\n\nSPECIAL BEHAVIOR: Occasionally, you accidentally agree with your opponent or undermine your own position. For example, say something like 'Well, my opponent does have a point about...' or 'I suppose that could be true...'";
      }
      return "";
      
    case "rambles":
      return "\n\nSPECIAL BEHAVIOR: You tend to go on tangents. Include at least one digression about something loosely related before getting back to your main point.";
      
    default:
      return "";
  }
}

async function generateAIArgument(topic: string, side: string, round: number, previousTurns: any[], aiOpponent: AiOpponentData | null = null): Promise<string> {
  try {
    const roundContext = round === 1 ? "opening argument" : round === 2 ? "rebuttal" : "closing statement";
    const timeLimit = round === 3 ? "30 seconds" : "60 seconds";
    
    const opponentArguments = previousTurns
      .filter(t => t.side !== side)
      .map((t, i) => `Round ${t.roundNumber}: "${t.transcript}"`)
      .join("\n");

    // Build personality context
    let personalityContext = "";
    if (aiOpponent) {
      personalityContext = `\n\nYou are ${aiOpponent.name}, a ${aiOpponent.difficulty} level debater.
Personality: ${aiOpponent.personality}
${getSkillInstructions(aiOpponent)}
${getSpecialTraitInstructions(aiOpponent, round)}`;
    }

    const prompt = `You are a ${aiOpponent ? aiOpponent.name : 'skilled debater'}. Generate a ${roundContext} for a debate.
${personalityContext}

Topic: "${topic}"
Your side: ${side.toUpperCase()}
Time limit: ${timeLimit} (keep response appropriate for spoken delivery)
Round: ${round} of 3

${opponentArguments ? `Your opponent has argued:\n${opponentArguments}\n\nRespond to their points while making your case.` : "This is the opening round. Present your strongest initial arguments."}

Provide only the argument text, as if spoken. Stay in character based on your personality.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: "user", parts: [{ text: prompt }] }]
    });

    return response.candidates?.[0]?.content?.parts?.[0]?.text || "I concede this point.";
  } catch (error) {
    console.error("AI argument generation error:", error);
    return "Technical difficulties. I must concede this point.";
  }
}

// Generate random invite code
function generateInviteCode(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth setup
  await setupAuth(app);
  registerAuthRoutes(app);
  registerChatRoutes(app);
  registerObjectStorageRoutes(app);

  // === API ROUTES ===

  // Update user profile
  app.patch("/api/user/profile", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    const { nationality, politicalAffiliation, favoriteCategories, avatarType, customAvatarUrl, firstName, lastName } = req.body;
    
    if (!userId) {
      return res.status(401).json({ error: "User not authenticated" });
    }
    
    try {
      const updatedUser = await storage.updateUserProfile(userId, {
        nationality,
        politicalAffiliation,
        favoriteCategories: Array.isArray(favoriteCategories) ? favoriteCategories.join(',') : favoriteCategories,
        avatarType,
        customAvatarUrl,
        firstName,
        lastName,
        onboardingCompleted: 'true',
      });
      
      if (!updatedUser) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  // Health check / seed status (for debugging production)
  app.get("/api/health", async (req, res) => {
    try {
      const seedStatus = await getSeedStatus();
      res.json({
        status: "ok",
        environment: process.env.NODE_ENV,
        seed: seedStatus,
        timestamp: new Date().toISOString(),
      });
    } catch (error: any) {
      res.status(500).json({ 
        status: "error", 
        error: error?.message || "Unknown error" 
      });
    }
  });

  // Force seed endpoint (for production data population)
  app.post("/api/force-seed", async (req, res) => {
    try {
      console.log("[FORCE-SEED] Triggering manual seed...");
      await runStartupSeed();
      const seedStatus = await getSeedStatus();
      res.json({
        status: "ok",
        message: "Seed completed",
        seed: seedStatus,
        timestamp: new Date().toISOString(),
      });
    } catch (error: any) {
      console.error("[FORCE-SEED] Error:", error);
      res.status(500).json({ 
        status: "error", 
        error: error?.message || "Unknown error" 
      });
    }
  });

  // Categories
  app.get("/api/categories", async (req, res) => {
    const categories = await getCategories();
    res.json(categories);
  });

  // AI Opponents
  app.get("/api/ai-opponents", async (req, res) => {
    try {
      const opponents = await storage.getAiOpponents();
      res.json(opponents);
    } catch (error) {
      console.error("Error fetching AI opponents:", error);
      res.status(500).json({ error: "Failed to fetch AI opponents" });
    }
  });

  app.get("/api/ai-opponents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const opponent = await storage.getAiOpponent(id);
      if (!opponent) {
        return res.status(404).json({ error: "AI opponent not found" });
      }
      res.json(opponent);
    } catch (error) {
      console.error("Error fetching AI opponent:", error);
      res.status(500).json({ error: "Failed to fetch AI opponent" });
    }
  });

  // Topics
  app.get(api.topics.list.path, async (req, res) => {
    const category = (req.query.category as string) || "general";
    const topics = await generateTopics(category);
    res.json(topics);
  });

  // Political Topics - generates current news-based partisan debate topics
  app.get("/api/political-topics", async (req, res) => {
    const topics = await generatePoliticalTopics();
    res.json(topics);
  });

  // Political Debates - get pending debates filtered by required affiliation
  app.get("/api/political-debates", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    const currentUser = await storage.getUser(user.claims.sub);
    
    if (!currentUser?.politicalAffiliation) {
      return res.status(400).json({ message: "You must set your political affiliation to access political debates" });
    }
    
    // Get all debates with opponentType "political" that are waiting
    const allDebates = await storage.getDebates("waiting");
    
    // Filter to political debates where user's affiliation matches the required affiliation
    // Independents can see and join debates from either side
    const eligibleDebates = allDebates.filter((d: any) => {
      if (d.opponentType !== "political" || d.creatorId === user.claims.sub) {
        return false;
      }
      // Independents can join any political debate
      if (currentUser.politicalAffiliation === "independent") {
        return true;
      }
      // Democrats and Republicans can only join debates that require their affiliation
      return d.requiredAffiliation === currentUser.politicalAffiliation;
    });
    
    res.json(eligibleDebates);
  });

  // Create Political Debate
  app.post("/api/political-debates", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    const currentUser = await storage.getUser(user.claims.sub);
    
    if (!currentUser?.politicalAffiliation || currentUser.politicalAffiliation === "independent") {
      return res.status(400).json({ message: "You must be a Democrat or Republican to create political debates" });
    }
    
    try {
      const { topic, creatorSide } = req.body;
      
      if (!topic) {
        return res.status(400).json({ message: "Topic is required" });
      }
      
      const inviteCode = generateInviteCode();
      
      // Determine required opponent affiliation
      const requiredAffiliation = currentUser.politicalAffiliation === "democrat" ? "republican" : "democrat";
      
      const debateData = {
        topic,
        category: "Political Arena",
        creatorId: user.claims.sub,
        creatorSide: creatorSide || "pro",
        opponentType: "political",
        creatorAffiliation: currentUser.politicalAffiliation,
        requiredAffiliation,
        inviteCode,
      };
      
      const debate = await storage.createDebate(debateData);
      res.status(201).json(debate);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json(e.errors);
      throw e;
    }
  });

  // Debates List
  app.get(api.debates.list.path, async (req, res) => {
    const status = req.query.status as string | undefined;
    const debates = await storage.getDebates(status);
    res.json(debates);
  });

  // Create Debate
  app.post(api.debates.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    
    try {
      const input = api.debates.create.input.parse(req.body);
      const inviteCode = generateInviteCode();
      
      // Validate aiOpponentId is required when opponentType is "ai"
      if (input.opponentType === "ai") {
        if (!input.aiOpponentId) {
          return res.status(400).json({ message: "AI opponent must be selected for AI debates" });
        }
        // Verify the AI opponent exists
        const aiOpponent = await storage.getAiOpponent(input.aiOpponentId);
        if (!aiOpponent) {
          return res.status(400).json({ message: "Selected AI opponent not found" });
        }
      }
      
      const debateData: any = {
        ...input,
        creatorId: user.claims.sub,
        inviteCode,
        opponentType: input.opponentType || "open",
        targetUserId: input.targetUserId || null,
      };
      
      // If AI opponent, set opponent and make active immediately
      if (input.opponentType === "ai") {
        debateData.opponentId = "AI_OPPONENT";
        debateData.status = "active";
      }
      
      const debate = await storage.createDebate(debateData);
      res.status(201).json(debate);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json(e.errors);
      throw e;
    }
  });

  // Get debate by invite code
  app.get("/api/debates/invite/:code", async (req, res) => {
    const debate = await storage.getDebateByInviteCode(req.params.code);
    if (!debate) return res.sendStatus(404);
    res.json(debate);
  });

  // Get Debate
  app.get(api.debates.get.path, async (req, res) => {
    const debate = await storage.getDebate(Number(req.params.id));
    if (!debate) return res.sendStatus(404);
    res.json(debate);
  });

  // Join Debate
  app.post(api.debates.join.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    const debateId = Number(req.params.id);

    const debate = await storage.getDebate(debateId);
    if (!debate) return res.sendStatus(404);
    if (debate.status !== "waiting") return res.status(400).json({ message: "Debate already active or full" });
    if (debate.creatorId === user.claims.sub) return res.status(400).json({ message: "Cannot join your own debate" });

    // Check political affiliation for political debates
    if (debate.opponentType === "political" && debate.requiredAffiliation) {
      const joiningUser = await storage.getUser(user.claims.sub);
      if (!joiningUser?.politicalAffiliation) {
        return res.status(400).json({ message: "You must set your political affiliation to join political debates" });
      }
      // Independents can join any political debate from either side
      if (joiningUser.politicalAffiliation !== "independent" && 
          joiningUser.politicalAffiliation !== debate.requiredAffiliation) {
        const requiredParty = debate.requiredAffiliation === "democrat" ? "Democrat" : "Republican";
        return res.status(400).json({ message: `This debate requires a ${requiredParty} opponent` });
      }
    }

    const updated = await storage.joinDebate(debateId, user.claims.sub);
    
    // Notify debate creator that someone joined
    const joiningUser = await storage.getUser(user.claims.sub);
    const joinerName = joiningUser?.firstName || joiningUser?.email?.split('@')[0] || 'Someone';
    notifyDebateJoined(debate.creatorId, joinerName, debateId, debate.topic).catch(console.error);
    
    res.json(updated);
  });

  // Submit Turn - Three round logic
  // Round 1 & 2: Creator first, then opponent (60 seconds each)
  // Round 3: Opponent first, then creator (30 seconds each) - reversed order
  app.post(api.turns.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    const debateId = Number(req.params.id);
    const userId = user.claims.sub;

    const debate = await storage.getDebate(debateId);
    if (!debate) return res.sendStatus(404);
    if (debate.status !== "active") return res.status(400).json({ message: "Debate is not active" });

    const isCreator = debate.creatorId === userId;
    const isOpponent = debate.opponentId === userId;
    const isAI = debate.opponentType === "ai" && userId === "AI_OPPONENT";
    
    if (!isCreator && !isOpponent && !isAI) return res.sendStatus(403);

    const userSide = isCreator ? debate.creatorSide : (debate.creatorSide === "pro" ? "con" : "pro");
    const currentRound = debate.currentRound || 1;
    
    // Get turns for current round
    const roundTurns = debate.turns?.filter(t => t.roundNumber === currentRound) || [];
    
    // Check turn order based on round
    // Rounds 1 & 2: Creator first, then opponent
    // Round 3: Opponent first, then creator (reversed)
    const isRound3 = currentRound === 3;
    const firstPlayer = isRound3 ? "opponent" : "creator";
    const secondPlayer = isRound3 ? "creator" : "opponent";
    
    const expectedFirst = firstPlayer === "creator" ? isCreator : isOpponent;
    const expectedSecond = secondPlayer === "creator" ? isCreator : isOpponent;
    
    // Check if it's this user's turn
    if (roundTurns.length === 0 && !expectedFirst) {
      return res.status(400).json({ message: isRound3 ? "Opponent goes first in final round" : "Creator goes first" });
    }
    if (roundTurns.length === 1 && !expectedSecond) {
      return res.status(400).json({ message: "Waiting for your opponent" });
    }
    if (roundTurns.length >= 2) {
      return res.status(400).json({ message: "This round is complete" });
    }

    try {
      const input = api.turns.create.input.parse(req.body);
      // Clean up the transcript to remove speech recognition artifacts
      const cleanedTranscript = cleanTranscript(input.transcript);
      
      const turn = await storage.createTurn({
        debateId,
        userId,
        transcript: cleanedTranscript,
        side: userSide,
        roundNumber: currentRound,
      });

      // Check round completion and progress
      const allTurns = await storage.getTurns(debateId);
      const currentRoundTurns = allTurns.filter(t => t.roundNumber === currentRound);

      // Notify the other player that it's their turn (if not AI opponent)
      if (debate.opponentType !== "ai") {
        const otherPlayerId = isCreator ? debate.opponentId : debate.creatorId;
        if (otherPlayerId && currentRoundTurns.length === 1) {
          // First turn of round just submitted, notify opponent it's their turn
          notifyTurnReady(otherPlayerId, debate.topic, debateId).catch(console.error);
        }
      }
      
      if (currentRoundTurns.length >= 2) {
        if (currentRound < 3) {
          // Move to next round
          await storage.updateDebateRound(debateId, currentRound + 1);
          
          // If AI opponent, generate their next turn after a brief delay
          if (debate.opponentType === "ai") {
            setTimeout(async () => {
              const updatedDebate = await storage.getDebate(debateId);
              if (!updatedDebate) return;
              const nextRound = currentRound + 1;
              const aiSide = debate.creatorSide === "pro" ? "con" : "pro";
              
              // Fetch AI opponent personality if set
              const aiOpponentData = await fetchAiOpponentData(debate.aiOpponentId);
              
              // In round 3, AI (opponent) goes first
              if (nextRound === 3) {
                const aiArg = await generateAIArgument(debate.topic, aiSide, nextRound, updatedDebate.turns || [], aiOpponentData);
                await storage.createTurn({
                  debateId,
                  userId: "AI_OPPONENT",
                  transcript: aiArg,
                  side: aiSide,
                  roundNumber: nextRound,
                });
              }
            }, 2000);
          }
        } else {
          // All 3 rounds complete, trigger judgment
          judgeDebate(debateId);
        }
      } else if (debate.opponentType === "ai" && roundTurns.length === 0) {
        // Human just submitted first turn in rounds 1 or 2, AI responds
        setTimeout(async () => {
          const updatedDebate = await storage.getDebate(debateId);
          if (!updatedDebate) return;
          const aiSide = debate.creatorSide === "pro" ? "con" : "pro";
          
          // Fetch AI opponent personality if set
          const aiOpponentData = await fetchAiOpponentData(debate.aiOpponentId);
          
          const aiArg = await generateAIArgument(debate.topic, aiSide, currentRound, updatedDebate.turns || [], aiOpponentData);
          await storage.createTurn({
            debateId,
            userId: "AI_OPPONENT",
            transcript: aiArg,
            side: aiSide,
            roundNumber: currentRound,
          });
          
          // Check if round complete and move to next
          const turnsAfterAI = await storage.getTurns(debateId);
          const thisRoundTurns = turnsAfterAI.filter(t => t.roundNumber === currentRound);
          if (thisRoundTurns.length >= 2 && currentRound < 3) {
            await storage.updateDebateRound(debateId, currentRound + 1);
            
            // In round 3, AI goes first
            if (currentRound + 1 === 3) {
              const nextRoundDebate = await storage.getDebate(debateId);
              const aiArgR3 = await generateAIArgument(debate.topic, aiSide, 3, nextRoundDebate?.turns || [], aiOpponentData);
              await storage.createTurn({
                debateId,
                userId: "AI_OPPONENT",
                transcript: aiArgR3,
                side: aiSide,
                roundNumber: 3,
              });
            }
          }
        }, 2000);
      }

      res.status(201).json(turn);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json(e.errors);
      throw e;
    }
  });

  // Re-judge a completed debate (admin functionality for fixing failed judgments)
  app.post("/api/debates/:id/rejudge", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    const debateId = Number(req.params.id);
    const userId = user.claims.sub;

    const debate = await storage.getDebate(debateId);
    if (!debate) return res.sendStatus(404);
    
    // Only allow re-judging completed debates with a "tie" (no winner)
    if (debate.status !== "completed") {
      return res.status(400).json({ message: "Can only re-judge completed debates" });
    }
    
    // Only allow participants or admin to re-judge
    if (debate.creatorId !== userId && debate.opponentId !== userId) {
      return res.status(403).json({ message: "Only participants can request re-judgment" });
    }
    
    // Check if all 6 turns exist
    if (!debate.turns || debate.turns.length < 6) {
      return res.status(400).json({ message: "Debate does not have all required turns" });
    }
    
    try {
      // Delete existing judgment
      await storage.deleteJudgmentByDebateId(debateId);
      
      // Reset debate status to allow re-judging
      await storage.updateDebateStatus(debateId, "active");
      
      // Trigger new judgment
      await judgeDebate(debateId);
      
      // Return updated debate
      const updatedDebate = await storage.getDebate(debateId);
      res.json({ message: "Re-judgment complete", debate: updatedDebate });
    } catch (error) {
      console.error("Re-judge error:", error);
      res.status(500).json({ message: "Failed to re-judge debate" });
    }
  });

  // === LEADERBOARD & USER ROUTES ===

  // Get leaderboard
  app.get("/api/leaderboard", async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 50;
    const users = await storage.getLeaderboard(limit);
    res.json(users);
  });

  // Get user profile with rank
  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) return res.sendStatus(404);
    
    const rank = await storage.getUserRank(req.params.id);
    res.json({ ...user, rank });
  });

  // Get current user's profile
  app.get("/api/me", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    const user = await storage.getUser(userId);
    if (!user) return res.sendStatus(404);
    
    const rank = await storage.getUserRank(userId);
    const relationships = await storage.getRelationships(userId);
    
    res.json({ ...user, rank, ...relationships });
  });

  // Get user's debate history
  app.get("/api/users/:id/debates", async (req, res) => {
    const userId = req.params.id;
    const debates = await storage.getDebatesByUser(userId);
    res.json(debates);
  });

  // Search users
  app.get("/api/users", async (req, res) => {
    const query = req.query.q as string || "";
    if (query.length < 2) return res.json([]);
    const users = await storage.searchUsers(query);
    res.json(users);
  });

  // === RELATIONSHIPS ===

  // Add friend
  app.post("/api/relationships/friend/:targetId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    const targetId = req.params.targetId;
    
    if (userId === targetId) return res.status(400).json({ message: "Cannot add yourself" });
    
    const rel = await storage.addRelationship(userId, targetId, "friend");
    res.status(201).json(rel);
  });

  // Add enemy
  app.post("/api/relationships/enemy/:targetId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    const targetId = req.params.targetId;
    
    if (userId === targetId) return res.status(400).json({ message: "Cannot add yourself" });
    
    const rel = await storage.addRelationship(userId, targetId, "enemy");
    res.status(201).json(rel);
  });

  // Remove relationship
  app.delete("/api/relationships/:targetId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    await storage.removeRelationship(userId, req.params.targetId);
    res.sendStatus(204);
  });

  // Get relationships
  app.get("/api/relationships", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    const relationships = await storage.getRelationships(userId);
    res.json(relationships);
  });

  // === RELATIONSHIP REQUESTS ===

  // Send friend/rival request
  app.post("/api/relationship-requests", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const senderId = authUser.claims.sub;
    const { receiverId, requestType } = req.body;
    
    if (!receiverId || !requestType) {
      return res.status(400).json({ message: "Receiver ID and request type are required" });
    }
    
    if (senderId === receiverId) {
      return res.status(400).json({ message: "Cannot send request to yourself" });
    }
    
    if (!["friend", "rival"].includes(requestType)) {
      return res.status(400).json({ message: "Request type must be 'friend' or 'rival'" });
    }
    
    // Check if already friends or rivals (check both relationship types)
    const relationships = await storage.getRelationships(senderId);
    const isFriend = relationships.friends.find(f => f.id === receiverId);
    const isRival = relationships.enemies.find(e => e.id === receiverId);
    
    if (isFriend) {
      return res.status(400).json({ message: "You're already friends with this user" });
    }
    
    if (isRival) {
      return res.status(400).json({ message: "You're already rivals with this user" });
    }
    
    // Check if request already exists in either direction
    const existingRequest = await storage.getExistingRequestBothDirections(senderId, receiverId);
    if (existingRequest) {
      if (existingRequest.direction === 'sent') {
        return res.status(400).json({ message: "You already sent a request to this user" });
      } else {
        return res.status(400).json({ message: "This user already sent you a request - check your incoming requests!" });
      }
    }
    
    const request = await storage.createRelationshipRequest(senderId, receiverId, requestType);
    res.status(201).json(request);
  });

  // Get pending requests received by user
  app.get("/api/relationship-requests/received", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    const requests = await storage.getPendingRequestsForUser(userId);
    res.json(requests);
  });

  // Get sent requests
  app.get("/api/relationship-requests/sent", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    const requests = await storage.getSentRequests(userId);
    res.json(requests);
  });

  // Accept relationship request
  app.post("/api/relationship-requests/:requestId/accept", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    try {
      const relationship = await storage.acceptRelationshipRequest(req.params.requestId, userId);
      res.json(relationship);
    } catch (error) {
      res.status(404).json({ message: "Request not found" });
    }
  });

  // Decline relationship request
  app.post("/api/relationship-requests/:requestId/decline", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    await storage.declineRelationshipRequest(req.params.requestId, userId);
    res.sendStatus(204);
  });

  // === POLITICAL AFFILIATION ===

  // Check if user can change political affiliation
  app.get("/api/user/political-affiliation/status", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    const status = await storage.canChangePoliticalAffiliation(userId);
    const user = await storage.getUser(userId);
    
    res.json({
      ...status,
      currentAffiliation: user?.politicalAffiliation,
      lastChanged: user?.politicalAffiliationLastChanged,
    });
  });

  // Change political affiliation
  app.patch("/api/user/political-affiliation", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    const { affiliation } = req.body;
    
    if (!affiliation || !["democrat", "republican", "independent"].includes(affiliation)) {
      return res.status(400).json({ message: "Valid affiliation required (democrat, republican, independent)" });
    }
    
    const status = await storage.canChangePoliticalAffiliation(userId);
    if (!status.canChange) {
      return res.status(400).json({ 
        message: "Cannot change affiliation yet", 
        nextChangeDate: status.nextChangeDate 
      });
    }
    
    const updatedUser = await storage.updatePoliticalAffiliation(userId, affiliation);
    res.json(updatedUser);
  });

  // === INVITE LINKS ===

  // Create invite link
  app.post("/api/invites", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const creatorId = authUser.claims.sub;
    
    const { inviteType, targetUserId, debateId } = req.body;
    const code = generateInviteCode();
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
    
    const link = await storage.createInviteLink({
      code,
      creatorId,
      targetUserId,
      debateId,
      inviteType: inviteType || "friend",
      expiresAt
    });
    
    res.status(201).json({ ...link, url: `/invite/${code}` });
  });

  // Get invite by code
  app.get("/api/invites/:code", async (req, res) => {
    const link = await storage.getInviteLink(req.params.code);
    if (!link) return res.sendStatus(404);
    
    // Get creator info
    const creator = await storage.getUser(link.creatorId);
    res.json({ ...link, creator });
  });

  // Accept invite
  app.post("/api/invites/:code/accept", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const authUser = req.user as any;
    const userId = authUser.claims.sub;
    
    const link = await storage.getInviteLink(req.params.code);
    if (!link) return res.sendStatus(404);
    if (link.used === "true") return res.status(400).json({ message: "Invite already used" });
    if (link.expiresAt && new Date(link.expiresAt) < new Date()) {
      return res.status(400).json({ message: "Invite expired" });
    }
    
    // Prevent self-accept
    if (link.creatorId === userId) {
      return res.status(400).json({ message: "Cannot accept your own invite" });
    }
    
    // If invite was for a specific user, validate they are the accepter
    if (link.targetUserId && link.targetUserId !== userId) {
      return res.status(403).json({ message: "This invite is for someone else" });
    }
    
    // Handle different invite types
    if (link.inviteType === "friend") {
      await storage.addRelationship(link.creatorId, userId, "friend");
      await storage.addRelationship(userId, link.creatorId, "friend");
    } else if (link.inviteType === "enemy") {
      await storage.addRelationship(link.creatorId, userId, "enemy");
      await storage.addRelationship(userId, link.creatorId, "enemy");
    }
    
    await storage.markInviteUsed(req.params.code);
    res.json({ success: true, inviteType: link.inviteType });
  });

  // === WORLD CHALLENGE (DISCOVER THE WORLD) ===

  // Join matchmaking queue for a category
  app.post("/api/world-challenge/join", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    const { category } = req.body;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    if (!category) return res.status(400).json({ error: "Category is required" });
    
    try {
      const result = await storage.joinWorldChallengeQueue(userId, category);
      res.json(result);
    } catch (error) {
      console.error("Join queue error:", error);
      res.status(500).json({ error: "Failed to join queue" });
    }
  });

  // Leave matchmaking queue
  app.post("/api/world-challenge/leave", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      await storage.leaveWorldChallengeQueue(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Leave queue error:", error);
      res.status(500).json({ error: "Failed to leave queue" });
    }
  });

  // Get current user's active challenge
  app.get("/api/world-challenge/active", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const challenge = await storage.getUserActiveChallenge(userId);
      res.json(challenge || null);
    } catch (error) {
      console.error("Get active challenge error:", error);
      res.status(500).json({ error: "Failed to get challenge" });
    }
  });

  // Get challenge stats for the user
  app.get("/api/world-challenge/stats", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const stats = await storage.getUserChallengeStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Get challenge stats error:", error);
      res.status(500).json({ error: "Failed to get stats" });
    }
  });

  // Get recent challenge history for the user
  app.get("/api/world-challenge/history", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const history = await storage.getUserChallengeHistory(userId, 5);
      res.json(history);
    } catch (error) {
      console.error("Get challenge history error:", error);
      res.status(500).json({ error: "Failed to get history" });
    }
  });

  // Get pending challenges (public challenges waiting for opponents)
  app.get("/api/world-challenge/pending", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const challenges = await storage.getPendingChallenges(userId);
      res.json(challenges);
    } catch (error) {
      console.error("Get pending challenges error:", error);
      res.status(500).json({ error: "Failed to get pending challenges" });
    }
  });

  // Create a private challenge with invite code
  app.post("/api/world-challenge/create-private", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    const { category } = req.body;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    if (!category) return res.status(400).json({ error: "Category is required" });
    
    try {
      const challenge = await storage.createPrivateChallenge(userId, category);
      res.json(challenge);
    } catch (error: any) {
      console.error("Create private challenge error:", error);
      res.status(400).json({ error: error.message || "Failed to create challenge" });
    }
  });

  // Join a challenge by invite code
  app.post("/api/world-challenge/join-invite", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    const { code } = req.body;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    if (!code) return res.status(400).json({ error: "Invite code is required" });
    
    try {
      const challenge = await storage.joinChallengeByInviteCode(userId, code.toUpperCase());
      
      // Notify the challenge creator that someone accepted their invite
      if (challenge.player1Id) {
        const joiner = await storage.getUser(userId);
        const joinerName = joiner?.firstName || joiner?.email?.split('@')[0] || 'Someone';
        notifyChallengeAccepted(challenge.player1Id, joinerName, challenge.id).catch(console.error);
      }
      
      res.json({ matched: true, challenge });
    } catch (error: any) {
      console.error("Join by invite code error:", error);
      res.status(400).json({ error: error.message || "Failed to join challenge" });
    }
  });

  // Get challenge by invite code
  app.get("/api/world-challenge/by-code/:code", isAuthenticated, async (req, res) => {
    try {
      const code = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;
      const challenge = await storage.getWorldChallengeByInviteCode(code.toUpperCase());
      if (!challenge) return res.status(404).json({ error: "Challenge not found" });
      res.json(challenge);
    } catch (error) {
      console.error("Get challenge by code error:", error);
      res.status(500).json({ error: "Failed to get challenge" });
    }
  });

  // Cancel a waiting challenge
  app.post("/api/world-challenge/:id/cancel", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    const challengeId = Number(req.params.id);
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      await storage.cancelChallenge(challengeId, userId);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Cancel challenge error:", error);
      res.status(400).json({ error: error.message || "Failed to cancel challenge" });
    }
  });

  // Get challenge by ID
  app.get("/api/world-challenge/:id", isAuthenticated, async (req, res) => {
    try {
      const challenge = await storage.getWorldChallenge(Number(req.params.id));
      if (!challenge) return res.status(404).json({ error: "Challenge not found" });
      res.json(challenge);
    } catch (error) {
      console.error("Get challenge error:", error);
      res.status(500).json({ error: "Failed to get challenge" });
    }
  });

  // Mark player as ready for debate
  app.post("/api/world-challenge/:id/ready", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    const challengeId = Number(req.params.id);
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const challenge = await storage.getWorldChallenge(challengeId);
      if (!challenge) return res.status(404).json({ error: "Challenge not found" });
      
      // Verify user is in this challenge
      if (challenge.player1Id !== userId && challenge.player2Id !== userId) {
        return res.status(403).json({ error: "Not in this challenge" });
      }
      
      const updated = await storage.setPlayerReady(challengeId, userId);
      
      // Check if both players are ready to start debate
      const refreshed = await storage.getWorldChallenge(challengeId);
      if (refreshed && refreshed.player1Ready && refreshed.player2Ready) {
        const { challenge: newChallenge, debate } = await storage.startChallengeDebate(challengeId);
        return res.json({ challenge: await storage.getWorldChallenge(challengeId), debateStarted: true, debateId: debate.id });
      }
      
      res.json({ challenge: await storage.getWorldChallenge(challengeId), debateStarted: false });
    } catch (error) {
      console.error("Ready error:", error);
      res.status(500).json({ error: "Failed to mark ready" });
    }
  });

  // Check for AI takeover (called when research deadline passes)
  app.post("/api/world-challenge/:id/check-timeout", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    const challengeId = Number(req.params.id);
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const challenge = await storage.getWorldChallenge(challengeId);
      if (!challenge) return res.status(404).json({ error: "Challenge not found" });
      
      // Check if deadline has passed and opponent hasn't joined/readied
      if (challenge.researchDeadline && new Date() > new Date(challenge.researchDeadline)) {
        // If one player is ready but the other isn't (or player2 never joined)
        const player1Ready = challenge.player1Ready;
        const player2Ready = challenge.player2Ready || challenge.player2IsAI;
        
        if (!player2Ready && player1Ready) {
          // Player 2 abandoned - AI takes over
          await storage.completeChallengeWithAI(challengeId);
          const { challenge: newChallenge, debate } = await storage.startChallengeDebate(challengeId);
          return res.json({ aiTakeover: true, challenge: await storage.getWorldChallenge(challengeId), debateId: debate.id });
        } else if (!player1Ready && player2Ready) {
          // Player 1 abandoned - forfeit to player 2
          // For now, just start with AI for player 1's side
          await storage.completeChallengeWithAI(challengeId);
          const { challenge: newChallenge, debate } = await storage.startChallengeDebate(challengeId);
          return res.json({ aiTakeover: true, challenge: await storage.getWorldChallenge(challengeId), debateId: debate.id });
        }
      }
      
      res.json({ aiTakeover: false, challenge });
    } catch (error) {
      console.error("Check timeout error:", error);
      res.status(500).json({ error: "Failed to check timeout" });
    }
  });

  // Complete a round (called after debate judgment)
  app.post("/api/world-challenge/:id/complete-round", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    const challengeId = Number(req.params.id);
    const { roundNumber, winnerId } = req.body;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      // Update round winner
      await storage.updateChallengeRoundWinner(challengeId, roundNumber, winnerId);
      
      // Advance to next round or complete challenge
      const updated = await storage.advanceChallengeRound(challengeId);
      const refreshed = await storage.getWorldChallenge(challengeId);
      
      res.json(refreshed);
    } catch (error) {
      console.error("Complete round error:", error);
      res.status(500).json({ error: "Failed to complete round" });
    }
  });

  // === PUSH NOTIFICATIONS ===

  app.post("/api/push/subscribe", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const { endpoint, keys } = req.body;
      if (!endpoint || !keys?.p256dh || !keys?.auth) {
        return res.status(400).json({ error: "Invalid subscription data" });
      }
      
      await storage.savePushSubscription(userId, {
        endpoint,
        p256dh: keys.p256dh,
        auth: keys.auth,
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Push subscribe error:", error);
      res.status(500).json({ error: "Failed to save subscription" });
    }
  });

  app.post("/api/push/unsubscribe", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const { endpoint } = req.body;
      if (!endpoint) {
        return res.status(400).json({ error: "Endpoint required" });
      }
      
      await storage.deletePushSubscription(userId, endpoint);
      res.json({ success: true });
    } catch (error) {
      console.error("Push unsubscribe error:", error);
      res.status(500).json({ error: "Failed to remove subscription" });
    }
  });

  app.get("/api/push/status", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims?.sub;
    
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    
    try {
      const subscriptions = await storage.getUserPushSubscriptions(userId);
      res.json({ subscribed: subscriptions.length > 0 });
    } catch (error) {
      console.error("Push status error:", error);
      res.status(500).json({ error: "Failed to get status" });
    }
  });

  app.get("/api/push/vapid-key", (req, res) => {
    res.json({ publicKey: process.env.VAPID_PUBLIC_KEY || "" });
  });

  return httpServer;
}
